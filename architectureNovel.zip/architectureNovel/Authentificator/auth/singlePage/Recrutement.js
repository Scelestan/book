function C() { var choice = "Continuer#Explication";var texting = `
<br/>
<br/>** Recrutement du sud **
<br/>
<br/>
<br/>
<br/>Dans la ville d’Alvi’ndra, dans le sud de l'Empire du Sphinx, tous les enfants rêvent de devenir chevaliers au château impérial où réside le comte, mais préfèreraient par-dessus tout devenir chevaliers dans la citée impériale où vit l'empereur. C'est dans Alvi’ndra que Xalendan a vu le jour. Il est le fils cadet du forgeron et la forge ne lui plait point, au grand désarroi de son père*. Ce dont il rêve : c'est la chevalerie. C’est son but dans la vie, sa raison de vivre.
<br/>Il a des cheveux châtains mal coiffé et les yeux noirs de la nuit. Ce garçon a toujours voulu voir le monde extérieur, oui, Xalendan n’est jamais sorti de sa région. Tous les ans, il regarde partir les quelques nouveaux chevaliers choisis pour aller à la citée impériale avec envi. Il s’est juré que lui aussi partirait quand il aurait réussi à convaincre son père qui lui refuse avec opiniâtreté son départ. Ce jour-là, la veille de ses dix-sept ans, alors qu'il part pour livrer des outils à une ferme à l'extérieur de la ville ; Xalendan se retrouve face au fils du boucher, un gros personnage qui se vante toujours de ses avantages.
<br/>     -   Tu vas encore rester ici alors que moi, je serai choisi pour être chevalier, se vanta celui-ci en levant la tête.
<br/>     -   Tu as eu la permission de ton père, se renfrogna Xalendan
<br/>     -  Non, c'est ma mère qui l’eu forcé, elle ne voulait pas que je devienne un vulgaire boucher. Ah ! Mais j'oublie, ta mère est morte, quelle perte pour toi et ton frère...
<br/>Le garçon regarda le vantard droit dans les yeux d'un air menaçant. Celui-ci allait poursuivre mais Xalendan l'interrompit, plus menaçant :
<br/>     -   Tais- toi Jules !! Ou je te fais manger les semelles de tes chaussures !
<br/> Le fils du forgeron détestait que l'on parle de sa mère, maintenant dans l‘autre monde… Cela faisait maintenant cinq ans, ses vêtements avaient été retrouvés en bas d’une haute falaise dans une mare de sang. Elle était tombée.
<br/>     -   Tu crois que j'ai peur de toi, viens plutôt te présenter au recruteur ! railla le fils du boucher.
<br/>     -   On verra celui de nous deux qui vaincra ! défia-t-il, énervé.
<br/>     -   Alors à demain, espèce de bon à rien !
<br/>Jules s’éloigna d’un pas fier, content de s’être moqué du jeune homme.
<br/>Xalendan finit son travail et rentra chez lui.
<br/>Il se dépêcha de préparer ses affaires avant que son père ne revienne du travail. C’était à lui de prendre les décisions pour son avenir ! Il était décidé à désobéir à son père.
<br/>Le lendemain, il se leva très tôt, avant tout le monde, et partit se présenter devant le recruteur. Il attendit deux heures, avec l'angoisse que son père le retrouve.  
<br/>Le chevalier chargé du recrutement arrive enfin et jauge en un regard le monde qui l'attend : il y a une bonne cinquantaine de personnes. Autant dire qu’il y avait de la concurrence. Mais ce nombre ne surprit guère le garçon qui connaissait le rêve de tous les enfants. L'homme les emmena sur la place du village et monta sur une estrade qu’il créa avec la magie. Il commença enfin, après une
<br/>
<br/>* Dans ce monde, les enfants sont destinés à faire le métier que font leurs parents. Ainsi, Xalendan doit devenir forgeron selon la tradition.
<br/>
<br/>courte attente :
<br/>     -   Le métier de chevalier est un métier où l'on fait passer les autres avants soi, où l'on est solidaire et où meurent facilement les incompétents, où la peur de mourir n'existe pas, où le devoir ne s'arrête que dans la mort, où la souffrance est mirage et le désespoir une illusion. Mais avant toute chose, que ceux qui sont magiciens s'approchent.
<br/> Personne ne bouge... Xalendan était surprit de cette demande, pour lui, la magie faisait partie de l‘infaisable pour des gens normaux. (D’autre part, jamais Xalendan n’avait entendu un recruteur demander une telle chose, les années auparavant). Et dans cette ville, à part le comte et sa cour, il n’existait aucun bourgeois capable de prendre des cours de magie.
<br/>     -   Cela ne m'étonne pas, très rares sont ceux qui connaissent la magie, lança le recruteur. Très bien, mettez vous les uns derrière les autres.
<br/> Ce fut dans un brouhaha énorme que tout le monde s'exécuta.  Xalendan, lui, resta à l'écart.
<br/>     -  Toi aussi, allez ! ordonna le chevalier à Xalendan, à moins que tu ne viennes que pour observer ?
<br/>     -   A quoi bon se bousculer, se pousser : que l'on soit devant ou derrière, on passera tous, répondit celui-ci. De plus, logiquement les premiers devront quand même attendre que vous finissiez de vous entretenir avec les derniers.
<br/> Un sourire franc se dessina sur le visage du recruteur qui salua respectueusement son état d‘esprit.
<br/>Après une longue attente, le recruteur lui fit enfin signe de rentrer dans la tente. C’est normalement là que le candidat est interrogé par le chevalier. Un sourire s'installa sur le visage de l’homme quand l’adolescent de dix sept ans pénétra dans sa tente. Il lui demanda d’abord son nom, puis son prénom, puis la profession de son père, enfin le nombre de frères et sœurs et sa situation familiale.
<br/>      -    Pourquoi veux-tu devenir chevalier ? lui demanda enfin le recruteur.
<br/> Xalendan fronça lentement les sourcils, c’était une question qu’il ne fallait pas prendre à la légère.
<br/>      -    Je rêve de le devenir depuis très longtemps, monsieur. Une fois, des chevaliers sont venus et ont fait la démonstration de l’art de l’épée puis ils ont montré quelque sort magique ; cela m'a tout de suite intéressé et je me suis promis de devenir chevalier, répondit-il d’un trait.
<br/>      -    Hum… Et quel âge as tu ?
<br/>      -    J’ai dix sept ans aujourd’hui monsieur.
<br/> Le recruteur ferma les yeux, on aurait dit qu’il cherchait quelque chose.
<br/>-	Très bien, tu peux disposer… Et bon anniversaire ! lança-t-il finalement.
<br/> Il attendit le recruteur à l’extérieur de la tente avec les autres jeunes candidats qui s’impatientaient. Seuls dix sont sélectionnés pour l’exercice à l’épée choisit par le recruteur. Parmi eux, Xalendan et le fils du boucher.
<br/>-	Je vais faire des groupes de deux, tiens ! Xalendan et Jules par exemple, proposa le   chevalier.
<br/> On décrit un cercle autour d’eux et on leur tendit une épée. Le garçon était tellement excité, il n’aurait pas pu rêver d’un meilleur adversaire.
<br/>-	Vous vous êtes déjà battus à l’épée ?
<br/>-	Non, répondirent les concurrents d‘une même voix.
<br/>      -	Très bien, c’est parti !
<br/> Xalendan soulève son épée, elle pèse une tonne... mais il dévie l’offensive ennemie d’un coup vers la droite.
<br/>Il a l’impression d’en avoir fait toute sa vie.  Malgré ses quelques maladresses, il exécute des enchaînements de plus en plus complexes qui sortent tous seuls. Son adversaire s’épuise et pour mettre fin à l’affrontement, Xalendan frappe l’épée de Jules latéralement. Ainsi, il le désarme puis porte son épée au cou de son adversaire. Quelques secondes passent…
<br/>-	Très bien, dit le chevalier recruteur. Xalendan, viens par ici.
<br/> Le garçon lança un regard de défi à Jules puis s'exécuta. Le chevalier dévisagea avec un léger sourire l’enfant avant de lui mettre ses doigts sur les tempes. Une minute s’écoula.
<br/>-	Tu es sélectionné, affirma le chevalier en retirant ses doigts.
<br/>-	Yata* !! s’écria l’adolescent.
<br/>-	Tu n’as pas dit à ton père que tu venais, dit le chevalier.
<br/>Sans attendre de réponse il continua :
<br/>      -    J’irai lui parler, va te reposer.
<br/>-	Merci monsieur.
<br/>      -	Tu n’as plus besoin de m’appeler monsieur, tu peux m’appeler Kevin, tu es mon égal à présent*.
<br/>-	Bien monsi…Kevin
<br/>-	Nous partons demain pour la cité impériale !
<br/>-	Euh… à demain alors…
<br/> Tout s’était déroulé très vite, Xalendan avait encore du mal à réaliser… Il venait de changer sa vie, en quelques heures !…
<br/>Le soir, il alla vers la maison pour dire adieu à son père et à son frère…
<br/>-	Je savais que tu y arriverais. Je suis fier de toi, mon fils, lâcha son père.
<br/>-	Merci père… Tu n’es pas fâché ? s’étonna Xalendan un peu inquiet.
<br/>-	Fâché contre son fils qui réalise son vœu, non… répondit son père avec un sourire forcé. Une
<br/>vraie tête de mule ! Tu me fais un peu penser à moi dans mon jeune âge…
<br/> La soirée se passa avec une petite fête d’adieu improvisée, organisée par son frère et son père.
<br/>Le lendemain arriva vite. Il partit de sa maison le cœur serré avec Kevin.
<br/>-	Pourquoi n’y a-t-il que moi de recruté, demanda Xalendan qui se souvenait des années précédentes.
<br/>-	Le chef nous a demandé de ne prendre au maximum qu'une personne cette année, sinon... On va tout t’expliquer lorsque nous arriverons à la cité, lui répondit le chevalier.
<br/>
<br/>*C’est un mot du patois d’Alvi’ndra, qui signifie littéralement : « youpi ».
<br/>
<br/>*Dés lors que le recruteur a dit qu’il était choisi chevalier, Xalendan en est un. Il n’y a pas d’épée de monarque que l’on pose sur l’épaule comme au moyen âge et le roi n’a point besoin de réciter des paroles. Il n’y a pas non plus de grade, on est un chevalier et point final. Sauf le maître des chevaliers qui est en fait le seul et unique chef. Le rang d’un chevalier se fait par ses titres, c'est-à-dire par le mérite des quêtes qu’ils accomplissent.
<br/>
<br/>          
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>                               
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>3.
<br/>
<br/>** Recrutement de l’est **
<br/>
<br/>
<br/>
<br/>-	Bonjour, dit le recruteur d’Aliga devant la soixantaine d’enfants d’âges divers.
<br/>-	Bonjour, répondirent en cœur les concurrents.
<br/>Parmi eux, Jasson, aux longs cheveux clairs et aux yeux bleus gris, un adolescent de 16 ans à l’esprit imaginatif, espiègle et joueur. Il a, depuis son enfance, le don de la lévitation et de la guérison. Bien qu’il ne le maîtrise pas, il a plusieurs fois guéri ses écorchures lui-même et a soigné la jambe de son père quand celui-ci s'est enfoncé très profondément une fourche dans le mollet. Son père et sa mère sont des fermiers. Ils lui ont permis de devenir chevalier et ainsi de réaliser son rêve. Son père espère qu’il sorte ainsi de la pauvreté, ainsi qu’il a toujours dis : « comme ceux-là ».
<br/>Il arrive à soulever des objets légers sans les toucher et s’entraîne pour le faire avec des objets plus lourds. Quand le recruteur demande aux enfants magiciens de s’avancer, seul Jasson s’avance, à sa grande surprise.
<br/>-	Que sais-tu faire, jeune homme, demanda le chevalier recruteur.
<br/>-	Je sais soulever des objets sans les toucher et guérir les écorchures, monsieur.
<br/>Le ton de fierté dans la voix de l'adolescent fit froncer les sourcils du recruteur :
<br/>-	Montre-moi, soulève ce caillou sans le toucher !
<br/>A la grande stupéfaction de la foule, Jasson s’exécuta et le caillou se leva faiblement. Le chevalier lui demanda s’il contrôlait ses pouvoirs et l’adolescent lui répondit que non, qu’il exécutait sans vraiment savoir comment s'opèrent les charmes magiques de guérison et de lévitation.
<br/>      -    Bien, tu me raconteras tout cela dans la tente, tout le monde en rang ! ordonna le recruteur.
<br/>Jasson entra dans la tente après un long moment et répondit aux questions diverses que posait le recruteur. Finalement, le chevalier soupira et il lui posa ses doigts aux tempes.
<br/>-	Tu as de grandes qualités mais je vois aussi beaucoup d’indiscipline dans ta tête, dit-il.
<br/>L’adolescent rougit.
<br/>-	Serais tu prêt à devenir un enfant sérieux pour devenir chevalier ? demanda le recruteur.
<br/>-	Oui ! Je serais prêt à tout pour le devenir, s’exclama joyeusement le candidat.
<br/>-	Et bien, tu es maintenant un chevalier.
<br/>-	Quoi ! s'exclama Jasson fou de joie.
<br/>Sa seule crainte était d’avoir mal entendu.
<br/>-	Tu es chevalier, répéta le chevalier avec un demi-sourire.
<br/>Après l'éclatement de ses émotions pour sa victoire, le chevalier Jasson alla raconter son exploit à son père et sa mère qui le félicitèrent, malgré leur tristesse*.  Le lendemain, il partit les larmes aux yeux en sachant qu’il ne reverrait plus sa famille de sitôt. Ses larmes séchées, il demanda au recruteur :
<br/>-	Pourquoi n’y a-t-il que moi de recruté ?
<br/>-	Le chef nous a demandé de ne prendre maximum qu'une personne, lui répondit-il
<br/>simplement.
<br/>
<br/>*Les chevaliers sont malheureusement contraints à ne plus revoir leur famille.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>4.
<br/>
<br/>** Recrutement de l’ouest  **
<br/>
<br/>
<br/>
<br/>Dans la ville de Layad, un garçon de dix sept ans part pour la chasse. Sa vie va être changée à  jamais. Fils d’un marchand, Selestan aime l’aventure, le danger et les défis. Il est assez grand, a de longs cheveux bruns et des yeux marron clairs. Il aurait aimé devenir chevalier, mais il n’y a pas de recruteur qui vient dans la ville cette année. 
<br/>« Le chef des chevaliers recrute de moins en moins » dit la rumeur. « Les recruteurs n’iront que dans les villes choisies par l'empereur. » Le jeune homme devra donc attendre l’année prochaine, en espérant que la caravane de marchandises de son père soit dans une grande ville à ce moment là.
<br/>Selestan est d’une adresse incomparable dans le maniement de l’arc, c’est ce qui l’a conduit à être chasseur à gages avant de continuer dans une autre voie. Il poursuit sa proie... Un énorme sanglier... Jusqu'à la route... L’animal a déjà traversé quand il décide de tendre l’arc.
<br/>-	Laisse-moi passer, ne tire pas, dit un homme à cheval.
<br/>« Si je ne tire pas, je perds ma proie et devrais rentrer les mains vides », cette idée lui était insupportable. Alors, ignorant les paroles de l’homme, Selestan tira…
<br/>La flèche frôla de très près la tête de l’homme qui esquissa un cri de surprise ; la flèche atteignit sa cible avec une puissance incroyable et le sanglier, qui se trouvait à quarante mètres du jeune chasseur, s’écroula.
<br/>Selestan regarda alors l’homme en le défiant.
<br/>-	Chevalier William, recruteur, dit l’homme d’un ton calme.
<br/>-	Qu….quo…balbutia Selestan embarrassé, il pouvait dire adieu à ses ambitions de chevalier.
<br/>-	Tu as déjà pensé à devenir chevalier ? demanda le recruteur comme s’il avait lu dans ses
<br/>pensées.
<br/> Il fût surpris par la question.
<br/>-	Oui, monsieur, répondit le jeune homme en rougissant, mais il n’y avait pas de recruteur
<br/>dans la ville, cette année.
<br/>-	Et moi, il n’y avait pas de concurrents assez qualifiés, soupira le chevalier recruteur. Mais toi
<br/>tu as l’air parfait, viens par ici.
<br/> Selestan s’approcha et le chevalier lui mit ses doigts sur les tempes.
<br/>-	Tu es qualifié ! s’écria le chevalier recruteur joyeusement.
<br/> Si rapidement ! Les recrutés devaient habituellement faire un ou plusieurs tests avant d’être choisis.
<br/>-	Que je deviens…. c'est, c'est... je vais aller préparer mes affaires et en informer mes parents.
<br/>-	Va, nous partons demain, rendez-vous ici à  neuf heures du matin.
<br/> Quand il en informa sa famille, elle parut satisfaite et heureuse, malgré leur tristesse qu'ils cachèrent rapidement pour laisser la fierté les envahir*. Le lendemain, il partit donc en compagnie de William et demanda :     
<br/>-	Pourquoi n’allez-vous pas dans d’autres villes pour recruter ?
<br/>      -	C'est à cause du chef, il n'a plus vraiment besoin de nouveaux chevaliers... Une bonne cinquantaine lui suffira, répondit-il.
<br/>
<br/>*Les parents acceptent généralement que leur fils devienne chevalier, car cela permet à celui-ci de sortir du bas peuple.
<br/>
<br/>          5.
<br/>
<br/>** Recrutement du nord  **
<br/>
<br/>
<br/>
<br/> Chloé, une fille de taille moyenne, aux longs cheveux bruns étincelants, aux yeux verts émeraude et à la peau douce comme des pétales de roses, âgée de 16 ans. C’est la fille légitime du comte de Colto, une ville du royaume de Zerande. Elle attend avec impatience l’arrivée du mystérieux recruteur venu du pays allié voisin. Douce et têtue, aussi turbulente que sage, cette fille a un mystérieux don pour la magie. Avec son esprit réaliste, elle n’arrive jamais à expliquer ses actions magiques incontrôlées. Quand un grand homme étranger entra dans les fortifications, tout le monde se tourna vers lui, avec l’espoir que ce soit le chevalier.
<br/>-	Bonjour à tous, dit l’homme, je suis le recruteur de chevaliers.
<br/>-	NON !! dit un homme avec exactement le même physique qui entrait en courant, c’est un
<br/>imposteur !
<br/>-	Argh !! Ce foutu a réussi à se libè…
<br/> Mais avant qu’il ait pu finir sa phrase, l’homme reçut une décharge électrique envoyée par son sosie, ce sortilège révéla le vrai visage du faux recruteur.
<br/>-	Un mage noir !! s’exclama le vrai recruteur.
<br/> Le mage noir se retourna vers son adversaire et lui lança une boule de feu qui envoya valser le chevalier trois mètres plus loin. Celui-ci riposta avec un éclair étincelant qui sortit de sa paume, le mage se défendit à l’aide d’un bouclier invisible. Une épée magique apparut dans les mains du mage qui s’apprêtait à achever son ennemi. Alors, les mains de Chloé se levèrent toutes seules et une onde de choc frappa le bouclier invisible du mage noir. Celui-ci se tourna vers elle et Chloé sentit ses paumes lui brûler quand elle envoya une deuxième onde de choc qui brisa le bouclier du mage, celui-ci eut à peine le temps de se téléporter avant que l’onde de Chloé ne le frappe. Avec l’énorme quantité d’énergie qu'elle avait utilisée, Chloé s’évanouit…
<br/>Quand elle se réveilla elle était sur son lit, son père à ses cotés qui marmonnait des choses incompréhensives. Un homme barbu de petite taille : le comte de Colto.
<br/>-	Doucement, s’écria le père en la voyant lever la tête, tu as peut être fais l’objet d’un sortilège
<br/>maléfique !
<br/>-	Non père, je me sens très bien ! répliqua-t-elle sèchement.
<br/> Chloé déteste quand on la traite comme une enfant gâtée ou qu’on la pouponne, elle déteste les flatteries et les compliments quand ils sont dits en l’air ou pour faire plaisir !
<br/>-	Reste au lit, tu es fatiguée. S’il te plait, la supplia son père.
<br/>-	Non, je dois être candidate, je veux devenir chevalier !
<br/>-	Mais tu l’es déjà, dit calmement le recruteur qu’elle n’avait pas remarqué au coin de la pièce.
<br/> Ce dernier  mit ses doigts sur les tempes de Chloé et dit :
<br/>-	Tu nous as fait une belle démonstration de tes pouvoirs, certes non contrôlés, mais puissants.
<br/>Tu es élue chevalier !
<br/>-	Me… Merci, dit Chloé qui ne savait pas vraiment comment réagir à cette soudaine
<br/>révélation. Elle était chevalier, enfin…
<br/>-	Demain, nous partons pour la cité impériale ! dit joyeusement le recruteur.
<br/>Quand l’homme partit, elle regarda son père qui pleurait.
<br/>-	Ma fille va être chevalier, elle va peut-être mourir, tuée par un démon venu du dieu noir de la
<br/>nécromancie, de l'enfer et du fe...
<br/>-	Tais-toi père ! Où je te lance un sort ! lança-t-elle, bien qu'elle connaisse très bien la paranoïa
<br/>de l'homme.
<br/> Chloé est une fille autoritaire et à fort caractère, alors, son père ne dit mot et partit de la chambre…
<br/>Le lendemain, elle quitta la ville en compagnie du recruteur et s’étonna d’être seule.
<br/>-	Pourquoi suis-je la seule recrutée, demanda alors Chloé
<br/>-	Le chef ne voulait pas plus d'une personne par recruteur, répondit le chevalier, soucieux de la
<br/>réaction de la fille à fort caractère.
<br/>-	D'accord, dit simplement la nouvelle chevalière.
<br/>Le recruteur se détendit.
<br/>
<br/>        
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}