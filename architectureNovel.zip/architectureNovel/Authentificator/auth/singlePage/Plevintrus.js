function C() { var choice = "Continuer#Guerre";var texting = `
<br/>
<br/>** Les elfes Sylvains **
<br/>
<br/>
<br/>
<br/>Durant le reste du voyage, Laziador et Jasson ne s'adressèrent presque plus la parole. Toutes les nuits étaient animées par les cris de douleur du mutant, Laziador faisait don tous les soirs de son sang à Jasson et le jeune homme brillait de tout son corps de plus en plus toutes les nuits, c'est quelque chose qui rendait l'elfe plus inquiet que jamais. Le chevalier avait beaucoup changé, autant mentalement que physiquement. On ne voyait plus l'œil de Jasson, tellement le rouge sur la pupille était présent. Il lui arrivait régulièrement de cracher du sang, sa peau avait une lueur rouge, ses sourcils disparaissaient et ses cheveux tombaient. Mais plus horrible, c'était le sixième doigt qui lui était poussé à la main. Plus odieux encore, ses poils et ses ongles qui poussaient à une vitesse impressionnante. Le pire, c'était la queue, une queue qui avait poussé dans le bas du dos du chevalier. Chloé, qui avait toujours trouvé Jasson " beau ", ne le regardait jamais, ou alors avec dégout. Les quatre chevaliers et leur professeur arrivèrent à la frontière. Aucun  garde, juste une pancarte sur laquelle était écrit : " Si vous tenez à la vie, n'entrez pas ". Il est vrai qu'avec l'effet que donnait la forêt, elle ne devait pas recevoir beaucoup de visiteurs. Laziador fit un geste et les chevaliers le suivirent dans la forêt. A peine ils eurent fait cent mètres que le professeur leur ordonna de s'arrêter. Tous s'exécutèrent sans rien dire quand l'elfe leur demanda de s'asseoir. Il déroula lentement son bandeau, laissant apparaître ses oreilles magnifiques. Laziador leva la main d'un coup sec puis lança :
<br/>      -    Eléfé sylvatyste, nossa benderé ylisto vossa mendist d'hilp.
<br/>      -    Elfe... sylvain je crois... Nous venons en paix vous demandez de l'aide, traduit Xalendan à ses camarades
<br/>Ses mots n'eurent aucun effet, la forêt resta comme elle était.
<br/>      -    Bien, vous pouvez vous asseoir, ils devraient arriver dans dix minutes. Je vais vous faire votre premier cours de magie avec moi en temps que prof. Tout d'abord, d'où vient la magie ?
<br/>Xalendan leva le doigt :
<br/>      -    Elle vient des mots que l'on pense ou que l'on prononce, et l'énergie magique de notre corps.
<br/>      -   Et tu oublies une chose primordiale, que peu de gens savent... C'est la planète qui exécute la magie.
<br/>Les chevaliers regardèrent l'elfe avec étonnement.
<br/>      -   Pourquoi alors nous devons utiliser de l'énergie pour un sort, si c'est la planète qui l'exécute ? demanda la jeune femme.
<br/>      -   Toujours de bonnes questions, Chloé... Eh bien comme je vous l'ai dit, la planète ne fait qu'exécuter... en utilisant notre énergie, elle ne fait que ce qu'on lui demande.
<br/>      -    C'est pour ça qu'il faut penser ou dire ce qu'on veut faire magiquement, pour que la planète l'entende, dit Selestan
<br/>      -    Oui, et le langage des elfes est plus puissant parce que la planète le comprend mieux ! s'exclama Xalendan
<br/>Le professeur eu un grand sourire :
<br/>      -    Vous avez tout deviné tous seuls ! C'est bien !
<br/>Un bruit de pas se fit entendre, Laziador, à la vitesse de l'éclair, se releva. Une jeune elfe apparut alors, habiller de feuilles et de fleurs, cet être était si magnifique. L'elfe avait de très longs cheveux blonds, le visage flegmatique, ses yeux éclatant de beauté étaient bleus comme la mer. Elle s'avança, ses gestes étaient fins, gracieux et sans hésitation. Dès qu'elle vit les oreilles de Laziador, ses sourcils se froncèrent.
<br/>      -    Comment un haut elfe peut se trouver ici ? demanda l'elfe d'une voix belle et cristalline.
<br/>Laziador raconta rapidement son histoire comme il l'avait racontée aux chevaliers précédemment.
<br/>      -     Pourquoi êtes-vous ve...
<br/>Les yeux de l'elfe croisèrent ceux de Jasson, qui était rouge sang. A une vitesse fulgurante, elle sortit une épée de son fourreau et s'élança sur Jasson. La vitesse de l'attaque ne laissa pas le temps au chevalier de réagir. Jasson, de manière incontrôlée, leva la main, paume vers le ciel. La lame de l'épée se planta dans son abdomen. L'elfe retira l'épée du ventre du chevalier et la rangea dans son fourreau, pleine de sang. Jasson tomba à genoux et baissa la tête, son sang coulait très rapidement. Toujours la paume en l'air, le bras tendu, le jeune homme chuchota d'une voix douce à l'adresse de l'elfe :
<br/>      -    Ce n'est pas bien de ranger son arme sans avoir enlever le sang qu'il y a dessus...
<br/>Un rayon lumineux surpuissant éclata sur Jasson, le chevalier cria à pleins poumons, la douleur était insupportable. Un gigantesque éclair lumineux jaillit de Jasson vers le ciel.
<br/>Le jeune homme sentit ses plaies se refermer avant de s'évanouir, encore une fois.
<br/>
<br/>
<br/>
<br/>
<br/>Tout le monde avait les yeux écarquillés, même l'elfe sylvain et Laziador. Xalendan regardait la scène bouche bée, ahuri par la puissance de son frère d'arme. C'est la jeune elfe qui se dirigea en premier vers Jasson, elle lui mit sa main sur le cœur et la retira doucement en chuchotant :
<br/>      -    Co... Comment ?... Ce n'est pas possible ! Il est vivant...
<br/>Elle se retourna vers Xalendan et les autres avant de dire :
<br/>      -    Comment a-t-il pu utiliser la magie alors que la planète est verrouillée !!
<br/>Laziador eut l'air surpris, il tendit sa main vers un caillou et s'écria :
<br/>      -    Soulève-toi !
<br/>Le caillou ne bougea pas et l'elfe tourna la tête vers l'autre elfe :
<br/>      -    Depuis quand ?
<br/>      -    Un jour et demi à peu près... lui répondit-t-elle.
<br/>      -   Nous n'avons pas essayé la magie depuis deux jours, c'est normal que nous ne nous en soyons pas aperçu ! Mais comment et pourquoi !!
<br/>L'elfe hocha négativement la tête en disant qu'elle n'en savait rien puis son attention dériva sur Jasson qui dormait au sol :
<br/>      -    C'est un démon ! Peu importe comment il a réussi à faire de la magie, il faut le tuer...
<br/>Par pure curiosité, Xalendan tendit discrètement la main vers un caillou et pensa de toutes ses forces : "Soulève ce caillou" mais rien ne se produisit. Il réessaya une deuxième fois mais le caillou ne bougea pas pour autant. Xalendan surprit les autres chevaliers à faire la même chose que lui, sans succès.
<br/>      -  C'est justement pour ce démon que nous venons ! s'exclama Laziador, il n'est pas encore à la phase finale de la mutation alors...
<br/>      -    Non... Nous ne procurons plus de feuilles aux humains !! C'est clair...
<br/>      -  De là à en oublier le pacte de vos ancêtres avec les chevaliers du Sphinx !! s'écria le professeur de toutes ses forces, vous n'êtes pas dignes d'être des elfes !! Cette race a toujours eu des valeurs que vous salissez !
<br/>Elle le regarda, impassible, puis dit :
<br/>      -    Des chevaliers du Sphinx... Suivez-moi...
<br/>Les deux elfes galopaient à une vitesse impressionnante, Laziador portait Jasson dans ses bras, les autres chevaliers essayant tant bien que mal de suivre le rythme à cheval. Ils  avancèrent toute la journée sans s'arrêter.
<br/>     -    Comment vous vous appelez ? demanda Selestan en rattrapant l'elfe.
<br/>Elle tourna la tête vers lui et quand leurs regards se croisèrent, Selestan détourna automatiquement les yeux. L'elfe faisait environ cinq centimètres de moins que Selestan, et pourtant, celui-ci la redoutait, sans aucune raison crédible.
<br/>      -    Lynaée... répondit-elle en souriant très légèrement.
<br/>Ils avancèrent encore quelques temps puis l'elfe s'arrêta, imitée par les autres.
<br/>      -    Nous sommes arrivés, dit-elle
<br/>      -  Arrivés où ? je ne vois rien, à part des arbres qui s'étendent à l'infini ! lança Xalendan
<br/>Sans rien dire, Lynaé avança de quelques mètres et disparut.
<br/>      -    Les yeux ne voient que la surface des choses... signala Laziador en avançant. Il disparut lui aussi avec Jasson dans les bras.
<br/>Selestan s'avança ensuite, et disparut ainsi que Chloé qui le suivait. Xalendan écarquilla les yeux, il avança. Il hésita longuement mais finit par se diriger vers l'endroit où ils avaient tous disparu.
<br/>Xalendan se regarda les bras et les mains, soulagé qu’ils soient encore présents. Il aperçut ses frères d'arme en levant la tête...
<br/> " Magnifique" fût le seul mot qu'il arriva à prononcer.
<br/>Des maisons elfiques étaient construites dans les arbres, un genre de grande place se tenait au milieu de la végétation, une centaine d'elfes venaient vers eux. Sortant des habitations ou  de la forêt dense, ils venaient tous se placer devant eux. Se souvenant des instructions de son livre, Xalendan s'avança, mit un genou à terre puis récita en langage elfe :
<br/>      -  Nous sommes venus en paix, amis du cycle de vie arbitraire. Le destin a choisi ce jour, mes paroles ne sont donc que formalité.
<br/>Laziador eut un grand sourire avant de poser lui aussi le genou à terre en posant Jasson devant lui. Ne sachant pas trop quoi faire, Chloé et Selestan imitèrent simplement leur professeur.
<br/>Personne ne bougeait, même pas les elfes, Lynaée s'était mêlée à ses compagnons. Un vieil elfe arriva alors, tout le monde s'écarta pour le laisser passer.
<br/>      -    Vous connaissez les paroles et pourtant, vous n'êtes pas des elfes ! déclara-t-il
<br/>      -    Moi, si... lança Laziador en se levant.
<br/>Le vieil elfe dévisagea, identifia le professeur longuement.
<br/>      -    Je suis le gouvernant du Lloclavr... Je désire parler avec vous cinq dans ma maison, seuls.
<br/>Laziador prit Jasson et les autres se levèrent. Ils suivirent alors le gouvernant elfe dans sa maison. Ils durent monter à une espèce d'échelle pour atteindre celle-ci.
<br/>L'elfe les invita à s'asseoir sur des chaises en bois couvertes de feuilles vertes.
<br/>      -    Je m'appelle Acelt, pourrait-je sav...
<br/>Il s’interrompit en voyant Jasson que le professeur avait posé au sol.
<br/>      -    Ne vous inquiétez pas, ce jeune homme est en mutation corporelle, mais il n'est pas encore Minaos... dit Laziador.
<br/>Le gouvernant leva la tête vers lui.
<br/>      -    Je vois, vous voulez qu'on lui donne une feuille, mais il n'en est pas question.
<br/>      -    Ces quatre adolescents sont des chevaliers du Sphinx.
<br/>Une expression d'effarement se lut alors une petite seconde sur le visage d'Acelt. Il retrouva vite son impassibilité et répliqua sèchement :
<br/>      -    Et alors !
<br/>Laziador répéta ce qu'il avait dit à Lynaé, mais cette fois plus calmement :
<br/>      -    Vous oubliez le pacte de vos ancêtres avec les chevaliers du Sphinx.  Vous n'êtes pas dignes d'être des elfes... Cette race a toujours eu des valeurs que vous salissez.
<br/>Acelt regarda le professeur avec tristesse, il ferma les yeux et une larme coula sur sa joue. Il rouvrit les yeux et dit d'une voix pleine d'excuse :
<br/>      - Nous ne faisons plus confiance aux humains, malheureusement... Pourtant, vous le savez mieux que moi, j'aimais cette race riche et intelligente. Seulement voilà, nous sommes en guerre contre des humains mercenaires à cause de la trahison d'un des rares humains que notre peuple a beaucoup aimé. A cet homme, nous avons transmis tous nos secrets avec confiance... Et il nous a trahi, il continue à nous lancer de puissantes attaques avec ses guerriers ! Il nous a menacés de dire au Chaos nos secrets... Nous allons... mourir si tel est le cas...
<br/>Les humains, malgré leur richesse et leur intelligence, sont des êtres malicieux et sournois, perfides et aveuglés par le pouvoir.
<br/>      -   Je ne suis pas un humain et je vous assure que mes élèves sont dignes de confiance.
<br/>Acelt lui lança un regard triste sans rien dire.
<br/>      -    No ya séito'o (je le jure), lança Xalendan au gouvernant.
<br/>L'elfe tourna furtivement la tête vers lui.
<br/>Xalendan continua :
<br/>      -    La parole sacrée des elfes, celui qui ment avec cette langue se voit maudit par les dieux eux-mêmes. Et l'elfe qui ne croit pas aux mots que j'ai prononcé maintenant ne vaut pas mieux que celui qui les trahit.
<br/>Une autre larme coula sur la joue de l'elfe et celui-ci, les yeux froncés, souffla à Xalendan :
<br/>      -    Tu me fais penser à cet homme avant qu'il ne nous trahisse, il avait les mots pour gagner la confiance de l'autre, les beaux mots qui font que tu laisses un sourire se dessiner sur ton visage. Mais ça c'est terminé, je ne ferai pas la même erreur !
<br/>Xalendan regarda l'elfe avec gravité, puis déclara d'un ton faussement navré :
<br/>      -    C'est en voulant ne pas faire une erreur que vous allez en faire une autre...
<br/>Acelt resta de marbre, regardant Xalendan, impassible.
<br/>      -  Alors autant ne rien tenter, comme ça vous ne ferez aucune erreur, dégagez nous de vos terres ! continua Xalendan. Seulement si on fait ça, il faudra tuer Jasson, sinon il se retrouvera dans le camp du Chaos ! Et alors là, vous serez la cause de la mort de ce jeune homme et vous ne vaudrez pas mieux que l'homme qui vous a trahi !
<br/>      -    ASSEZ !! beugla le gouvernant dont les yeux brillaient. Je vous donnerai la feuille que vous voulez... Mais il faudra nous aider à tuer l'homme qui nous a trahis en retour.
<br/>Laziador baissa la tête. " Je n'ai jamais vu meilleur négociateur de toute ma vie ! " songea le professeur.
<br/>      -    Très bien, vous nous aidez en nous procurant une feuille de guérison et on vous aide en tuant cet... humain.
<br/>
<br/>
<br/>
<br/>
<br/>Quand Selestan était sorti de la maison du gouvernant, il était parti à la découverte de la forêt. Les elfes lui dirent qu'il ne fallait pas trop qu'il s'éloigne et le chevalier respecta donc leur parole. Certes le cheval de Jasson avait été abandonné pendant le voyage, mais Cristalis était encore bien là. Ça paraissait bizarre mais, pour une forêt si intense que celle-ci, la lumière du coucher du soleil se voyait largement. Selestan s'assit dans l'herbe avec Cristalis qui s'allongea comme à son habitude. Il contempla les fleurs avec tendresse quand il eut soudain une envie impérieuse de dessiner...  Il avait toujours aimé, admiré les artistes pour leurs œuvres magnifiques. Aussi bizarre que ça puisse paraitre, Selestan voulait dessiner, là, maintenant, pour la première fois de sa vie. Il partit en courant vers la ville des elfes en demandant à Cristalis de l'attendre. Il se rendit à la maison d’Acelt et toqua poliment. Quand il demanda des accessoires de dessin, Acelt lui donna rapidement un cahier vierge ainsi qu'un crayon et une gomme. Il revint alors à l’endroit où sa licorne l'attendait en ronflant.
<br/>Sans trop savoir comment faire, Selestan prit le crayon avec le désir de dessiner la jolie fleur bleue qui se trouvait devant lui. A son grand étonnement, sa main commença son œuvre, enchainant des traits, des ronds et des ombres. Rapidement, il termina son dessin qu'il regarda avec stupéfaction, il avait reproduit la fleur trait pour trait, même en noir et blanc ce dessin faisait penser à la réalité. Selestan tourna la tête et aperçut Lynaée qui le regardait assise sur un tronc d'arbre tordu, le visage dans les mains.
<br/>      -    Que fais-tu ? demanda Selestan à l'elfe
<br/>      -    Je te regarde... Tu peux me montrer ton dessin.
<br/>Selestan se rendit au côté de Lynaée et tendit son œuvre. Un son admiratif sortit de la bouche de l'elfe.
<br/>      -    Tu dessines depuis combien de temps ?
<br/>      -    Euh... A vrai dire, c'est la première fois...
<br/>L'elfe parut étonné avant de montrer au chevalier son livre de dessin. Selestan admira les dessins, les yeux écarquillés, à côté, sa petite fleur était horrible, des arbres, des champs, des prairies, des lacs et des torrents... Ce livre était un vrai dictionnaire sur la nature.
<br/>      -    Tes parents doivent être fiers de toi ! lâcha Selestan.
<br/>Lynaé eut un sourire :
<br/>      -    C'est la première fois que je le montre à quelqu'un.
<br/>Le chevalier fût touché par la déclaration de l'elfe. Il décida de changer de conversation pour ne pas faire de boulette regrettable :
<br/>      -    Tu as quel âge ?
<br/>      -    Quatre vingt ans et toi ?
<br/>Selestan perdu sa respiration et toussa pour que l'air revienne dans ses poumons.
<br/>      -    ah...Euh... Moi j'ai... J'ai dix sept ans.
<br/>      -    Pas la peine d'être gêné tu sais, j'ai entendu dire que l'âge des elfes était cinq fois celui des hommes, ce qui te ferait... quatre vingt cinq ans exactement.
<br/>Selestan ne fût pas le moins du monde soulagé, l'expérience de cette "jeune" elfe était bien supérieure à la sienne, à tous les niveaux.
<br/>      -    Nous devrions aller voir comment va réagir l'autre dém... Chevalier avec la feuille, dit Lynaée.
<br/>Selestan acquiesça d'un hochement de tête.
<br/>Durant la petite marche du retour, Selestan et Lynaée ne parlèrent pas. Le chevalier regardait l'elfe du coin de l'œil et admirait sa beauté. Quand ils furent presque arrivés, l'elfe s'aperçut du regard du jeune homme tourné vers elle.
<br/>      -    Pourquoi tu me regardes sans cesse de cette façon.
<br/>Selestan tourna aussitôt la tête à l’opposé. " Parce que je te trouve magnifique ! " répondit Selestan dans son for intérieur.
<br/>      -    C'est... C'est parce que tu... Tu... Enfin euh... Je ne sais pas, pardon.
<br/>Tous les gestes du chevalier étaient saccadés et hésitants, tellement qu'il était envahi par la timidité. Il se sentait rouge comme une tomate, quelque chose qui ne lui arrivait que très rarement. Lynaée rigola de bon cœur.
<br/>Ils arrivèrent enfin devant la tente où avait été logé Jasson, une tente étrange faite de feuilles et de branches, gardée par un elfe.
<br/>      -    Il a avalé la feuille il y a une heure... dit Laziador qui arrivait de son pas fluide derrière Selestan. Il est sauvé.
<br/>      -    Comment peut-on savoir s’il va guérir ou pas ! Ces feuilles, je veux bien qu'elles soient puissantes mais il ne faut pas les comparer aux dieux en disant que la feuille va le guérir à l'aise ! s'exclama Selestan.
<br/>Lynaée lui envoya un regard plein de colère avant de s'en aller d'un pas rapide. Selestan tourna ses paumes vers le ciel et haussa les épaules d'un air étonné en regardant l'elfe partir. Laziador lança un regard froid au chevalier :
<br/>      -    Je ne te savais pas si croyant ! Selestan... Tu as intérêt à surveiller tes remarques si tu ne veux pas que je te renvoie. Sache que les dieux n’existent pas !
<br/>      -   Vous ne pouvez pas prouver qu'il n'existe pas de dieux comme je ne peux prouver le contraire, professeur, dit Selestan en inclinant la tête vers la droite avec un léger sourire.
<br/>Un sourire moqueur se dessina sur le visage de l'elfe.
<br/>      -  Apparemment... Les paroles de Jasson ont été enregistrées...
<br/>Un lourd silence s'installa entre le professeur et le chevalier puis Xalendan et Chloé arrivèrent à leur tour devant la tente de Jasson.
<br/>      -    Pouvons-nous le voir ? demanda aimablement Laziador à l'elfe qui gardait la tente.
<br/>L'elfe sourit en hochant la tête en signe d'accord. Il souleva la feuille qui servait de porte. Le professeur devint alors livide et ses yeux s'agrandirent de frayeur.
<br/>Selestan s'étonna de cette attitude et regarda à son tour... Vide, complètement vide... Aucune trace de Jasson dans la tente.
<br/>Laziador se précipita vers une cruche remplit d'eau posée sur une table et partit en courant. Il hurlait à tue-tête :
<br/>      -    Cette fois !!... TU ES MORT !!...
<br/>
<br/>
<br/>
<br/>
<br/>Jasson s'était réveillé dans les bois, tout seul. Il avait scruté les environs sans rien trouver, pendant un instant, il envisagea la possibilité que ses compagnons l'aient abandonné...
<br/>Il se souvint alors avoir entendu une conversation entre ses camarades et un elfe sylvain. Bizarrement, même évanoui, Jasson avait entendu toutes les paroles de ses compagnons comme s'il avait été conscient. Il se remémora les différentes paroles et en conclut qu'il était guéri... Mais pourquoi était-t-il tout seul ? Une fois encore, la réponse lui apparut rapidement devant les yeux :
<br/>      -    Jasson... Je... Je ne me suis jamais... attaché à une personne mais toi, toi tu as réussi, souffla Dagonor, les dieux m'ordonnent sans cesse de te tuer... Mais je résiste à la souffrance.
<br/>Dagonor était entouré de chaînes magiques violettes qui formaient un globe autour de lui. De ses chaines se libéraient des rafales d’éclairs rouges qui fondaient sur le caomme pour le faire souffrir. A chaque étincelle, le visage de Dagonor se crispait et se ridait de plus en plus. Déjà qu'il avait l'apparence d'un démon, là, on aurait dit le dieu de la mort tout droit sorti de l'enfer.
<br/>      -    Jasson... Je ne suis pour l'instant qu’au degré un de ma punition... Si je ne te tue pas maintenant je passerai très vite au stade deux. Et quand le stade deux sera terminé... et si je ne t’ai pas tué... je tomberai lentement dans le coma, le stade trois de ma punition, avec le dieu Soruss en enfer. Et si par malheur, quand je serai au stade deux de ma punition, quand je serai en train de m'évanouir, ma peau touche de l'eau pure... alors je me transformerai en démon majeur de Kozopt et mon âme sera contrôlée par les dieux du Chaos...
<br/>ARG !!
<br/>Jasson n'avait compris que deux choses dans les dires de Dagonor :
<br/>Le Caomme était en train de se sacrifier pour le sauver et... pour des raisons qu'il n'avait pas trop comprises, le Caomme ne devait surtout pas être en relation avec de "l'eau pure".
<br/>      -    NON !! Dagonor ! Pourquoi te sacrifier !
<br/>      -   Prends soin de toi, petit, et prends garde, les dieux du mal enverront des chasseurs pour vous tuer, toi et tes compagnons... Aaahhhh !!
<br/>Des milliards d'insectes volants déferlèrent sur Dagonor, des insectes dont on ne discernait pas vraiment les traits, juste leur couleur rouge sang éclatante.
<br/>      -    Le stade deux... Ah, Arg... Je vous en supplie... AH !! beugla Dagonor en tombant à genoux.
<br/>Jasson ne bougeait pas devant cette scène terrifiante, ses membres ne répondaient plus : " C'est ainsi que font les dieux du mal pour se faire obéir " pensait Jasson. Complètement révolté et impuissant, le chevalier ne put faire qu'une seule chose :
<br/>      -    A L'AIDE !!...
<br/>Laziador arriva en courant, une cruche à la main, suivit des trois autres chevaliers. Avant que Jasson ait pu émettre le moindre son, Laziador sauta et balança le contenu de la cruche sur Dagonor. Des cris de douleur suivirent, les yeux rouges de Dagonor éclatèrent en sang...
<br/>      -    NON !!!! hurla Dagonor.
<br/>Jasson lut sur le sourire de son professeur : "et si...". Le Caomme était en train de fondre, le sang coulait à flot.
<br/>      -   C'ETAIT QUOI !! beugla Jasson, dans le récipient, c'était quoi !!
<br/>      -   De l'eau, dit Laziador avec fierté, la plus grande faiblesse des démons !
<br/>Jasson se précipita vers l'elfe et lui décocha une droite dans la figure. Le professeur tomba à terre et essuya le sang d'un revers de main :
<br/>      -    Tu ne vas pas bien Jasson, je pourrais te renvoyer !
<br/>      -   Pourquoi vous avez fait ça !! Il va se transformer ! Et nous allons tous les cinq MOURIR !!
<br/>Les yeux du professeur s'agrandirent :
<br/>      -    Qu'est-ce que tu racon...
<br/>Laziador n'eut pas le temps de finir parce que Dagonor le coupa avec la faible voix qui lui restait :
<br/>      -    Jasson, vous ne pouvez plus rien faire... Il faut fuir, FUYEZ !! Je ne veux pas que mon sacrifice soit vain ou que l'erreur de Laziador vous soit fatale, COUREZ. Courez sans vous arrêter et sans vous retourner... Jasson... Je t'en supplie...
<br/>Jasson regarda le reste du visage de Dagonor et vit que c'était sa dernière volonté... Et qu'il le suppliait...
<br/>Il prit alors Laziador par le bras et ordonna à ses compagnons de fuir en trainant Laziador qui ne voulait pas avancer.
<br/>      -    Allez professeur !! s’écria Jasson
<br/>      -    Lâche-moi et explique-moi !
<br/>Le chevalier lâcha son professeur et partit en courant. Il se rendit vite compte que l'elfe le suivait, et en fut soulagé.
<br/>Les chevaliers et leur professeur arrivèrent dans la cité elfique complètement essoufflés. Tombant à genoux, Jasson n'eut pas le temps de réagir que Laziador lui mettait un coup dans la figure.
<br/>      -    Je rends toujours les coups que l'on me donne ! dit l'elfe, maintenant tu vas me faire le plaisir de tout m'expliquer.
<br/>Jasson commença l'explication mais fut vite interrompu par un puissant cri qui déferlait par vague dans tous les sens, ils en conclurent que c'était Dagonor. Un moment plus tard, alors que tous les elfes étaient sortis de leurs tentes pour voir ce qui se passait, le cri stoppa net. Il fallut quelques minutes à tous pour reprendre leur esprit. Acelt s'avança vers les chevaliers, les sourcils froncés.
<br/>      -    Quel était ce bruit ?
<br/>      -   L'œuvre des dieux maléfiques... répondit Laziador, nous allons sûrement être attaqués.
<br/>Laziador expliqua tout aux elfes, dans les moindres détails.
<br/>Quelques minutes plus tard, un elfe à cheval arriva au galop. Cet elfe avait une mine pas vraiment enthousiaste, ce qui ne le privait pas d'avoir une noblesse inhumaine sur son cheval.
<br/>      -    Maître Acelt, dit l'elfe, nous avons repéré un nombre inimaginable de mercenaires du chaos qui marche en direction du Lloclavr... Nous craignions d'être leur cible.
<br/>      -    Malheureusement, je suis quasiment sûr que nous cinq sommes les cibles, affirma le professeur en désignant ses élèves. Nous avons déjà assez abusé de votre hospitalité, nous partons dès maintenant nous livrer à cette armée, ainsi il v...
<br/>      -    C'est hors de question !! lança le gouvernant avec force, nous honorerons le pacte que nos ancêtres ont fait avec les chevaliers du Sphinx !
<br/>Laziador eut un demi-sourire, que Acelt lui rendit. Le vieil elfe tourna avec style la tête vers l'elfe à cheval qui attendait toujours les ordres.
<br/>      -   Nous allons montrer à ces mercenaires que les elfes peuvent encore se battre !! Préparez notre armée !! s’écria Acelt.
<br/>Les chevaliers les regardèrent puis lancèrent d'une même voix :
<br/>      -    Nous combattrons au péril de nos vies au coté de nos alliés !
<br/>      -   De nos amis ! corrigea Laziador en regardant le gouvernant, la main levée.
<br/>Acelt leva sa main à son tour et confirma :
<br/>      -    De vos amis !...
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}