function C() { var choice = "Continuer#Corruption";var texting = `
<br/>
<br/>** Les vacances **
<br/>
<br/>
<br/>
<br/>Xalendan parcourait les couloirs du palais, le livre elfique à la main, aucun risque, tout le monde maintenant connaissait son existence. A ce propos, ça faisait maintenant deux jours qu'ils étaient revenus de la forêt, il avait pris la précaution de ne jamais se séparer de son livre. Et même, pour dormir, Xalendan mettait magiquement un genre de système d'alarme qui se déclenchait si quelqu'un d'autre était dans la chambre. Son livre, c'était tout pour lui, cet après midi là, alors qu'il marchait tranquillement son livre sous les yeux, Laziador l'attendait devant la porte de sa chambre...
<br/>Une porte bleu azur avec sur son centre, une magnifique peinture représentant des bateaux. Xalendan n'avait jamais vu en vrai ces machines de transport sur l'eau. Il n'avait d'ailleurs jamais vu l'océan.
<br/>"Ça, ce serait une chose à voir !" pensa-t-il.
<br/>      -    Comment ça va ? demanda le professeur qui le ramena sur terre.
<br/>      -    Oui... Très bien... Et... Et vous ? demanda le chevalier qui sortait tout juste de sa rêverie.
<br/>      -    Bien, je vais reprendre mes fonctions d'origine au sein de l'ordre...
<br/>      -    C'est à dire ? s’enquit le jeune homme
<br/>      -    Je m'occuperai de toute la magie !
<br/>Il paressait heureux de s'occuper à nouveau de cette matière, Xalendan voulut en savoir plus sur l'homme et commença à lui poser des questions sur sa vie. Il apprit d’abord que l'elfe avait cent quatre vingt cinq ans ! Que lui et d'autres elfes s'étaient échoués sur la rive, il était le seul survivant. Depuis, il avait intégré l'ordre et pendant un grand moment, il avait enseigné la magie. Il avait arrêté pour des raisons qu'il ne voulait pas énoncer.
<br/>      -    Tu m’as redonné envie d'apprendre la magie aux chevaliers.
<br/>Après cet aveu, l'elfe partit d'une démarche quelque peu joyeuse et Xalendan entra à la salle à manger où ses deux  frères et sa sœur d'arme l'attendaient.
<br/>      -    C'est Lazi... Le professeur sans nom qui s'occupera de la magie quand on recommencera les cours, expliqua simplement Xalendan.
<br/>      -    Lui aussi connait la langue... Et il va nous l'apprendre à mon avis, dit Jasson en entamant un bout de pain.
<br/>      -   D'où il peut bien la connaître ? s’énerva Chloé en prenant des pâtes, c'est quand même la langue des elfes, personne n'est censé la connaître en dehors d'eux !
<br/>      -    Je ne sais pas, mentit Xalendan, il ne veut pas me parler de sa vie d'avant...
<br/>Selestan le coupa en disant qu'il leur cachait quelque chose. Xalendan regarda un bol qui contenait de la sauce rouge... Avec des petits bouts de viande.
<br/>      -   Qu'est-ce que c'est ? demanda le jeune homme en montrant le bol.
<br/>Cette diversion avait permis que les autres chevaliers oublient le professeur sans nom...
<br/>      -   Cela vient de Bretonnie, répondit Chloé, c'est pour mettre avec les pâtes.
<br/>      -    La Bretonnie, c'est une ville ? demanda Jasson
<br/>      -    Non, c'est un état, comme l'Empire sauf que c'est plus petit... Je viens d'une ville là bas, expliqua Chloé.
<br/>Jasson questionna alors la jeune femme sur le pays quand une question traversa l'esprit de Xalendan.
<br/>      -    Mais... commença-t-il
<br/>Il voulait bien formuler sa phrase. Il regarda le mur fixement alors que les autres le regardait. Le chevalier prit une bouffée d'air et tourna la tête vers eux, puis il continua :
<br/>      -    Est-ce qu'il y a d'autres pays, comme celui des elfes par exemple ?
<br/>      -    Oui, je pense, affirmèrent les autres.
<br/>      -    Il faudra à tout prix demander une carte entière de notre monde au professeur, où est l'état des nains, (le pays d'origine de Magnus) par exemple ! Nous ne savons rien du monde que nous devons protéger.
<br/>Vers la fin du repas, Selestan s'exclama :
<br/>      -    Nous avons tous révélé un secret... Ah non, Jasson n'a rien dit ! Qu'est-ce que tu faisais à la bibliothèque tout le temps ?
<br/>Jasson contempla ses chaussures d'un air perdu.
<br/>      -    Ohh... Rien... soupira-t-il tristement, vous savez, je ne suis pas un très bon lecteur, alors je m’entraînait souvent à la bibliothèque.
<br/>
<br/>
<br/>
<br/>
<br/>Le lendemain matin avant le petit déjeuner, Jasson alla à la bibliothèque, dans l'espérance de voir réapparaitre ses amis. Malheureusement, la pièce était aussi vide que la première fois qu'il y avait pénétré.
<br/>      -    Rhag ! avait-t-il appelé, Rhig ! Rhoug !
<br/>      -  Qui sont Rhag, Rhig et Rhoug ? demanda malicieusement Chloé qui se tenait derrière lui.
<br/>Jasson ne l'avait pas vue arriver.
<br/>      -    Ce n'est rien...
<br/>Le chevalier se dirigea vers la porte, Chloé l'intercepta en l'attrapant fermement par les épaules. Elle le plaqua à l'aide de toutes ses forces sur le mur, Jasson se retrouva sur la pointe des pieds pour ne pas être étranglé.
<br/>      -    Quoi ! s’exclama-t-il en n'osant pas se défendre.
<br/>      -    Qui sont-ils ?
<br/>      -    Je ne vois pas de quoi tu par...
<br/>Chloé lui coupa le souffle en l'écrasant encore plus sur le mur. Jasson attrapa ses mains et les retira sèchement de son torse mais la jeune femme le griffa au passage. Il lâcha un juron devant ses mains ensanglantées puis lança un regard noir à Chloé qui resta de marbre.
<br/>      -    Réponds-moi ! menaça-t-elle.
<br/>      -   NON !! cria Jasson en colère, ses yeux pleuraient de rage... Il avait très envie de se défouler à coup de poing sur Chloé mais il se retint car il savait que sa tristesse pour la perte de ses fantômes s'était transformée en rage violente et peu contrôlable.
<br/>Malgré toute la colère qui se lisait sur le visage de Jasson, Chloé lui mit une baffe.
<br/>      -    Je t’avais prévenu !
<br/>Le chevalier lui en retourna une. Chloé, indignée, ouvrit la bouche sans qu'un son ne sorte et partit en claquant la porte furieusement.
<br/>Jasson s'assit sur une chaise et regarda les étagères remplies de livres, il attendit comme ça jusqu'à neuf heures... Songeant à ses camarades les fantômes. La colère bouillonnait maintenant dans son corps comme une soupe bout dans sa marmite. Si l'homme à l'origine de la mort de ses compagnon réapparaissait, il n’hésiterait pas à le tuer de ses mains. Le chevalier marchait à contrecœur, tête baissée, le souffle long avec des postillons qui sortaient de sa bouche, vers la grande salle à manger. Il ouvrit la porte violemment et se dirigea vers sa place, il crut entendre Chloé dire : " je vous l’avais dit... ", avant qu'il ne s'assied d'un mouvement furieux.
<br/>      -   Eh... Jasson, dit maladroitement Xalendan, ça fait maintenant trois jours qu'on est revenu de la forêt, et tu ne t'es toujours pas lavé... Tu es toujours dans les mêmes habits.
<br/>Jasson se regarda avec étonnement et dût admettre que son frère d'arme avait raison. A la fin du repas, Jasson alla dans ses appartements, puis dans la salle de bain. Comment avait-il pu oublié de se laver ! Même si en tant que paysan Jasson ne se lavait que très rarement dans son village natale, il faisait attention à son hygiène ici. Ses fantômes occupaient toute ses pensées.
<br/>Il se déshabilla lentement, quand il enleva son pantalon, une douleur aigu l'envahît, il grimaça en regardant le sang séché qui lui collait a la jambe. Le chevalier entra dans la baignoire, il ouvrit le robinet et à l’instant où l'eau toucha sa peau, il cria a plein poumon, il avait mal partout, l'eau l'avait brulé. Il sauta hors de la baignoire en hurlant, avec cette douleur qui le paralysait.
<br/>Tout à coup, il commença à trembler, à baver, il n'avait plus contrôle de son corps. Une migraine le prit. Jasson avait la tête qui tournait, puis plus rien, le trou noir, le vide,  le néant.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}