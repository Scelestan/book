function C() { var choice = "Revenir au début#Intro";var texting = `
<br/>
<br/>** Nouvelle difficulté **
<br/>
<br/>
<br/>
<br/>
<br/>      -  A la prochaine ! lança le chevalier à ses compagnons d’arme.
<br/>      -    Oui, à la prochaine Selestan !
<br/>Voila… C’est ainsi que les chevaliers Jasson et Chloé, suivis de leur professeur, Laziador, quittèrent le Lloclavr. Cette forêt ancestrale, qui était habité par des elfes. Le chevalier Selestan, à cause de ses blessures ne rentrera pas encore à la cité impériale. Le chevalier regarda ses compagnons disparaitre par-delà les arbres. Une larme coula sur sa joue, il vit encore Jasson monter son cheval, un sourire soupçonneux aux lèvres. Que de souvenirs…
<br/>      -    Ils sont partis… dit Lynaée en lui mettant la main sur l’épaule.
<br/>Selestan la regarda, encore une fois impressionné par sa beauté.
<br/>Le monstre géant, Alvin le roi de la forêt, vint se placer derrière le jeune homme.
<br/>      -  Malgré la semaine qui s’est déroulée, la mort du chevalier Jasson n’est pas du tout oubliée, dit Alvin. J’aurais aimé le connaitre, cet homme.
<br/>      -    Moi aussi, souffla Selestan en sanglot.
<br/>      -    Comment ça ? demanda le géant, étonné.
<br/>Selestan leva la tête vers le ciel et répondit :
<br/>      - Je ne le connaissais pas, malgré nos nombreuses discussions ! C’était un homme droit, sérieux et fier… Malgré son ironie continuelle.
<br/>Un elfe arriva à cheval :
<br/>      -    Acelt, le roi des elfes sylvains désire que vous vous entreteniez avec lui.
<br/>Selestan quitta Alvin et Lynaée afin de se diriger vers la tente du chef.
<br/>      -    Que me voulez-vous ? demanda Selestan aimablement.
<br/>L’elfe l’invita à s’asseoir en face de lui.
<br/>      -    Chevalier, connaissez-vous l’existence des Magicianna ?
<br/>      -    Oui, Laziador nous a expliqué leur pouvoir il y a peu.
<br/>      -    Dites-moi alors, à quoi elles servent et ce qu’elles sont.
<br/>Selestan expliqua à l’elfe ce que son professeur leur avait enseigné.
<br/>      -   Je vois, vous et les autres chevaliers en détenez une, mélangée à votre âme. Je vais vous apporter mes connaissances, chevalier :
<br/>Toutes les Magicianna ont une nature magique différente. D’après moi, le chevalier Jasson avait une Magicianna qui avait la faculté de la guérison. Connaissez-vous la nature de votre Magicianna ?
<br/>Le chevalier répondit négativement.
<br/>Acelt ouvrit un tiroir et en sortit une feuille. Il la positionna à plat sur la table puis expliqua :
<br/>      -    Posez à plat votre main sur la feuille, elle vous révélera la nature de votre Magicianna.
<br/>Selestan s’exécuta, quand il retira sa main, un sigle s’était inscrit sur la feuille.
<br/>Acelt parut étonné… Puis déchiffra :
<br/>      -    Vous avez la faculté de la terre et de la forêt.
<br/>Acelt expliqua brièvement cette faculté, puis Selestan sortit de la tente.
<br/>      -  Quel heureux hasard, cet humain peut exécuter notre magie ! s’exclama l’elfe une fois tout seul.
<br/>Alvin attendait Selestan à l’extérieur, celui-ci le regarda.
<br/>      -   De ce que j’ai entendu, tu as la faculté d’utiliser notre magie, celle des elfes sylvains… dit-il.
<br/>      -    Quoi ?! Votre magie !
<br/>      -  Oui, ta Magicianna est de type terre, comprenant la forêt… Tu peux ainsi utiliser nos sortilèges, et même les plus puissants. Je vais te présenter à un de nos enchanteurs, elle te testera.
<br/>Le chevalier gloussa, rencontrer un enchanteur était pour lui plus qu’un défi… Ces personnes à la puissance sans limite qu’il avait aperçues lors de la bataille l‘effrayait plus que tout. Leur yeux brillants et impassibles détournaient les yeux de quiconque les regardait.
<br/>Selestan suivit donc Alvin dans la forêt, et ce n’est qu’après plusieurs heures de marche que l’on commença à apercevoir au loin une petite cabane construite dans un grand chêne.
<br/>      -   C’est ici que je te laisse. A toi d’atteindre le grand chêne, à présent, dit le géant au chevalier.
<br/>Selestan était assez intelligent pour savoir que ce bout de chemin n’allait pas être une partie de plaisir. Par rapport à la route qu’il avait empruntée avec Alvin, celle qu’il avait devant lui été parsemée de ronces, d’orties et d’épines.
<br/>Quand le jeune homme se tourna pour demander le chemin au géant, celui-ci avait disparu. Selestan fronça les sourcils. Il commença à avancer… Finalement, la randonnée ne fût pas si dure que ça, mais quand il voulut regarder la cabane pour savoir s’il avait bien avancé, il se rendit compte qu’il n’avait pas bougé du tout. Il regarda autour de lui et s’aperçut qu’il était revenu au point initial.
<br/>      -    Bizarre… lâcha le chevalier, il me semblait pourtant que j’avançais.
<br/>Il fixa la cabane avec attention, ses blessures commençaient à se rouvrir. « Où est le piège ? ». Mais aucune réponse ne lui vint à l’esprit. Il repensa à leur professeur et essaya de penser comme lui. Un demi-sourire apparut sur son visage. Il s’assit sur le sol et posa la main par terre en demandant à la magie de lui indiquer l’heure. Un cadrant bleu apparut sur sa main pour la lui révéler. D’après lui, il avait marché deux heures depuis le départ d’Alvin. Il prit un bâton et regarda la cabane, puis il commença à calculer le temps qu’il faudrait pour atteindre l’arbre. Il grattait de temps en temps des chiffres sur le sable avec sa branche. Etant un fils de marchand, Selestan avait toujours eu une grande connaissance des nombres et des mathématiques. D’après ses calculs, il devrait déjà être arrivé, puisque le temps qu’il faut pour atteindre l’arbre est deux heures et qu’il a marché à une vitesse normale pendant justement deux heures. Il se leva souplement et se hissa sur ses pieds. La manière de penser de Laziador l’avait sauvé, puisque les yeux ne voient d’après leur professeur que la surface des choses.
<br/>      -    Enchanteur ! lança le chevalier, bien le bonsoir à vous !
<br/>Le décor changea et la cabane apparût juste derrière lui.
<br/>      -  J’avais donc bien raison, c’était une illusion… dit le chevalier sans se retourner.
<br/>
<br/>
<br/>
<br/>
<br/>Chloé était sortie de la forêt avec Xalendan et leur professeur, ils avaient déjà fait ce chemin, donc il leur était facile de ne pas se perdre, bien qu’il n’y ait eu aucun problème de ce genre même à l’aller puisque Laziador avait un très bon sens de l’orientation. Cela rappela à Chloé la raison de leur venue dans ces lieux éloignés. C’était à la base pour sauver Jasson… Et non pour qu’il se sacrifie. Une petite larme coula sur la joue de la jeune femme. Le cœur de la chevalière était devenu telle une pierre, flegmatique. Aucune autre larme ne roula, malgré les pensées néfastes de Chloé.
<br/>Un visage neutre, sérieux et réservé : ce n’était plus la Chloé d’avant. Elle avait vu des choses auxquelles même les plus âgés n’avaient jamais songé. Un regard de marbre, traversé par la vie qu’elle voulait depuis qu’elle était petite. Celle du chevalier, n’est autre que la souffrance et la mort. Jasson en est l’exemple, il avait un rêve, tout comme Selestan, Xalendan et Chloé, devenir chevalier. Un rêve devenu réalité, pour lui, pas très longtemps. Chloé serra les dents, un enfant est naïf et irréfléchi… Si Jasson n’était pas devenu chevalier, il serait encore en vie. Mais à quoi bon s’attarder sur le passé, Chloé avait eu du mal à réaliser au début : mais Jasson n’existe plus, il fait maintenant partie des souvenirs.
<br/>      -    Jasson… Chloé, j’aimerais t’en parler, dit Laziador en ralentissant l’allure de son cheval.
<br/>La jeune femme le regarda sans expression.
<br/>      -    Jasson et toi aviez des Magicianna dites « amoureuses ». Cela fait longtemps que j’y songe, je pensais vous en parler après la guerre. Mais malheureusement le temps change les choses. Je pense que vous n’étiez pas réellement amoureux l‘un de l‘autre ; mais que c’était vos Magicianna qui vous donnaient l’impression de connaître l’amour…
<br/>      -    J’AIMAIS JASSON !! s’égosilla Chloé en sanglotant.
<br/>La rage dans ses yeux ne reflétait qu’une partie de ce qu’elle ressentait. Et si tous ses sentiments explosaient, Jasson ne serait pas là pour la calmer. Laziador l’avait très bien compris, c’est pour cela qu’il dit :
<br/>      -   Il était également possible que vos Magicianna soient reliées et que vous vous aimiez aussi. Mais nous ne le saurons jamais…
<br/>Chloé sécha ses larmes, elle pourra autant qu’elle le voudra penser qu’elle a oublié Jasson, la jeune femme n’oubliera jamais… Ce jeune homme.
<br/>La route qu’ils étaient en train de parcourir était déserte jusque-là, mais le soir venu, un charriot tiré par des bœufs avançait dans la direction opposée. L’homme arrêta la charrette devant eux et descendit.
<br/>      -  Vous ne vous rendez tous de même pas à l’empire ? demanda-t-il.
<br/>      -   Pourquoi ? Nous ne devrions pas ? questionna Xalendan.
<br/>      -    L’empereur a été assassiné, dit l’homme.
<br/>Laziador fronça les sourcils, les deux chevaliers parurent surpris. L’homme les regarda l’air effrayé.
<br/>      -   Quoi ! Vous n’étiez pas au courant, c’était avant-hier. Maintenant l’empire vit sous dictature, c’est pour cela que moi-même je déménage…
<br/>      -   Que diriez-vous de partager notre repas ? demanda soudain le professeur.
<br/>L’homme fut surpris de cette demande directe mais accepta malgré tout. C’est vrai qu’il était l’heure de manger, et les chevaliers s’assirent par terre pour se remplir le ventre.
<br/>      -  Pourrions-nous connaître votre nom ? demanda le professeur.
<br/>      -    Gauvin.
<br/>      -   Dites-nous tout ce que vous savez sur ce qui s’est produit s‘il vous plait, dit Laziador d’un ton aimable.
<br/>      -   Bien, bien, reprit l’homme, donc avant-hier soir, alors que l’empereur prenait son repas… Un coup d’état fût lancé, dans l’étonnement le plus total, les chevaliers furent débordés par cette attaque. A ce qu’il parait, ce n’étaient pas quelques soldats qui accompagnaient le dictateur, mais une troupe entière de mages redoutables et de guerriers puissants. La bataille dura toute la nuit, et alors que le roi tentait de s’échapper, le dictateur, d’un poignard, trancha la tête de l’empereur. Il se désigna ensuite comme roi légitime… Mais j’y pense, pourquoi tout cela vous intéresse-t-il tant ?
<br/>      -    Sans vous mentir, nous sommes des chevaliers revenant de mission, dit Laziador d’un ton neutre.
<br/>L’homme parut effrayé. Puis il prit un rouleau de parchemin dans son charriot qu’il étala par terre. Sur ce parchemin était dessiner trait pour trait Laziador, Chloé, Xalendan, Selestan et Jasson. Voir une nouvelle fois le visage du jeune homme retourna l’estomac de Chloé qui vomit un peu de son repas.
<br/>      -    Vous êtes les chevaliers du Sphinx ! s’écria avec autant de crainte que d’admiration l’homme. La prime pour votre capture et de cent mille pièces d’or !
<br/>Les yeux des deux compagnons et de leur professeur s’écarquillèrent. Ils n’étaient pas censés connaitre l’existence des chevaliers du Sphinx.
<br/>      -  Mais… Vous n’êtes que trois et le parchemin dit clairement qu’il y a cinq personnes ! Vous êtes les seuls chevaliers encore en vie ! Vous êtes les seuls à pouvoir sauver l’empire ! C’est ce que le dictateur a dit très précisément dans son discours, mais que pour ce faire il faudrait qu’il y ait minimum les quatre chevaliers. C’est pour cela qu’il a mis cette prime en place, afin que sa seule crainte soit réduite à néant.
<br/>      -    La prime ne vous intéresse-elle pas ? demanda Laziador.
<br/>      -   Même si je gagnais cet argent, qu’est-ce que j’en ferais ? C’est bien trop pour un vieil homme comme moi qui a bien vécu sa vie. Et puis vous êtes nos sauveurs, aux habitants de l’empire.
<br/>Plus de chevalier vivant, cela voulait dire que tous les professeurs que la chevalière avait appris à connaître n’étaient plus de ce monde ! Chloé se sentit de plus en plus mal.
<br/>      -    Mais malheureusement… commença l’elfe, le chevalier Jasson de l’ordre du sphinx n’est plus parmi les vivants. Et le chevalier Selestan a été gravement blessé. Donc il n’y aura que deux chevaliers pour redresser l’empire du Sphinx ! Heureusement le verrou de la planète n’est plus actif !
<br/>Les deux chevaliers hochèrent la tête, il s‘était en effet aperçu de cela il y a plusieurs heures déjà…
<br/>
<br/>
<br/>
<br/>
<br/>Selestan regardait l’étendue des arbres qui se déroulait jusqu’à l’horizon invisible. Dos à la cabane de l’enchanteur, le chevalier attendait comme ça depuis plusieurs heures, sans s’être retourné une seul fois.
<br/>      -  Apparemment, tu as trouvé la cabane, c’est plutôt pas mal, dit une voix inconnue.
<br/>Une voix aussi douce et cristalline ne pouvait exister, aussi Selestan se retourna et put admirer l’elfe qui se trouvé devant lui.
<br/>      -  Nous allons jouer à cache-cache, si tu me trouves, je réfléchirai peut-être à l’enseignement que je vais pouvoir te donner, dit l’elfe d’une voix qui ressemblait plutôt à un chant.
<br/>Selestan perçut tout de suite la difficulté de l’exercice : l’elfe connaissait ce bout du Lloclavr mieux que quiconque et le jeune homme savait que la chercher serait une perte de temps. C’était tout bonnement impossible.
<br/>      -    Le nombre de personnes ayant trouvé la solution pour trouver la cabane, équivaut à peu près à vingt-cinq pourcent de celles qui ont essayé. Et le pourcentage de personnes m’ayant trouvée est de deux pourcent. Bonne chance… souffla la voix magnifique de cet être splendide.
<br/>Elle disparut une seconde plus tard, sous les yeux étonnés de Selestan. Il se rendit d’abord à l’endroit où elle avait disparu, quelquefois qu’elle n’ait fait que se rendre invisible. Malheureusement ce n’était pas la bonne solution. Elle n’a pas donné de limite de temps, se dit Selestan, donc tôt ou tard, je finirai par la trouver. Cette pensée s’évanouit presque aussitôt, trouver un elfe dans un bois comme le Lloclavr, la forêt la plus grande du monde… ça n’allait pas être une partie de plaisir. Il commença à chercher…
<br/>
<br/>
<br/>
<br/>
<br/>L’homme regarda les deux chevaliers, l’air surprit.
<br/>      -  Vous devez comprendre que votre ennemi est d’une puissance extrême, avertit-il vers le professeur.
<br/>      -  Même si nous devons tous mourir, nous aurons tout essayé, et rien à nous reprocher, lança l’elfe, à l’exemple de Jasson !  Lui, il avait compris le sens de chevalier du Sphinx.
<br/>Xalendan pencha la tête vers le sol, le regard vide. Laziador recommanda à tout le monde de se reposer, car le lendemain ils galoperont toute la journée.
<br/>      -   Tant qu’à faire, dit l’homme, je vais rester avec vous pour la nuit.
<br/>Les yeux fermés des chevaliers ne trahissaient d’aucune sorte toutes les épreuves qu’ils avaient traversées, ni celles qu’ils allaient traverser.
<br/>« Touche moi… touche moi… »
<br/>Gauvin ouvrit un œil, la nuit était noire.
<br/>L’homme ronronna avant de se rendormir. Une hallucination était possible avec tout le travail qu’il faisait.
<br/>« Attrape-moi… Attrape-moi… »
<br/>Gauvin ouvrit un œil qu’il referma aussitôt. Une goutte de sueur coula sur sa joue, un rêve, ce n’était qu’un rêve !
<br/>« N’aie pas peur…Prends moi dans ta main… »
<br/>L’homme se leva et regarda en tremblant autour de lui.
<br/>« Je suis là… »
<br/>Il aperçut le sac du professeur qui brillait d’un vert foncé. Gauvin courut vers celui-ci et vida son contenu sur le sol. Une pierre verte émeraude en sortit parmi tout le reste. Elle brillait malgré la nuit, l’homme tendit la main vers la pierre. Puis il hésita.
<br/>« Non… N’aie pas peur… Touche-moi… »
<br/>La main de Gauvin finit son trajet et toucha la pierre… Au contact de la sphère, l’homme émit un hurlement d’une puissance inhumaine. La pierre sembla fondre. Et des ailes se dressèrent sur le dos de l’homme, et ses ongles devinrent griffes. Sous les cris, les chevaliers et Laziador se réveillèrent, assistant à la renaissance… D’un sorcier du mal.
<br/>      -    Tu croyais vraiment pouvoir me battre ! Héritier elfe !
<br/>L’épée elfique de Laziador se matérialisa. Le démon éclata de rire. Chloé comprit tout de suite ce qui s’était passé, et tourna la tête afin de trouver de l’eau. Xalendan de son coté ne comprenait absolument rien, mis à part le fait qu’ils étaient en danger, il prit sont épée. Le sorcier leva la main et prononça des paroles indéchiffrables. Toutes les gourdes des chevaliers éclatèrent et l’eau s’étala sur le sol.
<br/>      -  Jeune femme ! Tu m’as eu la dernière fois, mais maintenant c’est finit !
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>20.
<br/>
<br/>** L’enchanteur **
<br/>
<br/>
<br/>
<br/>Cela faisait plus de deux heures que Selestan parcourait la forêt sans résultat. Ses blessures lui faisaient mal, il était épuisé. Il s’arrêta, il y avait forcément une solution. Assis sur le sol, le chevalier médita, c’était au cours de Laziador en tant que professeur d’adaptation aux lieux que le jeune homme avait appris à faire le vide dans son esprit. Il laissa libre cours à son instinct pour trouver la réponse. Une heure passa, Selestan n’avait encore aucune idée. Le vent caressa sa joue, le chevalier ouvrit subitement les yeux.
<br/>Sa Magicianna était celle de la terre ! Il se leva et joignit les mains, cherchant la puissance de sa Magicianna au plus profond de lui. Prête-moi tes pouvoirs ! Une douleur l’envahît, il cria. Une lumière verte s’échappa de son corps. Il délia ses mains, la lumière s’envola et sa douleur s’évapora. Des voix, il entendait des voix partout, insupportable, c’était trop. Il se prit la tête entre les mains.
<br/>      -    TAISEZ-VOUS !! A L’AIDE !!
<br/>Un bruit et un arbre sortit du sol, ses racines lui servant de pied, comme lors de la guerre.
<br/>      -    Calme-toi… dit une voix grave.
<br/>Il tomba à genoux et s’évanouit.
<br/>Quand il se réveilla, il était couché sur un arbre.
<br/>      -    Comment vas-tu ? demanda la voix grave.
<br/>Selestan comprit, c’était l’arbre qui parlait !
<br/>      -    Je… Je… Je ne sais pas… commença le chevalier.
<br/>      -    Pourquoi m’as tu appelé ?
<br/>Le jeune homme fût surpris, il ne sut pas quoi répondre.
<br/>      -    Je… Je ne comprends rien ! Comment j’ai fait ?
<br/>L’arbre sembla rire.
<br/>      -   C’est bien ma veine, me prendre un apprenti magicien, dis moi en quoi je peux t’aider.
<br/>Selestan se souvint de l’enchanteresse, et demanda à l’arbre s’il pouvait lui indiquer où elle était.
<br/>      -    Je vois… dit l’arbre d’une voix triste, tu es vraiment sûr de le vouloir.
<br/>      -   Oui ! s’exclama le chevalier heureux d’avoir trouvé par chance la solution.
<br/>Une onde sonore partit dans toutes les directions.
<br/>      -    L’enchanteresse est juste derrière toi, derrière ce gros arbre, en train de te surveiller. Mais je te préviens elle ne va pas y rester longtemps.
<br/>Selestan bondit soudain comme un chat et arriva au sol, il courut comme un fou et trouva l’elfe assise tranquillement derrière l’arbre.
<br/>      -    Enfin, dit-elle, ce n’est pas trop tôt !
<br/>      -  Vous… Vous !… Comment… je n’avais pas remarqué que vous étiez derrière moi, vous m’avez suivi tout le temps !
<br/>L’enchanteresse eut un petit sourire et hocha positivement la tête puis dit :
<br/>      -    Je trouve ce test plus facile que le précédent… Pourtant la réussite jusqu’à maintenant n’a été que de deux pourcent et pour trouver ma cabane, le résultat est de vingt-cinq pourcent. En clair, le nombre de personnes étant arrivées jusqu’ici  s’élève à cinq personnes toi compris. Tu as terminé les tests, nous allons passer à la première leçon. Si tu loupes l‘exercice, je ne poursuivrai pas ton apprentissage. Le pourcentage de réussite de la première leçon s’élève à… Zéro pourcent.
<br/>Les yeux du chevalier s’agrandir, il n’en pouvait plus, ses blessures le martyrisaient. Malgré tout, Selestan demanda en quoi consistait cet exercice.
<br/>      -    Tu va devoir me prouver que tu es digne d’être mon élève lors d’un combat contre moi, répondit en toute simplicité l’elfe.
<br/>Une goutte de sueur traversa le visage du chevalier. Combattre contre… une enchanteresse. Elle sortit son épée, le jeune homme prit la sienne. Le combat commença, dés les premiers coups d’épée, l’elfe prit le dessus avec une facilité sensationnelle. Le jeune homme reculait en contrant du mieux qu’il le pouvait l’épée de l’elfe. Même Xalendan aurait été désorienté face à cette puissance.
<br/>      -    Tu es lent, dit l’enchanteresse blasée, je ne suis même pas à zéro virgule un pourcent de mes capacités.
<br/>Cette révélation horrifia le jeune homme, qui étaient donc ces êtres !
<br/>L’elfe disparut, Selestan se retourna le plus vite qu’il put, mais elle n’était plus la.
<br/>      -    Ici !
<br/>      -    Quoi ! s’exclama le chevalier en levant la tête.
<br/>SLASH !! L’épée de l’elfe écorcha le garçon au bras. Le sang coula sur ses vêtements, Selestan regarda l’enchanteresse les yeux grand ouverts, elle ne rigolait pas. Il la regarda essuyant son épée. Le visage de l’elfe était impassible, ces êtres étaient des démons ! Leurs jolis visages n’étaient là que pour tromper leurs adversaires… ils étaient effrayants ! L’elfe tendit la main vers l’avant. Les feuilles mortes s’envolèrent en tournoyant vers Selestan.
<br/>      -    FEU !! s’écria le chevalier.
<br/>Rien ne se passa, le verrou de la planète était actif. Selestan se prit de plein fouet l’attaque de l’enchanteresse, les feuilles paraissaient aiguisées et dures, puisque elles coupèrent le jeune homme tout le long de son corps. Ses habits s’imbibèrent de son sang. Il retira son tee-shirt en hurlant de douleur, l’elfe avançait vers lui avec grâce et douceur. Elle caressa la joue du jeune homme :
<br/>      -    Je ne pensais pas que tu étais si faible, tu peux abandonné maintenant. En plus, le verrou de la planète n’était plus actif, c’est cet endroit qui n’accepte pas le relais de la magie par la planète.
<br/>Selestan serra les dents, il ne faisait pas le poids… Mais il n’abandonnerait pas !
<br/>Sa main partit à une vitesse hallucinante et vint claquer contre la joue de l’elfe. Elle cracha un peu de sang.
<br/>      -    Je n’abandonnerai pas ! Je vais te battre !! hurla le chevalier avec assurance.
<br/>Cette assurance n’était pas celle de ses pensées. Il regarda l’enchanteresse avec rage, elle restait impassible. Cela énerva encore plus le chevalier qui cria en prenant son épée.
<br/>Il chargea ! L’elfe esquiva l’attaque aisément, mit un coup de talon sur la jambe de son adversaire, puis son épée glissa sur le bord du ventre de Selestan. Il tomba à genoux, ses anciennes blessures s’étaient ouvertes et le sang coulait à flot. Sa nouvelle blessure au ventre le vida de son sang, malgré tout, il se releva en tremblant. Levant son épée, Selestan reçut le plat de l’épée de son adversaire dans la figure.
<br/>      -    Abandonne, ça m’évitera de te tuer.
<br/>Du sang sortait de la bouche du chevalier, il aurait été préférable d’abandonner, effectivement. Mais…
<br/>      -    Allez vous faire voir ! Maître ! s’exclama-t-il avec un demi-sourire voilé par le sang.
<br/>Le visage flegmatique de l’elfe regarda le chevalier au sol. Elle leva son épée.
<br/>      -    Très bien… lança-t-elle.
<br/>Une fumée verte provenant de Selestan s’éleva dans le ciel.
<br/>      -    AAAHHHH !! s’égosilla tout à coup le garçon en levant la main.
<br/>L’elfe fronça légèrement les sourcils, le jeune homme la regarda avec les yeux de la colère, ce n‘était pas les siens. Selestan rigola, d’une voix qui n’était pas la sienne non plus.
<br/>      -    Prends ça ! lança-t-il de cette même voix inconnue.
<br/>Un pic de pierre sortit du sol et se planta dans le dos de l’enchanteresse. Prise par surprise, elle ne put rien faire. De plus la vitesse de l’attaque l’avait laissé impuissante. Ses yeux dévoilait son étonnement, son visage trahissait ses pensées, pour la première fois. La fumée verte disparut, et Selestan revint à lui.
<br/>      -  Qu’est-ce qu’il s’est passé, je ne me contrôlais plus, effrayant ! dit-il.
<br/>Il regarda l’elfe, prit son épée et la tendit à son coup.
<br/>      -  Quoi qu’il se soit passé, j’ai gagné et il vous faut abandonner !
<br/>L’enchanteresse lui renvoya un rire moqueur.
<br/>      -    Je n’abandonnerai pas ! Tue-moi alors.
<br/>Les yeux du chevalier s’écarquillèrent et tout à coup,  il comprit le jeu de l’elfe. Depuis le départ il n’avait aucune chance ! Puisque s’il la tuait, il n’aurait pas de formation, et s’il ne la tuait pas : il ne gagnait pas. Donc pas de formation non plus. Il se crispa sous les mots de l’elfe, tremblant de tout son corps. L’enchanteresse eut un sourire et regarda le jeune homme droit dans les yeux, un air de défi sur le visage. Plus personne ne bougea, plusieurs heures passèrent, il faisait maintenant nuit noire. Tout à coup, le jeune homme se détendit, il planta son épée sur le sol. Le sang de l’elfe coulait encore, elle n’en avait plus pour très longtemps, mais lui non plus ne résisterait plus très longtemps, à cause de ses blessures. Il sourit en regardant l’elfe. Elle n’avait pas détourné les yeux une fois depuis le début.
<br/>      -    Pourquoi est-ce que ce serait nous qui devriont choisir le vainqueur ? Plutôt que de vous tuez, je vais demander un vote aux spectateurs afin qu’ils déterminent qui est le gagnant.
<br/>L’elfe sembla surprit :
<br/>      -    Quels spectateurs ?
<br/>Sa voix était celle de d’habitude, malgré sa blessure profonde. Cela désorienta le chevalier, mais il répondit en montrant la forêt :
<br/>      -    Ceux-là !
<br/>Les yeux de l’enchanteur s’écarquillèrent. Selestan appela la forêt, allant chercher au plus profond de lui… sa Magicianna. Les arbres bougèrent, les animaux arrivèrent. L’elfe regarda le chevalier avec admiration.
<br/>      -    Que ceux qui pensent que le maître a gagné, aillent à droite et que ceux qui pensent que j’ai gagné se mettent à gauche !…
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>21.
<br/>
<br/>**Est-ce la fin ?**
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>      -    Suis-je mort ?
<br/>Jasson regarda autour de lui. Il était dans un monde sans couleur, sans noir ni blanc, entièrement vide et dépourvu de vie. Un monde sans horizon, sans fin. Un homme apparut devant lui.
<br/>      -    C’est ainsi que l’on nomme… L’infini…
<br/>
<br/>
<br/>***

<br/>c'est alors que cette quête..
<br/>je ne l'ai imaginé, 
<br/>peut être...
<br/>que nos coeur lié, 
<br/>pouvait chanter, ou pas,
<br/>ça l'était déjà,
<br/>et demain sera,
<br/>toujours un cas. 
<br/>Contre toute attente...
<br/>L'année suivante,
<br/>notre volonté,
<br/>allez.
<br/>elle fléchiera,
<br/>ou pas,
<br/>ça reviendra...
<br/>comme ça,
<br/>des fois...
<br/>sans avoir le choix,
<br/>on fait d'elle, 
<br/>un roi. 
<br/>Comme attiré vers le ciel ! 
<br/>Sans qu'elle soit là..
<br/>focalisé, 
<br/>on ne sait pas...
<br/>qu'on - se fait vrillé ! 
<br/>Elle ne peut... 
<br/>elle ne peut...
<br/>être que belle ! 
<br/>ça pardonne pas;
<br/>à ce choix indescent 
<br/>inexistant 
<br/>presque sans voie, 
<br/>on voie.
<br/>Que celui qui te protège n'est pas là...
<br/>quand je pense à toi
<br/>si j'abrège, ça donne l'amour en une forme 
<br/>contraste 
<br/>sans une pomme révélé dans l'orme 
<br/>si chaste...
<br/>elle nous allège cette sensation, 
<br/>communication,
<br/>paralèlle et belle... 
<br/>Comme si l'auteur devenait grelle 
<br/>cette année là,
<br/>je n'ai pas pensé à toi,
<br/>une seule fois. 
<br/>malgrés l'obcénité,
<br/>de ce que j'ai fais...
<br/>tu as pensé à moi,
<br/>comme autrefois...
<br/>En parlant d'un faux semblant, 
<br/>sincèrement.
<br/>
<br/>その時、このクエストは...
<br/>想像もしていなかった、多分...
<br/>私たちの心が縛られ、歌うことができた...
<br/>離れて...
<br/>あなたは理解していません、それはすでにありました、そして明日はいつもそうです。すべての可能性に対して...
<br/>翌年、私たちの意志は行きます。曲がるかどうかは別として、戻ってきます...
<br/>そのように、時々...
<br/>選択の余地なく、私たちは彼女を王にします。空に向かって描かれるように！彼女がそこにいなくても。
<br/>
<br/>焦点を合わせて、私たちは知りません...
<br/>私たち-ねじれる！彼女はできません...
<br/>彼女は美しいだけです！それは許しません。
<br/>この先天的な存在しないほとんど道のない選択に、私たちはあなたを保護する保護者がそこにいないことがわかります...
<br/>あなたを想うとき、短くすると、貞淑なニレにリンゴが出てこない、コントラストのない形で愛を与えてくれます...
<br/>それは、この並行した美しいコミュニケーションの感覚を和らげます...
<br/>偽物の似顔絵といえば、あたかもその年に作者がグレルになったようで、一度もあなたのことを考えたことはありませんでした。私がしたことの猥褻にもかかわらず...
<br/>あなたは前と同じように私のことを考えました...
<br/>心から。
<br/>
<br/>Sonotoki, kono kuesuto wa... 
<br/>Sōzō mo shite inakatta, tabun... 
<br/>Watashitachi no kokoro ga shibara re, utau koto ga dekita... 
<br/>Hanarete... 
<br/>Anata wa rikai shite imasen, sore wa sudeni arimashita, soshite ashita wa itsumo sōdesu. Subete no kanōsei ni taishite... 
<br/>Yokunen, watashitachi no ishi wa ikimasu. Magaru ka dō ka wa betsu to shite, modotte kimasu... 
<br/>Sonoyōni, tokidoki... 
<br/>Sentaku no yochi naku, watashitachi wa kanojo o ō ni shimasu. Sora ni mukatte egaka reru yō ni! Kanojo ga soko ni inakute mo.
<br/> 
<br/>Shōten o awasete, watashitachiha shirimasen... 
<br/>Watashitachi - nejireru! Kanojo wa dekimasen... 
<br/>Kanojo wa utsukushī dakedesu! Sore wa yurushimasen. Kono sententekina sonzaishinai hotondo michi no nai sentaku ni, watashitachi wa anata o hogo suru hogo-sha ga soko ni inai koto ga wakarimasu... 
<br/>Anata o omou toki, mijikaku suru to, teishukuna nire ni ringo ga detekonai, kontorasuto no nai katachi de ai o ataete kuremasu... 
<br/>Sore wa, kono heikō shita utsukushī komyunikēshon no kankaku o yawaragemasu... 
<br/>Nisemono no nigaoe to ieba, atakamo sono-nen ni sakusha ga gureru ni natta yō de, ichido mo anata no koto o kangaeta koto wa arimasendeshita. Watashi ga shita koto no waisetsu nimokakawarazu... 
<br/>Anata wa mae to onajiyōni watashinokoto o kangaemashita... 
<br/>Kokoro kara.

`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}