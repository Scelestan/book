function C() { var choice = "Continuer#FinTome1";var texting = `
<br/>
<br/>** Première bataille pour les chevaliers **
<br/>
<br/>
<br/>
<br/>Le lendemain matin, Chloé, Jasson, Xalendan et Selestan étaient en tenue de combat. D'après les ingénieurs elfes, il y avait plus de dix mille mercenaires qui s'étaient rassemblés ; d'après eux, la chance de vaincre est de cinq pour cent. Autant dire qu’ils étaient en mauvaise posture.
<br/>Les quatre chevaliers étaient assis autour d'un feu, personne ne parlait. Tout le monde étant perdu dans ses pensées.
<br/>Laziador arriva, avec sa tenue habituelle (ce qui surprit les chevaliers qui s’attendaient à le voir en tenue de combat). Il s'assit avec les chevaliers, plongé dans ses pensées.
<br/>      -    Nous sommes dimanche... lança t-il.
<br/>Tous le regardèrent avec un air étonné.
<br/>      -    Vous savez tous que la magie a été verrouillée par la planète ?... (Jasson avait été informé la veille, ça l'avait laissé stupéfait pendant de longues minutes.)
<br/>Les chevaliers hochèrent la tête.
<br/>      -    Seulement, la planète ne peut pas verrouiller la magie le dimanche de midi à minuit. Et d'après les ingénieurs, la bataille débuterait vers midi et demi...
<br/>      -    ça veut dire qu'on pourra utiliser la magie pendant la bataille ! s'écria Xalendan d'un air réjouit.
<br/>Un nouveau silence s'installa pendant lequel les chevaliers attendaient la confirmation de leur professeur. Celui-ci avait l'air préoccupé.
<br/>      -   Exactement Xalendan, nous pourrons utiliser la magie pendant la bataille... Mais je ne sais pas si c'est à notre avantage...
<br/>      -    Que voulez-vous dire ? Demanda Chloé.
<br/>Le professeur eut une longue inspiration.
<br/>      -    Si le verrou pour la magie n'est pas activé, ça veut dire que l’on peut utiliser la magie... Mais nos ennemis aussi. C'est ce qui m'énerve, les mercenaires ont choisi d'attaquer à un moment comme celui-ci.
<br/>Jasson dit alors que cela tournait à leur avantage car les elfes savent très bien utiliser la magie.
<br/>      -    Les elfes sylvains utilisent une forme de magie qui peut opérer même avec le verrou de la planète, dit Laziador.
<br/>Les chevaliers regardèrent leur professeur avec étonnement et considération.
<br/>      -    Le Chaos comprend des sorciers avec des pouvoirs cent fois supérieurs au mien. Seulement ces pouvoirs ont besoin du relais de la planète, donc les sorciers sont vulnérables si la planète met son verrou. Je crains que le chaos ne nous ait envoyé un de ces sorciers, pour eux, ce serait logiquement la meilleure stratégie à prendre. Ils ont à mon avis aussi envoyé l'humain qui a trahi les elfes, pour qu’il puisse contrer la magie des elfes sylvains. Puis quasiment tous les mercenaires du chaos ont les bases de la magie que vous connaissez. Je crains que cette bataille ne soit un suicide pour nous... Mais bon... Nous n'avons pas d'autre choix, alors tenez-vous prêts !
<br/>Sur ce, Laziador se leva et partit. Il leur confia qu’il allait chercher le chef des elfes sylvains.
<br/>Tout le monde était dans un état de stress extrême, c'était leur première bataille. Chacun dans une concentration ultime, les chevaliers préparaient des stratégies d'attaque et de défense. Midi arriva très vite, c'est à ce moment que le stress fut le plus intense. Exactement comme l'avait annoncé Laziador, les chevaliers réussissaient à pratiquer la magie.
<br/>Jasson crut que son estomac s'était retourné quand un elfe vint leur dire que la bataille allait commencer et qu’il fallait se mettre en place.
<br/>      -    Quelle place ? s’étonnèrent les chevaliers.
<br/>Acelt et Laziador arrivèrent à ce moment-là. Laziador prit soin de s’asseoir devant ses élèves, il commença :
<br/>      -  Selestan prendra le commandement d'une escouade d'archers à cheval, je crois me souvenir de tes performances d'archer et de ta maîtrise à cheval.
<br/>Selestan hocha la tête positivement. Il était étonné de prendre un poste de commandement alors que c'était sa première bataille. Surtout que Selestan n'avait combiné l'arc et l'équitation que deux fois...
<br/>      -   Xalendan prendra le commandement d'une escouade d'épéistes... Avec laquelle tu pourras utiliser autant la magie que l'épée.
<br/>Xalendan fit la grimace mais hocha malgré tout la tête.
<br/>      -    Chloé, tu feras de ton mieux pour mettre ta magie au service de la défense en tant que commandant d'une escouade d'archers à pied.
<br/>Chloé hocha la tête.
<br/>Acelt posa à ce moment là un livre devant Chloé.
<br/>      -    C'est un livre semblable à celui de Xalendan, informa celui-ci, tu pourras comme ça utiliser le langage elfe. Tu devras cependant me le rendre à la fin de la bataille, ces livres se font rares et il nous faut garder ceux qu’il nous reste.
<br/>Laziador reprit en regardant le dernier chevalier :
<br/>      -    Jasson, je crois me souvenir que tu as eu de nombreuses discussions avec Dagonor ?
<br/>      -    Exact, répondit le chevalier d'une voix sérieuse.
<br/>      -  Nous avons donc choisi de t'intégrer au groupe de stratèges durant la bataille, tu pourras comme ça les protéger tout en leur apportant tes connaissances.
<br/>Jasson soutint le regard de Laziador sérieusement, puis hocha la tête.
<br/>Un elfe arriva accompagné de quatre chevaux :
<br/>      -   J'ai amené vos chevaux, chevaliers, malheureusement celui de Jasson est... mort je crois pendant votre voyage.
<br/>      -    Exact, répondit Laziador.
<br/>      -    Je me suis permis de lui en donner un autre.
<br/>Les chevaliers prirent leurs chevaux et Jasson remercia l'elfe.
<br/>Quelques minutes plus tard, les chevaliers étaient à leur poste. Jasson fit connaissance avec les dix stratèges elfiques qui lui expliquèrent rapidement ce qu’ils avaient choisi pour le début des opérations. La stratégie consistait à affaiblir l'ennemi avec des pluies de flèches, puis de les achever avec les épéistes et les "dryades".
<br/>      -    Qu'est-ce qu'une dryade ? demanda Jasson aux elfes.
<br/>      -   Ce sont des esprits de la forêt... Personne ne sait vraiment ce qu’ils sont, ils ressemblent à des bouts de bois assemblés entre eux, ces bouts de bois qu’ils modélisent à volonté sont d'une dureté impressionnante.
<br/>Jasson approuva leur stratégie.
<br/>Selestan dut partir à la droite du futur champ de bataille pour trouver son escouade. Les huit elfes à son commandement le saluèrent à son arrivée, parmi eux, il y avait Lynaé. Cette responsabilité le stressa encore plus. "Pourquoi un petit chevalier comme moi qui n'a jamais vu une seule bataille se retrouve-t-il au commandement d'une escouade" se demanda Selestan en se rongeant les ongles.
<br/>Les dix archers que Chloé allait commander, se mirent au garde à vous à l'arrivée de la jeune femme. Elle sentit son estomac être rongé par le stress.
<br/>Xalendan découvrit son escouade d'épéistes qui le salua respectueusement. Ces neuf elfes devaient sûrement être des guerriers redoutables.
<br/>Cinq elfes, leur heaume sous le bras, entrèrent dans la tente ou Jasson écoutait les différentes stratégies.
<br/>      -    Ce sont les cinq messagers, leur rôle est de communiquer la stratégie aux différents commandants, informa un stratège pour Jasson.
<br/>Les stratèges firent part de leurs décisions aux messagers qui s'empressèrent de partir. Le chevalier sortit de la tente pour regarder le paysage, Les mercenaires commençaient à se voir au loin. Jasson soupira avant de revenir dans la tente.
<br/>      -  On commence à voir les guerriers du Chaos arrivés, annonça le chevalier.
<br/>      -    Exactement comme l'avaient prévu les ingénieurs.
<br/>Selestan commença à voir les mercenaires au loin, son ventre se noua. Il était encore jeune, il n'avait pas encore envie de mourir.
<br/>      -   C'est ta première bataille ? lui demanda Lynaée qui s'était faufilée jusqu'à lui.
<br/>      -    A vrai dire... oui... et toi, c'est aussi ta première bataille ?
<br/>      -  Non, pas vraiment... J'ai déjà participé à plus d'une trentaine de campagnes.
<br/>Selestan gloussa, il ne comprenait toujours pas pourquoi il était choisi commandant.
<br/>      -   Mais... reprit Lynaée, c'est la première fois que je participe à un combat de cette importance. L'ennemi est en très grand nombre... Peut être même que nous allons tout droit à la mort...
<br/>      -  Bonjour, dit un elfe qui arrivait à cheval, je suis un messager et on m'a ordonné de vous dire qu'il y aura deux pluies de flèches. Pendant la troisième, vous foncerez vers l'ennemi par la droite et participerez à la quatrième pluie de flèches, puis vous couvrirez les épéistes qui seront au corps à corps...
<br/>Chloé fronça les sourcils lorsqu'elle aperçut la gigantesque armée ennemie à l'horizon. Un elfe messager arriva à cheval.
<br/>      -   Vous ne devrez pas vous lancer dans la bataille tant qu'un stratège ne l'aura pas ordonné.... lança celui-ci.
<br/>Xalendan s'inclina devant le messager des stratèges.
<br/>      -   Il y aura trois pluies de flèches, expliqua l'elfe, et c'est pendant la quatrième pluie que vous foncerez vers le front droit de l'ennemi pour une attaque au corps à corps...
<br/>
<br/>
<br/>
<br/>
<br/>L'armée du Chaos était maintenant toute proche, Selestan sur sa licorne attendait avec impatience les premières pluies de flèches. Tout à coup, une cinquantaine de flèches volèrent à la vitesse du son, plusieurs mercenaires tombèrent, les autres restèrent impassibles. Le cœur de Selestan fit un bond, ça allait bientôt être à lui... Une deuxième pluie de flèches vola.
<br/>      -   Tenez-vous prêts ! ordonna Selestan aux huit elfes sous son commandement.
<br/>La troisième pluie décolla...
<br/>      -  Maintenant !! s'écria le chevalier. Ils s'élancèrent au galop.
<br/>A cinquante mètres des mercenaires, Selestan s'écria :
<br/>      -    Encochez vos flèches !... Prêt, TIREZ !!
<br/>Les flèches décollèrent en même temps que celles des autres archers. La flèche de Selestan atteignit une cible de première ligne, il en fût ravi.
<br/>Quelques secondes plus tard, des épéistes, d’étranges êtres qui ressemblaient à des bouts de bois gluants et des elfes à cheval foncèrent au corps à corps... Selestan repéra vite la seule escouade d'épéistes à leur droite, il ordonna à ses elfes de couvrir cette escouade comme les stratèges le lui avaient ordonné. Il reconnu Xalendan dans l'escouade, déchiquetant avec rage tous les mercenaires que se battaient contre lui. Le chevalier encocha une flèche. Il vit un elfe qui allait se faire tuer en traître par derrière par un mercenaire. Selestan se hâta de viser la tête de celui-ci avant qu'il n'enfonce son épée dans le dos de l'elfe. Il tira, pendant un instant, Selestan crut qu'il avait raté sa cible, mais sa flèche s'enfonça dans le cou de l'ennemi. L'homme-démon s’effondra. " J'avais visé la tête... Mais il faut un peu de chance de temps en temps ! " se dit Selestan. L'elfe que Selestan avait sauvé, leva la main en signe de remerciement avant de repartir au front.
<br/>Xalendan était englouti dans la mêlé et se déchaînait, il tuait tous les hérétiques sans pitié avec ses épéistes. Deux mercenaires l'attaquèrent en même temps. " Mince ! Impossible de parer leurs deux attaques en même temps ! " se dit Xalendan. A ce moment là une flèche atteignit un des deux mercenaires en plein cœur, le chevalier contra donc l'autre avant de lui couper la tête. Il se retourna et vit le groupe de Selestan qui les couvrait avec leurs flèches. Il n'eut pas plus de trois secondes de répit que déjà un mercenaire fonçait vers lui en beuglant. Il l'esquiva souplement et lui envoya un revers d'épée mais l'ennemi l'esquiva lui aussi. Xalendan fut étonné, jusqu'à maintenant, tous les mercenaires lui avaient paru faciles à tuer. Le chevalier s'élança vers son adversaire. Quelques claquements entre leurs deux épées avaient retenti avant que Xalendan trouve une faille dans la défense ennemie. Il s'y faufila habillement et porta le coup de grâce. Une volée de flèches tirée par les ennemis déferla vers son escouade. Un des épéistes fit des signes bizarres avec les mains puis s'écria en claquant des mains :
<br/>      -    Technique de la barricade de feuilles !!
<br/>Des feuilles sortirent de la forêt à une vitesse impressionnante pour se placer les unes sur les autres devant l'escouade de Xalendan. Les flèches s'enfoncèrent dans l'épaisse couche de feuilles mais ne la traversèrent pas. " Peu importe comment il a fait, mois aussi je vais me lancer dans la magie ! " songea Xalendan.
<br/>      -    Feu ! s'écria le chevalier en langage elfe en fonçant vers l'ennemi.
<br/>Xalendan lança une boule de feu sur quatre mercenaires. Le sortilège atteignit sa cible et explosa, envoyant valser les hérétiques, morts, quelques mètres plus loin...
<br/>      -   Servez vous aussi de votre magie ! s'écria le jeune homme à son escouade.
<br/>Tous les elfes affirmèrent qu'ils étaient à ses ordres. Les elfes combinèrent donc leur magie avec leur adresse à l'épée...
<br/>Jasson regardait la bataille à l'extérieur de la tente en compagnie des stratèges. Les elfes étaient en train de battre littéralement l'armée du chaos.
<br/>      -    C'est trop facile, notre stratégie est imbattable, dit un elfe d'une voix railleuse.
<br/>Jasson fronça les sourcils et dit :
<br/>      -    Je ne crois pas...
<br/>Les stratèges le regardèrent, étonné.
<br/>      -  Certes il exagérait en disant que notre stratégie était imbattable mais quand même, tu ne vois pas que nous sommes en train de gagner, dit un stratège.
<br/>      -    Mhhmhh... Non, je crois justement que nous sommes en train de perdre...
<br/>Sans attendre de réponse, le jeune homme entra dans la tente où il s'installa sur une chaise, les coudes sur la table, les doigts croisés signifiant une concentration inhabituelle. Les autres stratèges le rejoignirent.
<br/>      -   Je ne comprends pas, chevalier Jasson, qu'est-ce que vous dites, que nous sommes en train de perdre ?
<br/>Plus Jasson y songeait, plus sa réflexion lui confirmait sa pensée.
<br/>      -   Je pense que nous sommes tombés dans le piège de l'ennemi, dit Jasson d'une voix sérieuse qui ne lui ressemblait pas.
<br/>Des stratèges rigolèrent, d'autres poussèrent des cris avec sarcasme. Le chef des tacticiens s'écria d'une voix forte :
<br/>      -   Fermez la bande d'abrutis !! Jasson, explique-nous ton raisonnement.
<br/>      -    C'est trop facile...
<br/>      -    Explique-toi mieux !
<br/>Jasson soupira avant de se lancer dans l'explication.
<br/>      -    Les dieux du mal traitent leur adorateur, leur homme et démon d'une manière ignoble.
<br/>Il se souvint alors de Dagonor et de ses paroles.
<br/>      -    Les dieux n’existent pas !! s’indigna un organisateur.
<br/>Jasson lui lança un regard noir...
<br/>      -  Libre à vous de croire en ce que vous voulez... Il n'empêche que les dieux du mal traitent très mal les gens sous leurs ordres. Alors d'après moi... Tous ceux que nous combattons pour le moment font partie des adorateurs qui n'ont jamais manié une épée de leur vie. Les dieux maléfiques sont en train de se servir de nous pour écraser les personnes qui ne leur sont d'aucune utilité, et ils sont en train aussi de fatiguer nos guerriers. Car même si leur puissance est très faible, leur nombre est impressionnant, nos guerriers vont se fatiguer de plus en plus. Et quand nous serons totalement épuisés... Ils nous enverront leur véritable armée, et là ce sera la fin.
<br/>Tous les stratèges avaient subitement retrouvé leur concentration et songeaient au-delà de leurs pensées.
<br/>      -    Il est vrai que nous sommes peut-être dans une très mauvaise situation. Faisons, par mesure de sécurité, replier certaines escouades.
<br/>Les stratèges envoyèrent donc des messagers informer les escouades qui allaient se replier. Les émissaires partirent au galop.
<br/>      -    Il ne nous reste plus qu’à observer... dit le chef des tacticiens en fronçant les sourcils.
<br/>
<br/>
<br/>
<br/>
<br/>      -    Ca fait des heures qu'on se bat, et le nombre d'ennemis n'a pas l'air de diminuer, je commence à être sérieusement fatigué ! cria Xalendan à son escouade.
<br/>Pendant les quelques heures qui s'étaient écoulées, des escouades voisines s'étaient repliées, donc le jeune homme et ses elfes devaient combattre plus de mercenaires à la fois.
<br/>Selestan tirait des flèches avec son escouade depuis des heures, malgré les nombreux ravitaillements en flèches, les réserves se vidaient rapidement. Il regarda furtivement Lynaée qui balancait des flèches avec démence. " Qu’elle est belle, encore plus que d'habitude..." pensa le chevalier. Il secoua la tête, ce n'était vraiment pas le moment de penser à ça !
<br/>Chloé, de son coté, commençait sincèrement à s'impatienter, elle faisait les cent pas depuis plusieurs heures et aucun messager n'était venu lui dire de se lancer dans la bataille.
<br/>Elle regardait le combat en s'inquiétant pour ses frères d'arme.
<br/>Xalendan se battait avec acharnement, faisait tournoyer son épée dans tous les sens. Tout à coup, tous les mercenaires arrêtèrent de se battre, et, aussi bizarre que ça puisse paraître, ils fuirent tous.
<br/>Tous les elfes et les chevaliers étaient étonnés, aucun des guerriers ne poursuivit les ennemis. Ils étaient tellement épuisés, que grimper sur leur cheval aurait été une rude épreuve.
<br/>Jasson vit par les trous d'observation de la tente que les ennemis fuyaient. Les stratèges sautèrent de joie. Jasson se leva brusquement et frappa sur la table de toutes ses forces. Toute l'attention lui fut restituée.
<br/>      -   Faites replier toutes les personnes qui étaient au front. Préparez toutes vos forces pour une embuscade surprise et décisive dans la forêt. C'est là que les choses sérieuses vont commencer ! ordonna Jasson.
<br/>Tous les stratèges se ressaisirent, plongés de nouveau dans leurs pensées, ça leur paraissait indigne de faire la guerre dans leur magnifique forêt.
<br/>      -  Exécutez ses ordres ! dit subitement le chef des organisateurs. J'en prends l'entière responsabilité !
<br/>      -    Mais chef...
<br/>      -    Exécution !!
<br/>Une fois encore, les messagers partirent sans rien dire informer les commandants.
<br/>Xalendan et Selestan reçurent le message et se replièrent sans rien dire. Chloé reçut l'ordre de préparer son escouade dans la forêt pour l'embuscade.
<br/>Tout était prêt pour l'embuscade, la dizaine de minutes de répit n'avait pas permis aux escouades qui étaient au front de récupérer totalement leur souffle. L'armée du Chaos apparut de nouveau, cette fois progressant très rapidement, les guerriers était deux fois plus monstrueux, c'était vraiment les démons des dieux maléfiques.
<br/>En moins de cinq minutes, les démons arrivèrent devant la forêt. Tout le monde était en place suivant la stratégie de Jasson qui avait pris le commandement des opérations. Dès que le dernier guerrier maléfique, c'est à dire à peu près le deux mille cinq centième soldat, entra dans la forêt,  le piège débuta. Des flèches de tous les côtés, des cris dans tous les sens. La vraie bataille commençait. Toutes les dryades chargèrent, leur puissance égalait celle des démons mais leur nombre moins imposant en revanche allait faire toute la différence. Toutes les flèches n’avaient eu aucun effet au niveau du moral de l'ennemi... C'est pour cette raison que les dryades ne purent toucher autant de cibles que prévu. Les épéistes entrèrent en jeu, ainsi que les chevaliers elfes. Les archers, autant à pied qu'à cheval, arrivèrent pour couvrir les unités amies. Très bizarre, les démons ne furent pas surpris de l'embuscade et conservèrent toute leur puissance. Ils arrivèrent, malgré la puissance des elfes, à prendre l'avantage. Les êtres du mal se battaient avec acharnement et les elfes avaient du mal à les retenir.
<br/>Jasson décida d'intervenir :
<br/>      -  Envoyez les guerriers que vous appelez danseurs, les faucons de guerre, ainsi que vos enchanteurs et les elfes du clan de Ceflings.
<br/>Tous les guerriers que Jasson avaient mentionnés se retrouvèrent au front une minute plus tard. Les "danseurs" étaient des elfes qui maniaient deux épées en dansant et en chantant, leur attaque était d'une vitesse rare, et leur grâce incomparable. Les faucons arrivèrent du ciel, lâchant d'énormes pierres sur l'ennemi et attaquant avec leurs longues pattes griffues. Pour des faucons, ils étaient incroyablement grands. Les enchanteurs n’étaient vraiment pas nombreux, mais leur efficacité était telle que l’on aurait pu penser qu’ils étaient cent. Ils utilisaient la magie de la forêt, utilisant par exemple la branche d'un arbre comme fouet... Quant aux elfes du clan de Celfings, ils n’étaient qu'une quinzaine, mais leur attaque dévastatrice influença beaucoup l'issue de la bataille. Ils maniaient d'étranges bâtons d'où sortaient des lames pour trancher, couper et déchiqueter. Xalendan sentait vraiment que ce combat était d'un tout autre niveau que le précédent, le chevalier essayait tant bien que mal de prendre l'avantage avec le démon qui lui faisait face. L'arrivée de guerriers étranges mais extrêmement puissants remit de l'espoir dans le cœur du jeune homme. Selestan, de son coté, n'arrivait pas à tuer d'ennemi. Ses flèches se percutaient à chaque fois contre l'arme ennemie qui venait contrer le projectile où sinon contre l'énorme armure des démons. Sans compter que d'autres monstres ne se tracassaient vraiment pas des flèches et les esquivaient sans aucune difficulté. Non ! Ces ennemis étaient d'un niveau largement supérieur aux précédents. Chloé commençait à s'impatienter devant son impuissance qui l'énervait de plus en plus.
<br/>      -    Nous reprenons l'avantage ! s'écria Jasson.
<br/>      -    Non... Regardez le ciel
<br/>En effet, le ciel s’assombrissait à l’arrivée de la créature donc Laziador avait parlé, un sorcier du chaos. Un être répugnant, survolant le champ de bataille en jaugeant la situation de ses yeux rouge sang.  Une longue cape noire, des mains où l’on ne discernait que les veines tenaient un grand sceptre en bois. Le sorcier ouvrit la bouche et un cri retentit. Les vents se déchaînèrent, provoquant des tornades et des éclairs. Les éclairs semblaient être contrôlés par le sorcier, puisqu’ils ne frappaient que dans le camp des elfes. On entendait les hurlements des elfes qui se faisaient électrocutés, bientôt des experts magiciens arrivèrent pour tenter de contrer l’effroyable magie du démon. Bien sûr leur intervention n’était que superficielle, aucun magicien n’était capable d’arrêter le vent et la foudre de l’être maléfique, mais tout au mieux ils arrivaient à dévier les attaques.
<br/>Laziador arriva devant Jasson et les stratèges :
<br/>      -    C’est terminé, nous devons tenter le tout pour le tout.
<br/>      -  Comment ça, le tout pour le tout ? demanda un organisateur.
<br/>Le professeur soupira :
<br/>      -    Envoyez toutes vos unités au front.
<br/>      -   Nous n’avons plus que quelques escouades en attente… et elles ne nous seront pas d’une grande aide ! répliqua un stratège.
<br/>      -    Nous n’avons plus le choix, que les dernières unités chargent !
<br/>
<br/>
<br/>
<br/>
<br/>Cela faisait déjà dix minutes que le sorcier était arrivé. Et même avec l’entrée dans la bataille de quelques nouvelles unités, leur défaite était inévitable. Tout à coup, le sol trembla, et l’arrivée d’une nouvelle unité était certaine. Un dragon, rouge foncé et pesant plus d’une tonne marchait vers le front. A chaque pas qu’il faisait, la terre vibrait. Des yeux tristes traversaient les quatorze yeux des sept têtes du monstre. La tête du milieu était d’une couleur or et se démarquait des autres par sa grandeur. Mesurant plus de dix mètres de haut, le dragon déploya ses ailes et s’envola. N’ayant pas trop le temps de s’intéresser à cette bête, Selestan faisait du mieux qu’il pouvait pour rester en vie. Presque toute son escouade avait péri, Lynaée et lui se battaient côte à côte.
<br/>Ca faisait longtemps que Chloé réfléchissait à un moyen de battre le sorcier. N’étant pas au corps à corps, elle eut le temps de chercher dans le livre des elfes les mots dont elle avait besoin pour exécuter son plan. Elle expliqua sa stratégie aux archers sous ses ordres, tous lui obéir.
<br/>      -    Qu’il tombe devant moi ! s’écria Chloé en pensant au sorcier.
<br/>Même si ses mots avaient été prononcés en langage elfe, l’énergie que le sort lui prit, la fit tomber à genoux. Par contre le sorcier, surpris, n’eut pas le temps de comprendre avant qu’il ne se retrouve devant la jeune femme.
<br/>      -    Maintenant ! lança Chloé aux archers.
<br/>Tous avaient encoché une flèche et s’étaient positionné en cercle autour du sorcier. Ils tirèrent tous leur flèche au signal de Chloé. Le réflexe du démon fût impressionnant, il leva la main et prononça des paroles dans une langue inconnue. Toutes les flèches ricochèrent sur un bouclier invisible avant de se planter dans la tête de leur propriétaire. Chloé esquissa un cri, toutes les unités de son escouade venaient de périr sous ses yeux. Elle essaya de se calmer et réfléchit. Elle se souvint alors de la simulation de quête, pour combattre les professeurs, les chevaliers avaient communiqué par la pensée. Elle se concentra et appela Laziador de toutes ses forces mentales. Le sorcier perçut aussi le message avec sa magie. Il sembla ricaner.
<br/>      -  Crois-tu vraiment qu’il va te sauver ! Non mais il faudrait arrêter de surestimer vos capacités !
<br/>Le professeur arriva, une sphère bizarre dans la main.
<br/>      -   Je ne pensais pas avoir à me battre contre toi si vite, sorcier.
<br/>Sans attendre de réponse, Laziador tendit sa main qui tenait la sphère et récita en langage elfe :
<br/>      -    Que cette pierre de la terre des dieux, chasse à jamais ce démon des cieux.
<br/>Qu’il ne lui soit accordé aucune attention.
<br/>Après son immédiate exécution.
<br/>Dès que le démon touchera la sphère.
<br/>Il ne restera de lui que des poussières.
<br/>Après ce chant magnifique, Laziador lança de toutes ses forces l’objet sur le sorcier. Au lieu d’utiliser la magie, le démon sauta pour esquiver la sphère. Laziador serra les dents.
<br/>      -    Ainsi, sorcier, tu connais les pouvoirs de cette pierre ?
<br/>      -  J’ai participé à maintes guerres, elfe, mais j’ai aussi participé à des guerres contre des anges ! Et j’ai vu beaucoup de grands sorciers maléfiques périr sous la puissance de ces pierres. Comment un misérable elfe comme toi aurait pu s’en procurer une.
<br/>      -   Tu verras lors de notre combat que je ne suis pas aussi misérable que tu ne le penses, dit calmement Laziador.
<br/>Le sorcier ricana en toussant d’amusement.
<br/>      -    Tu crois m’arriver à l’orteil, à moi, un démon majeur.
<br/>Laziador gloussa discrètement, il savait qu’il lui était impossible de rivaliser avec le sorcier en terme de magie. Il regarda alors la pierre sur le sol ; c’était son unique chance de battre le démon. L’être maléfique vint se placer entre Laziador et la sphère. L’elfe fronça les sourcils, ça n’allait pas être facile. Cette pierre était très particulière, il était impossible d’utiliser la magie pour la contrôler, l’arrêter ou même la bouger d’un cheveu.
<br/>Chloé, ne croyant qu’au courage, sauta pour attraper la pierre mais fût arrêtée par le sorcier. Maintenant à terre et sans défense, Chloé lança un regard noir au démon. Les lèvres du sorcier semblèrent sourire pendant que le professeur criait. Les mains maléfiques de l’être se joignirent, et il cria :
<br/>      -    RAYON DESTRUCTEUR !!
<br/>Un éclair rouge s’échappa des mains du sorcier vers la jeune femme. Une ombre passa, puis une lumière jaillit dans tous les sens. La fée s’était interposée. Un bouclier magique s’étant créé au bout d’une baguette magique que tenait le petit être. Sastibive tendit sa baguette vers le démon. Des racines sortirent du sol et vinrent emprisonner le sorcier. Il esquissa un hurlement, puis regarda la fée.
<br/>      -   Je reconnais que les démons n’ont jamais réussi à envahir les terres de ses petites bouses. Mais de là à ce que l’une d’entre elles me batte !
<br/>Le sorcier éclata de rire. Un rire glacial qui fit trembler Chloé. Les racines resserrèrent leurs emprises mais le démon se volatilisa et réapparut juste derrière les lianes magiques. Laziador profita de la diversion pour sauter vers la sphère.
<br/>Le démon ne le vit que trop tard, l’elfe avait attrapé la pierre. Le démon fit un geste de main et la fée alla rejoindre Chloé par terre. Le sorcier était à présent très sérieux, il dévisageait le professeur, concentré. Chloé regarda autour d’elle, elle aperçut une gourde d’eau d’un de ses elfes qui jonchait sur le sol. Elle se rendit discrètement, ce qui ne fût pas difficile puisque le démon ne portait de l’attention qu’à la pierre. Elle but toute l’eau qui restait, prenant bien soin d’en garder le maximum dans sa bouche. Chloé se leva et fonça à l’aveuglette vers le démon.
<br/>      -    Pathétique, dit le sorcier en tendant sa main vers la jeune femme.
<br/>Chloé cracha l’ensemble de l’eau qu’elle avait dans la bouche sur le démon.
<br/>      -    Que… lâcha le sorcier avant de recevoir le liquide au visage, ah !!!
<br/>Son cri de douleur fût strident. Laziador lança la pierre à ce moment là en criant de rage. La pierre toucha le démon et son corps tomba inerte sur le sol, sans vie.
<br/>      -    Ouf ! lâcha le professeur, c’est terminé.
<br/>Chloé regarda un instant le corps du sorcier, puis la sphère. Elle n’avait rien comprit à cette histoire de pierres des anges… Elle demanderait des explications à Laziador plus tard. Chloé se dirigea vers la pierre, allait la prendre mais le professeur l’en empêcha en la poussant.
<br/>      -    L’âme du démon réside maintenant dans cette pierre. Il peut encore venir hanter une personne faible, si celle-ci touche le caillou.
<br/>Chloé fronça les sourcils, elle n’aimait pas ce qu’insinuait le professeur.
<br/>      -    Je ne suis pas faible !!
<br/>L’elfe sourit, puis prit la pierre sans rien dire.
<br/>Xalendan combattait toujours ses ennemis, bien qu’épuisé. Le sorcier n’était plus dans le champ de vision du chevalier, l’espoir revint alors. Blessé à la jambe gauche, Xalendan avait un mal fou à se déplacer, il ne restait presque plus personne dans son escouade. L’espoir qu’il avait bien mérité, disparut tout à coup, en même temps qu’une ombre gigantesque recouvrit le champ de bataille. Quelques elfes se risquèrent à lever la tête,  Xalendan aussi. Le dragon que le chevalier avait aperçu à l’horizon quelque temps avant, se tenait au dessus de la bataille. Ses immenses ailes étaient recouvertes de pic, mais plus impressionnant, le dragon avait sept têtes. L’énorme bête baissa ses têtes vers ce qui n’était pour lui que des fourmis. Sept rayons de feu déferlèrent, tuant tout sur leur passage, amis comme ennemis. On entendit le signal de repli, puis les cris des démons et des elfes incendiés. Xalendan, assis par terre, terrorisé, regardait l’immensité de ce qui se tenait au dessus de lui. Les démons, au lieu de fuir, profitèrent de l’occasion pour lancer la charge vers les elfes et leur forêt. Mais ce qui les attendait, était encore plus irréel. A peine le premier démon mit un pied dans la forêt qu’un immense cri de rage résonna. La forêt se secoua, non, elle se réveilla ! Tout à coup, les elfes s’arrêtèrent pour faire face à leur ennemi. Un elfe s’écria :
<br/>      -    ALVIN EST REVENU !!
<br/>Tous les elfes levèrent leur arme et hurlèrent d’une même voix :
<br/>      -   POUR ALVIN, LE ROI SUPREME DU LLOCLAVR !!!
<br/>Tous les guerriers poussèrent des cris assourdissants en chargeant leur ennemi. La forêt était enfin réveillée, les arbres se levèrent sur leur racine et attaquèrent l’ennemi avec leur branches. Les animaux sortaient de partout se servant de leur croc et de leur griffe pour tuer les ennemis. De nouveaux cavaliers entrèrent dans la bataille.
<br/>      -    Les chevaucheurs de licorne, les gardiens ancestraux ! dit un elfe de l’escouade de Xalendan.
<br/>Ignorant les rayons mortels du dragon, Xalendan, armé d’une nouvelle puissance, chargea avec le reste de son escouade. Les tremblements de la terre annoncèrent l’entrée dans la campagne du roi de la forêt, Alvin. Armé d’un énorme gourdin, le monstre roi arriva. Pris par surprise, les démons furent détruits par la nouvelle puissance de leur ennemi.
<br/>Chloé, à la vue du dragon, avait perdu espoir. Elle était tombée à genoux, suivant les anciennes instructions de leur professeur, elle avait levé une pierre vers le ciel. Priant pour que ça marche.
<br/>      -    La pierre de la simulation de quête ! avait crié Laziador.
<br/>En effet, les professeurs leur avaient dit : « son pouvoir vous sera révélé quand tout vous semblera perdu ». C’était Chloé, sans le savoir, qui avait appelé Alvin, le roi de la forêt. La pierre brillait, par delà le ciel…
<br/>Lors de la fuite, Lynaé était tombée de fatigue de son cheval. Les autres membres de l’escouade et Selestan était venu la secourir. Mais un rayon de feu les dévastèrent, Selestan en sortit vivant, bien qu’entièrement dégoulinant de sang. Personne d’autre à part Selestan, Cristalis et Lynaé dans l’escouade n’était vivant.
<br/>Dix démons en profitèrent pour venir se placer autour des deux survivants.
<br/>      -    On peut dire que vous avez eu de la chance ! persifla un caomme. Mais malheureusement, c’est fini.
<br/>Selestan identifia la situation et la qualifia de catastrophique. Il voulut gagner du temps.
<br/>      -    Comment ça, c’est fini ?
<br/>      -   Oui, pour vous deux ! ricana un autre démon, enfin l’elfe j’en fais mon affaire.
<br/>Le caomme se caressa alors l’entrejambe. Selestan, de nature habituellement calme, s’exacerba. Bien qu’à moitié vivant, le chevalier attrapa son épée et chargea en poussa un rugissement.
<br/>      -    NON !! supplia Lynaé.
<br/>C’est à ce moment là que la forêt s’était réveillée, malheureusement, Selestan ne put être spectateur, son combat face à dix démons avait commencé. Cristalis vint le rejoindre. Le chevalier ne sentait même plus les coups d’épée qu’il recevait. Une force nouvelle naquit en Selestan, celle du désespoir. Il explosa ses ennemis sans pitié, le premier se fit trancher la tête. La licorne fonça dans le tas avec sa corne, embrochant un démon.
<br/>Après l’arrivé du roi de la forêt, Jasson n’avait qu’une envie, se battre. Il leva sont épée et fonça au front sous les protestations des stratèges.
<br/>      -    Vous n’avez plus besoin de moi ! s’écria Jasson devant les organisateurs, alors à plus !
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>17.
<br/>
<br/>** Fin de la guerre **
<br/>
<br/>
<br/>
<br/>Le renversement de situation était impressionnant, les démons étaient en déroute. La seule chose qui faisait encore des pertes dans les troupes était les rayons de plus en plus dévastateurs du dragon. Chloé avait rejoint le front, ainsi que Xalendan et Jasson. Selestan se battait encore avec les démons isolés.
<br/>Tout à coup, Jasson ressentit une puissance nouvelle, il regarda le bout de ciel qui n’était pas caché par le dragon. Ce qu’il vit le remplit d’une immense joie, Rhig, Rhag, Rhoug ! Il poussa un cri pour évacuer le bonheur qui l’envahissait.
<br/>      -    On t’a manqué ! lança un fantôme devant lui.
<br/>      -  Oh oui ! s’écria-t-il en les attrapant aussi fort qu’il le pouvait.
<br/>      -    Le moment n’est pas à la réjouissance… dit Rhag, nous devons t’aider à terrasser ce dragon !… Seulement…
<br/>Jasson reprit sont sérieux en regardant le dragon.
<br/>      -   Le dragon à sept têtes est le plus rare, continua Rhig, sa faculté est de tuer celui ou celle qui l’a tué.
<br/>      -    Co… Comment ? C’est-à-dire que si je le tue, je meurs ! s’écria Jasson pétrifié.
<br/>      -    Tu es un olpha-um, je te rappelle, lança Rhag, tu as une chance de survivre avec nous à tes cotés ! Même si c’est à cinq pourcent.
<br/>Rhoug lui mit une tape amicale sur le dos. Il aperçût alors ses compagnons d’arme en train de se battre.
<br/>Selestan avait enfin terrassé ses adversaires, il tomba au sol d‘épuisement. Lynaée et Cristalis le mirent en selle, Lynaé vint se placer derrière lui sur le dos de Cristalis.
<br/>      -    Merci… lui dit-il doucement à l’oreille.
<br/>L’elfe commença à appliquer des sorts de guérison et des plantes médicinales sur le chevalier ; pendant que Cristalis les ramenait en trottant vers Laziador.
<br/>Laziador était soucieux, il connaissait les pouvoirs de ce dragon. Chloé et Xalendan vinrent le rejoindre lorsque les démons ne se comptèrent plus que par dizaines.	
<br/>      -  Professeur, commença Chloé, comment faisons-nous pour le dragon ? Il est trop loin pour que nos flèches l’atteignent et les faucons  qui ont essayé de le tuer se sont fait détruire.
<br/>Xalendan hocha de la tête. Laziador allait répondre mais fût interrompu par l’arrivé de Selestan. Laziador s’empressa de le poser à terre.
<br/>      - Tous les soins lui ont été administrés, dit cérémonieusement Lynaée, il devrait s’en sortir.
<br/>Les chevaliers furent soulagés.
<br/>      -    Et pour le dragon ? parvint à prononcer Selestan.
<br/>      -   J’y viens, dit Laziador. Il faut que vous sachiez que les dragons à sept têtes sont très particuliers, ceux qui les tuent meurent.
<br/>La surprise des chevaliers fut unanime.
<br/>      -    Je ne pourrai pas demandé à des chevaliers du sphinx de se sacrifier ! Alors se sera moi qui le tuerai !
<br/>      -    Non !
<br/>Tous se tournèrent, Jasson faisait face à son professeur. Il avança d’une démarche assurée, fixant tour à tour ses compagnons d’armes et son professeur.
<br/>      -    C’est moi qui le ferai !
<br/>      -    Non ! C’est impossible, se révoltèrent les chevaliers.
<br/>Selestan essaya même de se lever pour s’interposer, mais Lynaée le plaqua au sol. Chloé et Xalendan eurent pour réflexe de soutenir le regard de Jasson.
<br/>Laziador fixa le chevalier dans les yeux, celui-ci soutint son regard.
<br/>      -    Ah ! Mais au dessus de nous se trouve mon ami ! C’est mon devoir de le tuer puisqu‘il a sombré dans la folie, par ma faute… Et je mourrai !
<br/>Le professeur regarda longuement son élève puis dit finalement :
<br/>      -    Très bien ! Mais je te préviens, tu vas vraiment mourir !
<br/>Jasson ne le savait que trop bien, mais il était maintenant impossible de le faire changer d’avis.
<br/>      -    Jasson, lâcha le professeur sans expression, Pour le tuer, il faut lui trancher la tête du milieu, tu n’as plus une seule minute à perdre !
<br/>Jasson eut un demi sourire avant de lever la tête. « La tête du milieu… OK ! ».
<br/>Le chevalier leva la main au ciel, et cria avec émotion :
<br/>      -    A tous les dieux, accordez que ma vie soit dans ces cinq pourcents !! Au nom de tous les olpha-um…
<br/>Son doigt pointa le dragon.
<br/>      -    …JE VAIS TE TUER !!
<br/>Une couleur bleu argenté s’échappa de Jasson et il décolla, ses fantômes à ses côtés.
<br/>      -    Comme la lumière de l’âme monte dans le ciel
<br/>Pour que sa paix soit éternelle… récita silencieusement Laziador.
<br/>      -    Non… laissa échapper Chloé.
<br/>« Tout s’est passé si vite ! Ce n’est pas possible ! » pensa la jeune femme.
<br/>Seul Laziador comprenait les paroles de Jasson.
<br/>Les têtes du dragon étaient de plus en plus visibles par le chevalier. Il poussa un rugissement, la tête du milieu se tourna vers lui, elle aurait très bien pu le carboniser pour se sauver la vie mais n‘en fît rien, elle envoya juste un regard rempli de gratitude à Jasson. Les autres têtes n’eurent pas le temps de voir Jasson trancher la tête du milieu. Déjà le sang giclait.
<br/>      -    Adieu… Dagonor… Mon ami…
<br/>« J’aurais pu trouver mieux, quand même, comme dernière parole… »
<br/>Les fantômes entrèrent dans l’esprit de Jasson pour lui prodiguer sa chance de survie.
<br/>De leur côté, les larmes des chevaliers coulaient, désemparés et désorientés, ils observaient la scène sans rien pouvoir faire. Laziador joignit les mains et… pria, pour la première fois de sa vie. Les autres l’imitèrent, bientôt, tous les elfes ayant vu Jasson trancher la tête du dragon prièrent.
<br/>      -  Que cette minute de silence honore le chevalier qui sauva notre peuple ! s’écria Alvin d’une voix qui traversa les esprits de chacun.
<br/>Plus aucun bruit ne suivit ses paroles, mis à part le vent doux sur lequel le dragon et son meurtrier était en train de périr. Une lumière, tout droit venue des dieux, sortit du ciel et emporta dans les cieux ces deux guerriers, ces deux amis.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>18.
<br/>
<br/>** Des pertes, des adieux… **
<br/>
<br/>
<br/>
<br/>
<br/>      -    De combien de morts aurons-nous à nous souvenir ? Des morts qui auront sacrifié leur vie pour sauver les générations futures, dit Alvin devant tout le peuple des elfes sylvains.
<br/>Tous pleuraient, leurs larmes honoraient ces guerriers morts au combat. Les chevaliers se tenaient à côté du roi de la forêt, ils ne pouvaient se résoudre à accepter la mort de leur compagnon. Chloé fondit dans les bras de Xalendan. Une larme coula sur la joue de Laziador ; il leva la main sur son cœur.
<br/>      -    Jasson, repose en paix…
<br/>Selestan tapait du poing sur sa chaise, pas tout à fait remis de ses blessures. Lynaée lui mit une main réconfortante sur l’épaule, il ne se calma pas pour autant.
<br/>Une colombe s’envola dans le ciel « rouge ». Tous levèrent la tête vers ce signe de paix mérité.
<br/>
<br/>
<br/>
<br/>
<br/>      -    Selestan, trop faible pour un voyage, restera chez les elfes jusqu’à avoir récupéré des forces. Chloé, Xalendan et moi-même retournerons à la capitale de l’empire dans trois jours, dit avec émotion Laziador quelques jours plus tard…
<br/>      -    Laziador, que de questions me viennent en tête, dit Chloé !
<br/>      -   Je te permets de toutes me les poser, et si je peux y répondre, j’y répondrai, répliqua l’elfe.
<br/>Les trois chevaliers se placèrent devant leur professeur, assis en tailleur.
<br/>      -   Que… Que voulait dire les dernières paroles de Ja… Jasson ?
<br/>Se prénom fît roulé une larme chez Xalendan et énerva Selestan qui s’explosa la main contre un arbre.
<br/>      -   Pour commencer, les olpha-um… sont des êtres choisis par des fantômes. Les êtres les plus respectés chez les elfes, et sûrement la race la plus éteinte de toutes. Jasson en était un…
<br/>      -    Des… Des fantômes ?
<br/>      -   Oui, ce sont des personnes naissant dans le monde des morts. Ils sont très rares…
<br/>Laziador leur fît part de son savoir sur les fantômes pendant dix bonnes minutes.
<br/>       -   Comment se fait-il que Jasson ai réussi à se guérir de la blessure que lui avait infligé Lynaée alors que le verrou de la terre était actif ? demanda la jeune femme.
<br/>       -  Jasson avait une Magicianna… ce sont des énergies divines très rares et recherchées, elles permettent de faire de la magie de volonté, plutôt que de prendre comme relais la planète, on prend la Magicianna. Cette énergie choisit le corps où elle s’installe, et se mélange à l’esprit de ce corps ; conférant donc leur pouvoir à cet esprit.
<br/>      -    Co… Comment… Jasson était olpha-um et détenait une énergie divine ? s’exclama Selestan qui ne savait pas trop s’il avait bien compris ces explications.
<br/>      -    Vous tous avez une Magicianna…reprit Laziador, c’est d’ailleurs pour cela que vous avez été choisis pour être chevaliers du Sphinx. Les épreuves étaient truquées depuis le début, lors de votre recrutement. Les Magicianna existent au nombre de quarante-neuf, et une autre est la Magicianna suprême. Celle-ci ne choisit un corps qu’une fois tous les millions d’années.
<br/>      -   Est-ce que c’était la Magicianna qui agissait lorsque la lumière bleutée sortait de Jasson, peu avant son envol vers le dragon ? demanda Xalendan.
<br/>Le professeur hocha la tête en signe d‘affirmation.
<br/>      -    Assez de questions pour aujourd’hui… au lit !
<br/>Ils entrèrent dans leur couverture, sachant très bien qu’ils ne dormiraient pas. Exactement comme elle l’avait prévu, Chloé ne ferma pas l’œil de la nuit. Elle repensa à tous les bons moments qu’elle avait partagés avec Jasson. « Il était… irremplaçable… » pensa-t-elle. Il était certain que cette personne, que ce chevalier des plus courageux, resterait dans le cœur des chevaliers jusqu’à leur mort…
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}