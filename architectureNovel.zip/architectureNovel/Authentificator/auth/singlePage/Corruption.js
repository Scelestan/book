function C() { var choice = "Continuer#Plevintrus";var texting = `
<br/>
<br/>** Corruption **
<br/>
<br/>
<br/>Dès que Chloé eut entendu son camarade hurler, elle abandonna sa tâche et courut jusqu'à sa chambre, Selestan arriva en même temps qu'elle, les cris s'arrêtèrent. Ils entrèrent dans la chambre, puis dans la salle de bain, Chloé se tourna brusquement en le voyant. En fait, parce que Jasson était tout nu et puis parce qu'il avait le torse brulé vif, le garçon avait les yeux fermés. Selestan se précipita vers l'eau de la baignoire et  constata qu'elle était à une température normale. Chloé surmonta son embarras pour se tourner vers le corps inerte de son frère d'arme, à ce moment là, Xalendan entra dans la pièce et  ne put s'empêcher de grimacer.
<br/>      -    Que s'est-t-il passé ? demanda Xalendan effrayé
<br/>      -   On ne sait pas, il s'est mis tout à coup à crier. Chloé, va chercher la soignante !
<br/>Xalendan s'agenouilla devant Jasson, tendit la main vers lui et dit en langage elfe qu'il fallait guérir la brûlure. A la grande surprise du chevalier, le sortilège engloutit ses forces d'un coup, alors, par pur réflexe il rompit le sort, ce qui lui prit une quantité époustouflante d'énergie. Xalendan s'allongea, le cœur battant à cent à l'heure et le souffle court.
<br/>      -    Ne pas utiliser la magie…souffla-t-il à Selestan avant de s'évanouir.
<br/>Selestan toucha le front de Xalendan, il était brûlant.
<br/>      -   Refroidis un peu son corps, dit-t-il à l'adresse de la magie, la main tendue vers le front de Xalendan.
<br/>Aussitôt, les faibles tremblements du chevalier s'estompèrent. Selestan fût content de son sortilège et traina Xalendan vers le coin de la pièce.
<br/>La soignante arriva en trombe, suivie de Chloé.
<br/>      -    Oh ! Que s'est-il passé ? dit-elle d’une voix aigue.
<br/>Sans attendre de réponse, elle alla vers Xalendan et dit qu'il manquait juste d'énergie, qu'un peu de repos le sortirait d'affaire. En revanche, quand elle regarda le pauvre Jasson, elle trembla de tout son corps. Paralysée par la terreur, elle ne bougeait plus. Elle réussit finalement à approcher doucement son doigt vers le front du chevalier.
<br/>Quand le doigt toucha la peau du chevalier, la soignante poussa un cri en retirant son doigt qu'elle suça en fermant les yeux.
<br/>      -    Il faut à tout prix aller chercher Laziador ! s'exclama avec peur la soignante qui prit la fuite, débrouillez vous, je n'ai pas envie d'être infectée !
<br/>      -    Qui est Laziador ? s'écria Chloé
<br/>      -  C'est le professeur sans nom... l'informa Xalendan qui ouvrit les yeux faiblement.
<br/>Le chevalier fût contraint de dévoilé le secret de l'elfe. Sous les questions incessantes de la jeune femme, Selestan réussit, en sa compagnie, à trouver Laziador. Le professeur les accompagna à la salle de bain. Quand l'homme entra dans la pièce, il esquissa un hurlement. Le professeur tourna la tête vers Xalendan qui réussit à sourire.
<br/>      -  Je suppose que tu as essayé la magie... Le premier symptôme est là. La soignante, vous m'avez dit qu'elle avait touché son front, a crié puis elle est partie... Le deuxième symptôme est là... songea à haute voix Laziador en tremblant légèrement. L'eau, il s'est brûlé avec l'eau !
<br/>      -   Non monsieur... dit Selestan, j'ai vérifié, l'eau était à température normale.
<br/>      -    Le troisième symptôme est là ! s'exclama Laziador qui tremblait maintenant entièrement. La corruption du Chaos !
<br/>Les chevaliers s'étonnèrent de cette maladie dont ils ne connaissaient même pas le nom. Corruption du "cao" avait songé Chloé, qu'est-ce que c'est ? Laziador leur répondit que c'était une maladie redoutable, que c'était dû à une contamination et que cette maladie provenait le plus souvent d'une morsure de "Minaos" ou de "Caomme"...
<br/>      -    Mais que fait cette maladie ? s’énerva Chloé. Comment on la guérit ?
<br/>      -    Cette maladie va transformer Jasson en Minaos et pour le guérir... Il n'y a qu'une manière... Connaissez-vous la forêt ancestrale du "Lloclavr", c'est la plus grande forêt de notre monde, dit l'elfe.
<br/>      -   Jamais personne ne nous a montré la carte de notre monde... Non, nous ne connaissons pas le "Lloclavr", dit Xalendan d'un ton énervé plein de reproche.
<br/>Laziador s'empressa de prendre un parchemin de son sac, un très grand parchemin qu'il étala sous les yeux ébahis des chevaliers.
<br/>      -    Là, c'est le Lloclavr, dit l'elfe en montrant une partie de la carte.
<br/>      -    Il est vrai que c'est très grand, je me demande comment une si grande forêt a pu se former, se demanda Chloé
<br/>      -    Concentrons-nous sur le fait, comment guérir notre frère d'arme,  demanda Selestan
<br/>Laziador leur expliqua que là bas, il y a un endroit aussi grand que trois villes, rempli d'arbres "plévintrus" (guérisseur).
<br/>      -   Une seule feuille d'un de ces arbres pourrait guérir Jasson, malheureusement, nous avions une réserve de ces feuilles, mais c'était jadis... Car les elfes qui habitent là bas ne veulent plus d'homme ni de nain sur leur territoire. Pour les sensibiliser, il va falloir que vous ameniez Jasson avec vous... Il devrait se réveiller bientôt, c'est l'eau qui l’a brûlé, et c'est la douleur que l’a fait s'évanouir. Je vous préviens, il risque de... crié... à son réveil.
<br/>Sur ce, Laziador partit de la chambre. Chloé remarqua, à ce moment là, la morsure, sur le mollet du jeune homme. Après un bon quart d'heure, les chevaliers décidèrent de laisser Jasson seul jusqu'à son réveil et allèrent s'asseoir sur le lit de celui-ci en prenant soin de fermer la porte de la salle de bain.
<br/>
<br/>
<br/>
<br/>
<br/>Jasson ouvrit un œil, puis l'autre... Une douleur le prit, il essaya de crier mais en vain... L'homme qui avait failli le tuer, qui avait tué ses fantômes, se tenait devant lui :
<br/>      -   Pas la peine d'essayer de crier, tous les sons que tu produiras, que les autres chevaliers pourront entendre, seront dissipés par ma maigre magie...
<br/>      -    Mes fantômes... réussit à chuchoter Jasson.
<br/>      -   Tu seras bientôt un Minaos. Un homme en mutation, dont le corps est corrompu, ne peut avoir de fantôme, dit l'homme.
<br/>Le chevalier n'avait pas compris un mot de ce que l'autre disait.
<br/>      -   Tu voulais savoir mon nom, eh bien c'est Dagonor. Tu seras bientôt des nôtres, Jasson le chevalier corrompu.
<br/>L'être émit ensuite un son qui ressemblait plus ou moins à un ricanement. Dagonor disparut sans laisser de trace et le jeune homme put hurler, à pleins poumons, sa douleur.
<br/>Les autres chevaliers débarquèrent en trombe par la porte qui fut presque cassée en deux à la volée.
<br/>      -    Qu'est-ce qui s'est passé ? demanda Chloé avec une voix excitée et inquiète.
<br/>Elle s'empressa de s'agenouiller au coté du malade. Par pur réflexe, Jasson cacha les parties intimes de son corps nu, ce qui raviva ses brulures... Il poussa un cri.
<br/>      -    Qu’est-il arrivé ? le questionna Selestan
<br/>D'un coup, sans que Jasson ne puisse se contrôler, il avança la tête avec la bouche ouverte vers Chloé, il ferma la bouche à quelques centimètres d'elle, comme s’il avait voulu la mordre. Puis il retira sa tête sous les protestations terrifiées de la jeune femme qui s'empressa de s'éloigner. Jasson avait le souffle bruyant, un bruit démoniaque sortait de sa bouche, à vous mettre la chair de poule.
<br/>      -    Qu'est-ce qui te prend ? s’exclama Xalendan !
<br/>Jasson tourna sa tête vers lui comme un serpent vers sa proie. Il regarda Xalendan les dents serrées, il lâcha un petit cri en claquant des dents, puis secoua la tête. Le jeune homme se prit le visage entre les mains, les yeux fermés.
<br/>      -    Qu'est-ce qui m'arrive ?
<br/>Il voulut pleurer mais au lieu de ça, ses yeux devinrent rouge sang, il voyait flou, ses yeux lui piquaient. Jasson supplia le ciel sans que les autres chevaliers ne puissent faire quelque chose.
<br/>On déposa le jeune homme sur son lit, on lui apporta à manger mais pour l'eau, les chevaliers se ravisèrent et préférèrent appeler Laziador qui en connaissait un peu plus... sur les démons.
<br/>      -    Tu as soif ? demanda l'elfe à son arrivée.
<br/>Jasson hocha la tête en signe d'affirmation.
<br/>      -  C'est pire que je ne le croyais... Les hommes en transformation n'ont soif qu'une semaine après la morsure, et à ce moment là, la transformation a débuté.
<br/>      -    Il est vrai que ça fait cinq jours au moins que je n'ai pas bu, et je ne m'en rends compte que maintenant... réussit à souffler le malade.
<br/>      -    Mais que va-t-il boire ? s'exclama Chloé !
<br/>      -    A-t-il déjà essayé de vous mordre ? demanda Laziador aux chevaliers.
<br/>Les chevaliers l’affirmèrent et le professeur dit qu'il ne fallait pas perdre de temps.
<br/>      -    Mais il a soif ! s'écria la petite amie de Jasson.
<br/>      -   Les Minaos boivent du sang ! Alors à part lui donner ton bras pour qu'il suce tes veines... Il n'y a pas de solution ! s’énerva l'elfe.
<br/>Le professeur dit ensuite qu'il ne fallait pas attendre, qu'il fallait partir tout de suite pour la grande forêt sylvestre. Il avait affirmé qu'il les accompagnerait pendant ce périple.
<br/>      -    Quand as tu rencontré le Caomme ? Ou le Minaos ? demanda Laziador à Jasson.
<br/>      -    Il n'y a même pas dix minutes... marmonna le jeune homme.
<br/>Les yeux de l'elfe s'écarquillèrent d'étonnement, il se rapprocha ensuite de Jasson et le questionna avec une fausse patience :
<br/>      -    Quand as tu rencontré le démon pour la première fois ?
<br/>      -    Il y a à peu prés une semaine, dans le bois quand j’étais à la recherche de plantes pour guérir Chloé... AAAHH !!
<br/>Une douleur prit le chevalier qui ne se retenait pas de beugler comme un cochon qu'on égorge. Laziador lui redemanda s’il avait vu le démon ici, il y a quelques minutes.
<br/>      -    Oui... Il a utilisé sa magie pour m'empêcher de crier... Il... Il...  Il s'appelle Dagonor...
<br/>Le professeur but une gorgé d'air un peu effaré et déclara :
<br/>      -    C'est le tueur de chevalier, ou le contaminateur. Depuis que l'ordre existe, il pourchasse un à un les chevaliers et les tue sans aucune pitié. Sa magie est puissante et nous n'avons jamais réussi à s’en débarrasser, Jasson, comment ça se fait qu'il t’ait contaminé et non pas tué ?
<br/>Le chevalier pleura. Et demanda à ce que ses frères d'arme sortent un instant de la chambre. Selestan sortit sans discuter, Xalendan tenta de négocier mais finit par sortir, par contre Chloé ne se sentant pas concernée, ne bougea pas. Ce n'est que lorsque l'elfe lui demanda de sortir qu'elle émit un grognement et se résigna à rejoindre les autres à l'extérieur.
<br/>      -    Alors ! le pressa Laziador.
<br/>      -  Mais pauvres fantômes... couina Jasson complètement désemparé, c'est eux qui m’ont sauvé... Et je ne pourrai jamais les revoir...
<br/>Le chevalier pleura de plus belle. Les yeux de l'elfe s'écarquillèrent.
<br/>      -    Sois plus clair, qu'est-ce qui s'est passé, des fantômes ?...
<br/>      -  J'avais des fantômes... Et ils sont intervenus pour me sauver la vie quand la dague de Dagonor allait m'achever. Ils sont arrivés de nulle part, ont contré l'attaque du démon et ont disparu juste avant que je m'évanouisse, je pense que c'est à ce moment là qu'il m'a mordu...
<br/>      -    D'où viennent tes fantômes ? s'énerva Laziador.
<br/>Jasson n'avait jamais vu le professeur s'énerver, cette expérience ne lui plut guère, il avait maintenant une plus grande pression.
<br/>      -    Je... Je... C'est à la bibliothèque qu’ils sont apparus pour la première fois, qu'ils m'ont appris qu’ils étaient mes anges gardiens. Ils m'ont dit qui ils étaient, pourquoi ils m'avaient choisi... Pour simplifier.
<br/>L'elfe parut étonné, il lui demanda pourquoi ses fantômes n'étaient pas revenus après leur disparition.
<br/>      -    Parce qu'ils devraient ?
<br/>      -  Bien sûr, les fantômes ne meurent que lorsque celui qu’ils ont choisi, l'olpha-um, est décédé. Ils ont créés une barrière autour de toi, celui qui aurait dû te toucher à ce moment là, a touché la barrière, quand ça se produit, les fantômes disparaissent pendant un quart d'heure à peu prés, et l'homme, le démon ou l'être qui a touché la barrière est transporté alors à une quinzaine de kilomètres de l'olpha-um. Bizarre qu’ils ne soient pas revenus... Sinon, comment ça se fait que tu as plusieurs fantômes ?
<br/>      -   C'est parce qu'ils sont frères, dit simplement Jasson qui sentit la fatigue le ressaisir. Et d'après le démon, les fantômes ne reviennent pas parce que je suis en transformation, et comment savez-vous tout ça sur les fantômes ?
<br/>      -  Disons que mon peuple a toujours eu une certaine fascination pour les olpha-um... Chez nous les elfes qui ont des fantômes sont rares et vénérés.
<br/>      -   Vous êtes un elfe, s'émerveilla le chevalier en souriant comme il pût...
<br/>Ses yeux se fermèrent, il eut juste le temps d'entendre Laziador s'écrier : " nous allons te sauver, je te le promets ! ". Jasson sombra ensuite dans l'inconscience, une nouvelle fois.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>14.
<br/>
<br/>** Fin des vacances **
<br/>
<br/>
<br/>
<br/>Selestan entra avec ses deux frères d'arme dans la chambre, avec l'autorisation de l'elfe. Le chevalier avait compris que Jasson voulait gardait des choses secrètes, il avait ravalé ses réflexions quand on lui demanda de sortir... Mais dès que Jasson irait mieux, le jeune homme voudrait à tout prix des réponses. Pour le moment, il fallait atteindre le Lloclavr avec Jasson en vie, et surtout sans que celui-ci n'ait mangé un de ses compagnons, cette pensée le fit sourire. Selestan avait besoin de rire pour se remettre les idées en place, c'est ainsi que fonctionnait ce chevalier, autant il peut être très sérieux, autant il peut être très espiègle. C'est pour cette raison que l'humour noir l'avait envahî, il rigolait silencieusement en imaginant Jasson en train de s'affaler sur Chloé et en train d'arracher les boyaux de la jeune femme avec ses dents. C'est la voix elfique de Laziador qui lui remit les pieds sur terre.
<br/>      -    ...Nous partons dans une heure... Avec un peu de chance, nous arriverons à Zervitch pendant la nuit.
<br/>      -    On va marcher pendant la nuit ! Mais les rôdeurs, les bandits, les bêtes sauvages sans oublier le monstre qui a mangé un morceau de la jambe à Jasson, s'inquiéta Chloé.
<br/>La façon dont Chloé avait parlé de la morsure subie par le chevalier fit rire Selestan... Il s'excusa et écouta la réponse du professeur qui fût sèche :
<br/>      - Vous êtes maintenant des chevaliers aux dons exceptionnels ! Quelques bandits ou bêtes sauvages ne doivent pas vous faire peur comme à des gamins ordinaires, pour ce qui est du Caomme, j'en ferai mon affaire...
<br/>Il avait dit ses derniers mots avec une voix qui en disait long sur son désir de vengeance. Le professeur les laissa aller se préparer, après une longue hésitation, Laziador décida de laisser encore un peu Jasson avec un garde pour sa protection. Lui aussi alla se préparer pour le long voyage qui les attendait.
<br/>
<br/>
<br/>
<br/>
<br/>Une demi-heure s'écoula, Jasson dormait à poings fermés... Jusqu'à ce qu'il se réveille, comme si tout ce qui s'était passé n'était qu'un rêve. Au départ, il crut que c'était le cas et s'étira avec soulagement. Le chevalier leva ensuite la tête et aperçut le garde, gisant au sol dans une marre de sang. Il ne put s'empêcher de s'exclamer à voix basse :
<br/>      -    Bouillie infâme sanguinolente...
<br/>Ses mots lui étaient sortis de la gorge à son grand étonnement. Ses paroles n’étaient pas les siennes mais c'est lui qui les avait dites.
<br/>      -    L'esprit du Chaos commence à s'infiltrer en toi, c'est très bien, dit une voix familière.
<br/>Jasson tourna la tête et aperçut Dagonor devant la porte.
<br/>      -    C'est bien moi, affirma t-il en s'avançant vers le jeune homme, je suis venu t'expliquer la suite de ta mutation...
<br/>Le chevalier lui cracha au visage mais Dagonor ne réagit pas, il prit la salive de Jasson avec le doigt et l'avala. Se geste provoqua un haut le cœur suivit d'une grimace chez le chevalier.
<br/>      -    C'est bien ce que je croyais... dit Dagonor en suçant son doigt. Je t'explique, à partir de maintenant, vu que mon venin corrompu coule dans toutes tes veines, ta mutation ne se déroulera que pendant la nuit. Aussi le jour, tu seras un humain normal... Avec du sang de mutant. Je te préviens, tes nuits seront horribles ! Petit à petit tu auras une queue qui apparaitra, ta couleur de peau va changer... Enfin tu verras bien tout ça...
<br/>Un bruit de pas se dirigeant rapidement vers la chambre fit couper net la conversation. La porte s'ouvrit, le démon eut un dernier rire sadique avant de disparaitre. Laziador se précipita vers le chevalier.
<br/>Le professeur eut un léger remord en voyant le garde mort près de la porte.
<br/>      -    Que s'est-il passé ? ça va ?
<br/>      -   Je ne me suis jamais senti aussi bien, lança Jasson avec joie, il y a Dagonor qui m’a rendu une petite visite... Très instructive.
<br/>L'elfe fronça les sourcils, signe que Jasson avait compris comme une demande d'explication, alors il récita exactement ce que lui avait dit le Caomme.
<br/>      -   Effectivement, très instructif... commenta Laziador, nous partons pour le...
<br/>Jasson le coupa en lui disant qu'il avait tout entendu dans son sommeil. Le professeur hocha de la tête :
<br/>      -    Bien, va préparer tes affaires en vitesse, nous parlerons pendant le voyage…
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>Chloé venait de finir la préparation de sa valise. " Mon cheval ne supportera pas le poids du sac " songea-t-elle. Elle haussa finalement les épaules et commença la descente avec la valise, la fée à ses côtés. Quand elle arriva en bas, Selestan et Xalendan étaient déjà là, ils saluèrent Sastibive chaleureusement, les chevaliers s'étaient vite habitués à la présence du petit être (Sastibive ne suivra pas les chevaliers pour ce voyage). Ils commencèrent à discuter en attendant Laziador, à plaisanter, mais le cœur n'y était pas, chacun pensait à l'avenir de Jasson.
<br/>Laziador arriva ensuite.
<br/>      -    Et Jasson...  commença Chloé.
<br/>Elle ne continua pas car elle aperçut le chevalier descendre les marches avec assurance un peu plus loin. Chloé esquissa un cri avant de se mettre la main devant la bouche.
<br/>Jasson trottina vers eux... Il s'arrêta devant ses frères d'arme et salua tout le monde, puis s'exclama :
<br/>      -    J’espère que je ne vous ai pas manqué !
<br/>Selestan avait les yeux écarquillé par l'étonnement, la bouche Xalendan était bée et ses yeux, brillant... Quand à Chloé, elle pleurait de joie. Jasson avait l'air en pleine forme, d'une aptitude à peine croyable : il avait parlé sur un ton joyeux. La jeune femme souffla pour elle : " si, tu nous as manqué... ". Sastibive était la seule qui avait entendu mais n'en dit rien.
<br/>Chloé fut la première à se jeter sur Jasson et à le prendre dans ses bras de toutes ses forces, les deux autres suivirent et ils furent bientôt tous les uns contre les autres, comme des frères réunis.
<br/>      -    Ca ne faisait qu'une demi journée que j’étais évanoui et déjà vous me sautez dans les bras, qu'est-ce que ça aurait été si ça avait duré une semaine.
<br/>      -    Tu n’es plus malade ? demanda Xalendan.
<br/>Sa voix était marquée par l'angoisse... Chloé se surprit, en attendant la réponse, à avoir un sentiment d'anxiété qui devait se lire sur son visage ; car Jasson l'avait regardé d'un air qui ne trahissait pas sa vulnérabilité. Ses sourcils descendaient légèrement vers l'extérieur de son visage, ses yeux étaient chargés de désespoir.
<br/>      -    Malheureusement, je suis paralysé par cette maladie que je ne peux combattre...
<br/>Il avait baissé la tête en parlant, accablé par ce qui lui arrivait.
<br/>      -    Nous allons t'emmener chez les elfes, ils vont te sauver ! s'exclama Selestan avec optimisme.
<br/>      -    Si je survis au voyage... rétorqua le chevalier.
<br/>Cette réponse néfaste écrasa les derniers sentiments de bonheur des adolescents. Laziador, qui était resté à l’écart pendant tout l'échange, s'avança soudain vers eux. Avec le charisme que dégageait ce professeur, les jeunes ne tardèrent pas à s'écarter.
<br/>      -    Je jure sur l'honneur que quand nous reviendrons, tu seras sain et sauf !
<br/>L'elfe avait dit ses mots avec une telle conviction que le moral des chevaliers remonta d'un coup.
<br/>Sur ces quelques paroles, la petite troupe partit à cheval pour le Lloclavr... sauf qu'il faut préciser que Selestan montait trop fièrement sa licorne. Malheureusement pour lui, une heure après le départ du groupe, cela sauta aux yeux de Chloé qui commença à s'énerver :
<br/>      -    Ca va Selestan, on le sait tous que c'est une sublime licorne qui te sert de cheval... Mais là faut pas abuser, ça devient lassant.
<br/>La victime regarda les autres d'un air suppliant. Cela énerva encore plus Chloé :
<br/>      -    Pas la peine de les regarder comme ça, ils confirment tout à fait ce que j'affirme, n'est ce pas Jasson ?
<br/>Celui-ci lança un bref regard à Selestan puis il leva la main comme pour se protéger, baissa la tête et fronça légèrement les sourcils.
<br/>      -    Bah... Je.... Heu... Peut-être... Mais en quoi ça te regarde que Selestan se vante !
<br/>A la fin de sa phrase, le chevalier enleva toute protection de son visage, leva la tête d'un air provoquant et lança un lourd regard de défi sur Chloé.
<br/>La jeune femme maintint le regard de Jasson. Ce regard provocateur se transforma rapidement en un regard noir. Xalendan décida d'intervenir, il se positionna entre les deux adversaires et posa chacune de ses mains sur une épaule d'une façon amicale. Aucun d'eux n'avait bougé. Il sourit à ses  frère et sœur d'arme :
<br/>      -   Vous êtes extrêmement têtus... En plus pour vous je trouve que c'est une qualité, mais ça sert à quoi de faire ce que vous faites !
<br/>Les deux chevaliers ne bronchèrent pas. Xalendan fit un signe a Selestan qui vint se placer derrière Jasson.
<br/>      -    Un... Deux... chuchota Selestan
<br/>Quand les deux acolytes s'exclamèrent ensemble : "3", ils poussèrent Jasson et Chloé par terre. Chloé se retrouva malgré elle sous Jasson qui ne bougeait plus.
<br/>      -    Sort de là !! cria-t-elle en se dégageant de Jasson.
<br/>Le chevalier s'était écroulé inerte sous la poussée de la jeune femme, les yeux fermés, il ne bougeait plus d’un cheveu, le visage impassible. C'était la fin de Jasson.
<br/>      -   NON !! s'écria Chloé en se précipitant vers le chevalier au sol.
<br/>Ses larmes coulaient abondamment. Tout à coup, comme ressorti de la mort, Jasson attrapa Chloé et la mit par terre avant de l'embrasser tendrement. Les deux autres, qui avaient compris depuis le début, la supercherie, s'étaient éclipsés discrètement.
<br/>      -    Euh... les tourtereaux ! Vous n'avez normalement pas le droit de faire ça... dit Laziador avant de s'interrompre.
<br/>      -    Excusez- moi... répondit Jasson
<br/>L'elfe eut un mouvement vers sa bouche qui voulait dire : "oh... mince".
<br/>      -    J'espère que tu n’as pas refilé le virus à ta sœur d'ar...
<br/>Chloé eut un mouvement de recul, elle tremblait de tout son être. Laziador se précipita vers la jeune femme et lui mit un coup de genou dans le ventre. La puissance du coup aurait pu la tuer... Heureusement, elle se contenta de vomir. Ayant vu le coup d'un peu plus loin, Selestan et Xalendan coururent vers le professeur, épées à la main. L'elfe esquiva habilement, gracieusement, souplement et facilement les attaques avec arme de ses élèves. Il frappa les jambes de Xalendan qui tomba sous le choc. L'elfe arracha ensuite l'épée à Selestan et lui planta son manche dans le ventre. Le chevalier s'écroula en criant de douleur.
<br/>      -  Voila ce qui arrive quand on n’a pas de tête ! dit calmement Laziador, votre geste aurait été le bienvenu si seulement, j’étais maléfique...
<br/>Il aida les deux garçons à se relever et continua :
<br/>      -   J'ai mis un coup dans le ventre de Chloé pour qu'elle vomisse le satané microbe que Jasson lui avait donné...
<br/>      -    Vous voulez dire que je me serais transformée en minaos ! intervint Chloé.
<br/>Elle allait beaucoup mieux, on ne remarquait presque pas le coup qu'elle s'était pris.
<br/>      -   Non... Heureusement... Mais tu aurais était paralysée pendant quelques jours. Maintenant, trêve de bavardage, en route.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>Selestan et le groupe avait chevauché toute la journée, ils s’étaient juste arrêter pour mangé et pour les besoins pressants. L'ancien chasseur, habitué à la vie sans repos et à la chevauchée continuelle, n'avait aucun mal à supporter le voyage. Ce n'était pas le cas des trois autres chevaliers qui se tordaient de douleur, surtout au niveau du derrière. Ils maudissaient tous leur cheval, à part Selestan qui bavardait avec sa licorne:
<br/>      -    Ca ne t'a rien fait que je sois sur ton dos pendant toute la journée ?
<br/>      -    A vrai dire, c'est vrai que tu pèses lourd, mais sinon, tu n'as vraiment pas à t'en faire. Sinon, toi et tes fesses ?
<br/>Selestan sourit en répondant qu'il en avait trop l'habitude pendant son enfance pour qu'une seule journée de chevauchée ne le fasse souffrir.
<br/>Les étoiles étaient belles, tout le monde s'apprêtait à se coucher quand Jasson poussa un horrible cri de douleur. Sachant très bien d'où ça venait, Laziador se rendit à ses côtés, suivi des chevaliers. Il s'arrêta à deux mètres, le jeune homme poussait de grands hurlements, ses yeux étaient rouges et un filet de sang sortait de sa bouche.
<br/>      -   Soif !... S'exclama du mieux qu'il pouvait le jeune homme.
<br/>Jasson avait en effet, pendant toute la journée, maîtrisé sa soif de sang... Mais un mutant ne peut contenir longtemps son désir de sang. L'elfe prit un couteau de sa poche et se coupa légèrement sur une partie du bras. Chloé esquissa un cri et se cacha les yeux en voyant le couteau du professeur finir son action. Laziador prit ensuite un récipient pour y laisser couler le sang qui sortait abondamment de son bras. Aucun signe de douleur ne traversa le visage fin de l'elfe. Jasson bavait devant ce récipient, dans lequel coulait pour lui, de l'eau. Le professeur tendit au jeune homme le bocal rempli à ras bord, il se comprima ensuite la plaie. Jasson but le contenu du pot avec fougue et rage, quand il eut fini, il beugla un son qui ne trahissait pas son ravissement. Le garçon lança alors un regard rempli de gratitude vers l'elfe avant de s'écrouler sur le sol et de s'évanouir. Il devint alors tout lumineux, la lumière bleue... Malgré son bras ensanglanté, le professeur s'avança vers le chevalier, inquiet. Les autres regardaient la scène bouche bée, stupéfiés.
<br/>      -    Il la perd... marmonna l'elfe pour lui même.
<br/>Chloé, avec sa spontanéité habituelle, répliqua nerveusement :
<br/>      -    Qu'est-ce qu'il perd ?
<br/>L'elfe eut un sourire forcé :
<br/>      -    Ce n'est pas encore le moment.
<br/>Sur cette phrase énigmatique, Laziador partit se coucher. Chloé allait le rappeler mais Xalendan lui mit doucement la main sur l'épaule et attrapa de son autre main celle de la jeune femme et la serra tendrement.
<br/>      -  Je pense aussi que ce n'est pas le moment... Nous sommes tous fatigués, y compris toi, je te promets que demain je ne dirai rien si tu lui poses des questions...
<br/>      -    Mais...
<br/>Xalendan la prit soudain dans ses bras en la coinça tendrement contre lui. Ce qui coupa le souffle à la jeune femme, elle ne bougea pas, surprise et ne sachant comment réagir.
<br/>Finalement, elle le repoussa violement et le regarda avec férocité :
<br/>      -    Seul Jasson a le droit de me faire ça !!
<br/>Puis elle partit en pleurant.
<br/>Le lendemain, quand Selestan se réveilla, Jasson était assis sur un gros rocher et regardait le paysage d'un air triste. Le chevalier se dirigea vers le mutant, celui ci tourna la tête vers lui. Les yeux de Jasson étaient entièrement rouges, sa peau donnait l'impression d'avoir été brûlée vive. Le visage impassible, Jasson l'invita à s'asseoir à ses cotés, Selestan s'exécuta.
<br/>      -    Cette nuit, comme me l'a prédit Dagonor, a été atroce... je...je m'en souviendrai toute ma vie...commença Jasson
<br/>      -    Tu n’es qu’au début de tes souffrances ! interrompit une voix démoniaque que Selestan ne reconnaissait pas.
<br/>Dagonor apparut alors devant eux. Selestan poussa un cri de rage, se maudissant de ne pas avoir pris son épée. Il allait lancer un sort mais Jasson l'arrêta et dit d'une voix lasse :
<br/>      -    Que veux-tu ?
<br/>Le Caomme regarda Jasson et un sourire se dessina sur son visage à la peau rouge foncé.
<br/>      -   Tu commences à t'habituer à me voir, c'est très bien... Je me demande même si je ne devrais pas te rajouter un gène pour que tu deviennes Caomme, comme moi. Nous ferions une bonne équipe tous les deux...
<br/>      -    DEGAGEZ !! le coupa Selestan.
<br/>Ce cri réveilla tous ses compagnons. Dagonor tourna doucement la tête vers la provenance du son.
<br/>      -    Selestan, c'est ça ? Ne t'inquiète pas, je ne vais rien vous faire... C'est Jasson qui vous tuera quand sa mutation sera finie...
<br/>      -    DAGONOR !! s'écria Laziador qui revenait d'une petite excursion.
<br/>Chloé et Xalendan se réveillèrent en trombe et regardèrent un instant le Caomme les yeux écarquillés avant de saisir leurs armes. Une longue épée à une main et un tranchant apparurent dans les mains de l'elfe. Un léger "waha..." sortit de la bouche de Xalendan.
<br/>      -    Ca fait longtemps que tu n'es pas apparu devant moi ! Traqueur Dagon.
<br/>Dagonor serra les dents et ouvrit la "bouche", laissant apparaitre des dents noircies.
<br/>      -    Seuls ceux de ma race ont le droit de m'appeler comme ça,  Prince !
<br/>L'elfe fronça les sourcils. Durant la fraction de seconde où Selestan cligna des yeux, Dagonor disparut. Tous les chevaliers eurent du mal à quitter des yeux l'endroit où s’était tenu, a l'instant, le Caomme. Sauf Jasson, qui avec un soupir, partit d'un pas las, se dégourdir les jambes.
<br/>      -    J'ai besoin d'être seul, alors s'il vous plait ne me suivez pas, lança Jasson d'une voix calme et assurée.
<br/>
<br/>
<br/>
<br/>
<br/>Jasson entra dans un petit bois où il s'assit en silence sur un tronc d'arbre coupé. Il sentit alors une autre personne derrière lui. Sans se retourné et d'une voix calme, Jasson s'exprima :
<br/>      -    Dagon... dit, c'est comment, là d'où tu viens.
<br/>Des bruits de pas se firent entendre. Dagonor s'assit à coté du chevalier, sur une grosse roche lisse.
<br/>      -    Eh bien... C'est l'enfer, mon pote.
<br/>      -    Comment ça l'enfer, je m'attendais à ce que tu dises que c'était super.
<br/>Dagonor expira profondément en regardant par terre.
<br/>      -    Ouais... C'est ce que j'aurais dû dire mais... ça aurait été un mensonge.
<br/>      -    Pourtant, dans tes actes, tu laisses penser que tu adores le mal.
<br/>Le Caomme tourna la tête vers le chevalier en déclarant :
<br/>      -    Crois-tu que j'ai le choix ?
<br/>      -    Je ne sais rien du Chaos et puis je ne suis ni pour le bien, ni pour le mal, je suis pour l'équilibre.
<br/>Une larme rouge coula sur la joue du démon. Il parvint pourtant à sourire légèrement.
<br/>      -    C'est également ce que je pensais être... Mais les dieux sont trop puissants et ne supportent pas les personnes neutres, impossible de leur résister.
<br/>      -    C'est pour ça que tu traques les chevaliers ?
<br/>Dagonor hocha simplement la tête en guise de réponse. Laziador apparut à ce moment là, son épée a la main. Il allait porter le coup décisif au Caomme mais celui-ci disparut une fraction de seconde avant.
<br/>      -    TU ES FOU !! Rester avec ce démon sans rien faire, Jasson, tu me déçois beaucoup ! s'écria l'elfe.
<br/>      -    Très bien, je ne veux plus être chevalier, laissez moi et repartez au palais.
<br/>Le professeur eut l'air surpris, mais attrapa quand même Jasson par le bras et le traina jusqu'au campement qui avait été rangé. Dès qu'ils furent arrivés, Jasson se défit de l'emprise du professeur.
<br/>      -    A quoi bon se battre alors que ce sont les dieux, nos ennemis !!
<br/>Laziador le regarda avec un sourire.
<br/>      -    Je ne sais pas ce qu'a pu te dire le démon mais les dieux n'existent pas ! Quelle preuve as-tu pour dire qu'ils existent...
<br/>      -    Et vous, quelle preuve avez vous pour dire qu'ils n'existent pas !!
<br/>Le jeune homme et l'elfe se fixaient avec colère. Même un mammouth rose n'aurait pas fait détourné leurs yeux l'un de l'autre.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}