function C() { var choice = "Continuer#Nouvelle vie";var texting = `
<br/>
<br/>** Des explications **
<br/>
<br/>
<br/>Dès que Jasson fût arrivé au château impérial, on lui demanda d’aller attendre avec les autres chevaliers dans la grande salle. Le jeune homme était impressionné  par la beauté des lieux. Alors qu’il avançait au côté de son recruteur dans les longs couloirs du château, celui-ci lui fît savoir qu’ils ne se reverraient probablement pas avant très longtemps. Le recruteur le fît rentré dans une grande salle et lui signala sont départ d’un signe de main. Il attendit plusieurs heures, de nouveaux recrutés entraient dans la salle assez régulièrement. Finalement, après des heures d‘attentes, un grand homme entra, suivi de plusieurs chevaliers. L’homme dégageait une aura forte, si bien que quand il commença à parler, tout le monde se tourna vers lui et le silence se fît :
<br/>      -   Après vos voyages, qu’ils aient été longs ou courts, nous allons vous demander de nous montrer vos talents... Je n’ai qu’une chose a dire, que les tests commencent !
<br/>Il y eut trois files d'attente, une pour la magie, une autre pour le combat rapproché et une pour les combats à distance.
<br/>Jasson se faufila dans la partie pour la magie. C'était la moins remplie, la partie "combat rapproché" était remplie à bloc, il remercia les dieux de ne pas être dans cette catégorie. On lui demanda de montrer ses talents, puis on lui prit la tête entre les mains, comparé à la fois précédente (au recrutement) il sentit une puissance inconnue l'envahir. Il en avait fermé les yeux, son corps frissonna d‘effroi…
<br/>Après que le dernier chevalier soit passé aux tests, tous les récents chevaliers se mirent en face du grand homme. Celui-ci dit de manière directe :
<br/>    -   Chloé diColto*, Selestan,  Jasson et Xalendan resteront là ! Que les autres me suivent...
<br/>Jasson fût surprit d’entendre son nom, il ne bougea pas, comme il avait été ordonné.
<br/>Les quatre sélectionnés se rendirent à l’étage de l'empereur. Ils furent prié d’attendre derechef dans une salle cette fois plus petite et plus ornementé, l’or et les pierres précieuses étaient de mise aux quatre coins de cette magnifique pièce.
<br/>      -	Selestan, dit celui- ci à Xalendan en lui tendant la main.
<br/>-	Xalendan, répondit-il en lui serrant la main.
<br/>Après avoir échangé les salutations, ils bavardèrent un bon quart d’heure. Pendant ce temps, Jasson admira la belle jeune femme qui se trouvait à quelques pas de lui.
<br/>-	Salut, dit Chloé en le voyant
<br/>-	Sa...lut… balbutia Jasson encore sous le coup de foudre.
<br/>« Elle est tellement belle… » pensa le garçon. Le jeune homme ne savait pas se qu’il ressentait. Pour tout dire, il ne s’était jamais intéresser aux filles malgré l’intérêt que portait les autres garçons de son âge au sexe opposé. C’était toujours comme si une force invisible venait le dissuader de pensée à l’amour. En ce moment, ce sentiment d’attirance était présent.
<br/>-	Je m’appelle Chloé, reprit-elle.
<br/>-	Enchanté, moi c’est Jasson, répondit-il, prêt à se ressaisir.
<br/>Le silence se fît, apparemment les deux parties ne savaient pas quoi dire.
<br/>      -	J’ai 16 ans, et toi ? demanda Chloé en regardant le jeune homme.
<br/>
<br/>*Dans ce monde, les noms de famille n'existent pas pour les humains, sauf pour les grandes familles riches ou/et influentes.
<br/>-	Pareil, s’exclama Jasson en essayant de contenir sa joie.
<br/>Leurs regards se croisèrent… Les yeux de cette jeune femme étaient si envoutant, si beau !
<br/>Xalendan arriva à ce moment, il fît un clin d’œil à Selestan… Celui-ci eu un sourire moqueur :
<br/>      -    Et bien ! Vous n’êtes pas du genre à y aller doucement !
<br/>Jasson regarda ces chaussures… Chloé se contenta de se présenter aux deux autres sans faire attention à la réflexion. Jasson finit par se mêlée à la discussion. Le jeune homme apprit qu’ils venaient chacun d’un endroit totalement différent. La porte s’ouvrit d’un coup, plusieurs domestiques entrèrent et les invitèrent à se rendre à l’audience que leur avait accordé le roi.
<br/>-	Ne faites pas attendre son altesse, lança une servante.
<br/>-	Il attendra comme tout le monde ! répliqua Chloé, nous n’allons tout de même pas courir !
<br/>Jasson admirait de plus en plus le caractère de la jeune femme, qui l’attirait comme un aiment. Elle était tellement belle. Il dut faire un effort surhumain pour ne pas la prendre dans ses bras et l’embrasser. Jasson découvrait l‘amour, cette sensation illuminait son cœur et son esprit tel le soleil en hiver.
<br/>
<br/>
<br/>
<br/>
<br/>Chloé se comportait avec ce jeune homme d’une manière différente, comme si une force invisible l’avait poussée à parler la première. Elle marchait en suivant les pas des servantes, perdu dans ces pensées.
<br/>Ils arrivèrent finalement dans la salle d’audience de l'empereur, celui-ci les accueillit avec joie. Il était petit, à l’air joyeux, bien bâti, sa couronne et son sceptre brillaient dans la salle.
<br/>-	Bienvenue ! Mes enfants, dit chaleureusement l'empereur, assit sur son trône.
<br/>-	Bonjour, dirent les nouveaux chevaliers en mettant respectueusement le genou au sol.
<br/>L’empereur leur lança un sourire radieux et prit la parole :
<br/>      -    Levez-vous je vous prie.
<br/>Tous s’exécutèrent en attendant que l’homme continu son discours.
<br/>-    Vous ne savez sûrement pas ce que vous allez devenir, j’avais ordonné au recruteur de ne rien vous dire. J’ai décidé que vous seriez les nouveaux chevaliers d’élite ! Les meilleurs. Ceux que l’on nomme : les chevaliers du Sphinx.
<br/>Chloé vit l’expression de surprise sur le visage du dénommé Selestan.
<br/>-	Je croyais que c’était une légende ! s’écria celui-ci.
<br/>Fils de marchand, Selestan avait beaucoup voyagé et entendu un nombre incalculable d’histoires et de légendes.
<br/>-	Non, ils existent et vous avez été élus pour en devenir les membres. J’ai décidé de faire ressuscité cette Ordre.
<br/>-	Les membres de quoi ? demanda Xalendan qui, lui, n’avait jamais mit les pieds hors de son
<br/>village jusqu'à maintenant.
<br/>-	De l’Ordre du Sphinx, expliqua l’empereur. Un Ordre très ancien qui fait régner la paix et la
<br/>justice. Enfin… Pour résumé, c’est ça. Je suis vieux, comme vous pouvez le voir, alors ma fatigue m’atteint rapidement, je voulais juste vous voir de mes propres yeux, pour la suite, je vous confit à Dalritas… Pour le moment, je vous conseille d’aller prendre connaissance de vos quartiers au 10ème étage de la tour du château.
<br/>-	10ème !! Mais c’est… Coupa Chloé avant de se faire interrompre.
<br/>-	Haut… Je sais, mais c’est pour que le peuple n’y accède pas car l’Ordre du Sphinx est
<br/>secret ! coupa l'empereur amusé. Et puis ça vous musclera les jambes !
<br/>Chloé fît la grimace et sortit de la salle. Ils furent ensuite accompagnés par un garde, qui leur indiqua le chemin.
<br/>Ils grimpèrent donc les marches, la longueur du trajet leur permettait de faire plus ample connaissance.
<br/>Chloé, décidée à mieux faire connaissance avec Jasson, se rapprocha de lui.
<br/>« Pourquoi je suis attirée par lui comme un aimant. » se demanda-t-elle. 
<br/>« Cette fois, pas question de parler la première… »
<br/>Mais malheureusement pour elle, Jasson fût complètement déboussolé dès qu’elle l’eut approché et il n’arrivait plus à produire un son. Finalement, elle se sentit ignorée par le jeune homme et elle s’énerva…
<br/>La jeune femme colérique lui mit un coup dans les jambes et il s’effondra par terre, se cognant le nez contre une marche.
<br/>-	Pourquoi tu as fait ça, dit Selestan en relevant son récent compagnon.
<br/>Xalendan essuya le sang qui coulait abondamment du nez de Jasson.
<br/>-	Pas fait exprès, déclara-t-elle d’une voix hautaine.
<br/>-	Ce n’est pas vrai, je t’ai vu et tu étais parfaitement consciente de tes actes, répliqua Selestan.
<br/>-	Il m’a ignoré !! s’écria-t-elle en regardant Jasson droit dans les yeux.
<br/>Son regard fit tressaillir le garçon qui détourna les yeux.
<br/>-	Regardez ! Il continue, dit-elle en se dirigeant vers lui.
<br/>Elle lui prit la tête et le força à la regarder dans les yeux. Ce regard l’effraya et il la repoussa, incapable de produire un son.
<br/>« Elle me déteste, à coup sûr. » pensa Jasson.
<br/>Chloé lui lança un dernier coup d’œil féroce et elle partit en courant vers le haut des escaliers.
<br/>-	Quel sale caractère ! lança Xalendan en regardant la jeune femme monter les escaliers à toute
<br/>allure.
<br/>-	Non, je n’aurais pas dû l’ignorer, répliqua Jasson.
<br/>-	Oui, mais elle n’aurait jamais dû réagir comme ça ! se révolta Selestan.
<br/>-	Non mais c’est…
<br/>-	Bon ! On continue à monter, le coupa Xalendan.
<br/>Chloé avait utilisé la magie pour entendre ce qu’ils disaient, elle fût surprise que Jasson la défende après ce qu'elle lui avait fait. Tout à coup, elle sentit une énorme passion et attirance pour ce jeune homme qu’elle connaissait à peine et elle se jura d’aller lui présenter des excuses.
<br/>Elle arriva donc en premier en haut et admira le spectacle qui l’attendait, un tapis rouge foncé s’étendait dans un long couloir, sur une moquette rouge moelleuse. Sur les murs étaient gravés et peints de fresques de très grands artistes. Le plafond était orné d’or et d’argent. Elle avança en se demandant comment elle avait mérité tout cela. Le château de son père était vraiment modeste à coté de ce décor. Elle marcha dans le couloir, dépassa plusieurs portes qu’elle n’osa pas ouvrir, puis tomba sur l’une d’elle où il y avait gravé : « salle commune des quatre chevaliers »
<br/>Elle ouvrit la porte et se trouva dans une pièce ornée de rubis et de diamant. Sur les cotés de l’immense pièce, il y avait des étagères avec une multitude de livres et plusieurs tables ; ainsi que des fauteuils et des canapés. Elle referma la porte et continua son avancée.
<br/>Plus loin, il y avait une porte avec comme motif gravé : « Jasson »
<br/>Comprenant qu’il s’agissait des quartiers de Jasson. Elle se mit en quête de trouver son logis. Elle le trouva. Elle ouvrit la porte et resta bouche bée. Une immense pièce était devant elle. Au milieu une fontaine, autour des fauteuils et des canapés, des armoires, des étagères et des livres, des tables, le tout dans une immense splendeur.
<br/>Elle ouvrit la deuxième porte, celle de sa chambre, avec un grand lit, une grande étagère, ainsi qu’une petite table de nuit.
<br/>Elle ouvrit la troisième porte et y trouva une grande table pleine de nourriture.
<br/>Chloé s’assit et commença à manger, affamée par le voyage. Un cri d’exclamation venant de ses récents compagnons retentit. Elle comprit leur arrivée. Elle se prélassa une demi-heure, des questions commencèrent à lui tarauder l’esprit. Comment, en seulement quelques minutes, les portes avaient-elles pu être gravées de leurs noms… Le test pour trouver les sélectionnés avait été rapide, peut-être avait-il été truqué ? Non… Sûrement pas…
<br/>Elle alla dans la salle commune où elle espérait trouver les trois autres. Elle y trouva seulement Jasson ; celui-ci était devant un livre, se demandant ce que l’encre noir pouvait bien vouloir dire. Il ne s’aperçut même pas de son entrée dans la pièce.
<br/>Chloé se glissa sans faire de bruit derrière lui. Elle lui mit ses mains sur les siennes doucement, c’est alors qu’il sentit sa présence. Elle mit son menton sur son épaule et colla sa tête contre la sienne. Quand elle se rendit compte de ses actes, ils avaient déjà été effectués. Jamais elle n’avait été aussi entreprenante avec un garçon, surtout qu’elle ne connaissait ce jeune homme que depuis très peu de temps.
<br/>-	Je suis désolée pour ce que j’ai fait tout à l’heure, lui dit elle à l’oreille.
<br/>-	Ce n’était pas ta faute, répondit Jasson tristement, quand tu es là, je me sens bizarre, j’aime ta présence, mais je ne peux plus produire de son.
<br/>Cette réponse la fit sourire, « ainsi, il éprouve des sentiments pour moi » pensa-t-elle.
<br/>Alors elle le prit dans ses bras, l’emmena sur le canapé où elle lui envoya un regard amoureux. Jasson ne put s’empêcher de tendre ses lèvres vers celle de Chloé en un baiser. Elle lui rendit son amour et ils s’embrassèrent tendrement. Chloé sentit son cœur battre à tout rompre, une force invisible la poussait-elle à aller si vite ?! Quand ils eurent fini, elle demanda :
<br/>-	Qu'est-ce que tu étais en train de lire ?
<br/>-	Je…je ne sais pas lire… répondit timidement Jasson.
<br/>-	Tu ne sais pas lire ! s’écria Chloé, révoltée.
<br/>-	Je ne suis qu’un fils de fermier, tu sais, et ils n’apprennent pas à lire dans ce milieu pauvre.
<br/>-	Vraiment… Alors je t’apprendrai.
<br/>-	Vrai… merci.
<br/>-	Mais, revenons où nous en étions, dit-elle en l’embrassant de nouveau.
<br/>
<br/>
<br/>
<br/>
<br/>Selestan et Xalendan, quant à eux, avaient trouvé la salle d’entraînement où ils s’entraînaient déjà à l’épée.
<br/>      -      Ah, ah, lança Xalendan en désarmant son adversaire.
<br/>      -   Impressionnant, depuis combien de temps pratiques tu l’art de l'épée ? demanda Selestan.
<br/>      -   A vrai dire, c'est la deuxième fois que j'en fais, la première, c'était avec le recruteur, répondit-il.
<br/>Selestan le dévisagea, Xalendan se moquait de lui, lui qui en faisait depuis deux ans, n'avait jamais affronté d’adversaire aussi fort.
<br/>Se sentant honoré, le jeune escrimeur accepta joyeusement sa remarque.
<br/>      -   Bon, montre-moi quelques trucs, histoire que je te résiste, ironisa Selestan en prenant son épée.
<br/>Ils s'entrainèrent toute l'après-midi, Xalendan en tant que "professeur" et Selestan en tant qu'"élève".
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>Jasson, qui avait commencé son apprentissage à la lecture avec Chloé, commençait à comprendre ce que voulait dire les mots "lettre", "alphabet". Il progressait très vite. De temps à autre, Chloé coupait la leçon pour embrasser "son petit ami". C’était comme si ils s’étaient toujours connus.
<br/>Jasson acceptait ces baisers, bien que ça le déconcentrait.
<br/>Durant l’après-midi, il avait appris les "voyelles", les "consonnes" et les "syllabes" ; des mots qui lui étaient complètement étrangers, il y a quelques heures.
<br/>C’est alors qu’il reçut les émotions de quelqu'un, Jasson avait accès à un passé inconnu. Une fille, qui ressemblait à Chloé en plus jeune, répondait à un homme avec caractère... Incompréhensible, le jeune homme ne se contrôlait plus !
<br/>Puis un désir énorme de l'embrasser, d’embrasser Chloé... Il se leva, faisant tomber sa chaise au passage. Une aura bizarre s’échappa de son corps, le voilant intégralement d’un bleu lumineux scintillant.
<br/>      -     Que fais-tu !! s’écria Chloé effrayée.
<br/>Jasson prit Chloé avec force, la souleva de terre et se dirigea vers le bord de la pièce. Chloé toujours dans ses bras qui essayait en vain de s'échapper. Jasson toujours incontrôlable, la plaqua contre le mur, colla son corps contre le sien. Les flammes bleues qui l’entouraient ne cessaient de croitre. La lumière se répandit jusqu'à Chloé, mais le bleu qui entourait la jeune femme était plus foncé et tiré vers le rouge.
<br/>      -    Lâche moi !! se révolta Chloé incapable de résister
<br/>      -    Je t'aime, souffla Jasson d’une voix qui n’était pas la sienne.
<br/>      -    Tu me fais mal !! lâche moi, supplia-t-elle.
<br/>      -    Je t'aime, répéta-t-il de cette même voix étrangère.
<br/>Une sensation l'envahit, une douleur...
<br/>Jasson lâcha immédiatement Chloé, reprenant le contrôle de lui-même. Le jeune homme recula en chancelant. La lumière bleue avait disparu. Chloé s'avança, de la colère dans les yeux.
<br/>     -    Je m’excu....commença Jasson.
<br/>Mais il n'eût pas le temps de finir : Chloé le frappa violemment au visage. Son nez craqua et une flaque de sang gicla. Chloé prit la fuite mais avant d'atteindre la porte elle se souleva de terre, ne pouvant plus avancer. Jasson avait utilisé son pouvoir de lévitation pour la retenir, un geste incontrôlé qu'il se félicita d'avoir effectué. Elle s'apprêtait à utiliser sa magie quand le nouveau chevalier s'écria :
<br/>      -    Attends, NON !! Je n'étais pas moi-même, j'ai vu... Je t'ai vu, tu répondais à un homme barbu de petite taille avec caractère, tu étais très jeune et là... Une envie énorme m’a envahi.
<br/>Jasson avait dit ça tellement vite que sa bouche était sèche.
<br/>      -    C'était l'envie de... songea Chloé, nos pouvoirs se sont sûrement rencontrés et tu as pu voir en moi. Enfin maintenant libères moi... S'il te plait...
<br/>      -    Pourquoi m'as-tu frappé si tu avais la même envie que moi ? demanda Jasson.
<br/>      -    Tu m'as pris mon envie, sans doute, et puis tu m'as fait mal...et j'ai dû te supplier… chuchota-t-elle en rougissant.
<br/>      -    Tu n'aimes pas supplier... se moqua-t-il en la libérant de sa lévitation.
<br/>Il se guérit le nez à l’aide de la magie, il était maintenant épuisé par l'effort magique.
<br/>Il se dirigea vers elle pour la prendre dans ses bras mais elle se dégagea.
<br/>      -    Tu n'as pas été très gentil, dit Chloé en tournant le dos à Jasson.
<br/>Jasson prit la jeune femme et colla son dos contre lui, la soulevant une nouvelle fois de terre.
<br/>      -    J'aimerais avoir les pieds par terre plus d'une minute, se moqua-t-elle, et arrête de me draguer...
<br/>Il l'emmena sur le canapé où il allongea Chloé sur lui. Elle se laissa faire avec un léger sourire.
<br/>      -   Tu n'es pas très diplomate, dit le jeune homme en lui montrant le sang séché sur le sol.
<br/>      -    C'était une discussion assez violente en effet, ironisa-t-elle.
<br/>Et ils s'embrassèrent fougueusement...
<br/>VLAN !! La porte s'ouvrit à toute volée...
<br/>Un homme de grande taille à la musculature surprenante entra, les surprenant en train de s'embrasser. Il ne parut pas surpris, mais son visage montrait sa gêne.
<br/>      -    Je l'ignorerai pour cette fois puisque vous ne connaissez pas encore le règlement de l'ordre, dit l'homme d'une voix grave.
<br/>Il s'éclaircit la gorge et continua :
<br/>      -    Je m'appelle Zagzull, je suis l'entraîneur d'arme lourde de l'ordre... Je suis venu vous informer que le commodore Dalritas vous attend. Veuillez me suivre.
<br/>Rouge de honte, Chloé et Jasson accompagnèrent le dénommé Zagzull.
<br/>Ils traversèrent une porte rouge et descendirent une échelle par une trappe. Enfin ils arrivèrent dans une grande pièce avec une vingtaine de personnes, toutes assises sur des chaises placées en rond. Ces personnes les attendaient, apparemment.
<br/>Un homme petit, âgé d'une soixantaine d'année se leva :
<br/>      -    Bienvenue, nouveaux élus de la confrérie ! Cette réunion portera sur les présentations et sur le règlement, sur les cours et les... enfin bref, vous verrez...
<br/>Trois nouvelles personnes arrivèrent, dont Selestan et Xalendan.
<br/>      -    Ces deux-là commençaient déjà à s'entraîner à l'épée, dit l'homme qui les accompagnait, avec fierté.
<br/>Selestan et Xalendan était en effet en sueur, la respiration haletante.
<br/>      -    Bien... Asseyez-vous, je vous prie, reprit le vieillard.
<br/>Tous les quatre s'assirent avec crainte et fierté. Ils étaient là où très peu de gens étaient allés.
<br/>      -  Je vais vous donner d’abord quelques bases du règlement, commença tout à coup de commodore, on ne doit jamais dévoiler l'existence de cet ordre à qui que ce soit sans mon autorisation.
<br/>      -    Peut-être faudrait-t-il d’abord que vous leur disiez qui on est et qui vous êtes, qui ils sont et ce que l'on attend d'eux, coupa une femme.
<br/>      -    Oui... Oui... Je perds la mémoire d'année en année. Je suis le commodore Dalritas et voici tous vos professeurs, les gardiens du secret de notre existence... Vous êtes les quatre chevaliers du Sphinx, pour l’instant, vous êtes les quatre seuls. On attend de vous que vous accomplissiez des missions pour l'ordre... Je... Est-ce que je leur ai demandé de se présenter ?
<br/>      -    Non commodore, dit un petit homme dont les pieds ne touchaient même pas le sol quand il était assis sur la chaise.
<br/>      -   Oui... Alors toi, dit Dalritas en montrant Selestan, présente toi.
<br/>Après de brève présentation, le commodore continua le règlement, leur dit qu'il ne fallait pas manquer de respect aux professeurs, qu'il fallait obéir un minimum, qu'il fallait respecter les horaires qu'il donna dans la minute qui suivit… Bref, toutes les règles des plus logiques qui existent. Mais une règle retint l’attention de Chloé :
<br/>      -    Vous êtes des frères et sœur d'arme, unis jusqu'à la mort, il ne faudrait pas se laisser distraire par des choses plus avancées...
<br/>La jeune femme sentit le poids des regards qui la fixait.
<br/>      -    Bien, nous en avons fini. Demain, votre premier cours est à dix heures, le seul jour où vous pouvez vous lever tard, profitez-en, termina le commodore.
<br/>En regardant le planning de la semaine, Jasson se dit qu'il n'avait pas tout à fait tort (le planning lui avait été déchiffré par Chloé), le lendemain, il commençait par deux heures "d'athlétisme", même le mot lui échappait. Quand il demanda le sens de ce mot, il se rendit compte que seul Chloé le savait.
<br/>      -   C'est un genre de sport. Le but est de courir le plus vite et le plus longtemps possible, répondit Chloé.
<br/>Xalendan mit ses bras sur les épaules de ces deux frères d’armes.
<br/>      -  Bon... Racontez-nous comment vous avez été recruté, vous... Demanda-t-il à l'adresse de Chloé et de Jasson
<br/>Après avoir raconté leur "exploit", Selestan dit jalousement :
<br/>      -   Vous êtes magiciens, vous deux ! Moi je ne suis qu’un pauvre chasseur qui manie l’arc comme il peut…
<br/>Les mages, dans ce monde, étaient vu comme une sorte de dieu… Les sorciers, quand à eu, bon ou mauvais, étaient bon pour le buché ! Les magiciens étaient ainsi vu comme supérieur, et ça, Jasson le savait et il ne voulait pas être prit pour un dieu, loin de la.
<br/>      -    Oh ! Tais-toi ! Regarde, on a des cours de magie, tu auras vite fait de nous rattraper. Moi, j'ai peine à soulever un caillou magiquement... soupira Jasson.
<br/>Un éclair d'admiration illumina les regards de Xalendan et de Selestan, ils réussirent à le convaincre de leur montrer. Le jeune homme sortit une petite pierre de sa poche, il en gardait une constamment.
<br/>Quand il s'exécuta, les autres en restèrent bouche bée.
<br/>
<br/>
<br/>
<br/>Le lendemain, Selestan se leva avec la tête lourde. Il avait veillé tard dans la nuit. Son réveil sonnait, il était dix heures moins le quart… Il avait pourtant réglé le réveil à neuf heures. *
<br/>Il se leva du lit et se dépêcha de s'habiller, de manger et courut à son premier cours qui devait se passer à l‘extérieur du château. Avec toutes les marches d’escaliers qu'il devait dévaler, il arriva en bas en un temps considérable. Il trouva Xalendan en route, descendant les escaliers tranquillement.
<br/>      -    Que fais-tu, il est dix heures et cinq minutes !! s’écria Selestan.
<br/>      -    Quoi !! s’étonna le chevalier. Moi j’ai neuf heures trois quart. Mon réveil a sonné à sept heures et demie et je n’ai pas réussi à me rendormir…
<br/>Ils dévalèrent les derniers escaliers et arrivèrent dans la cour du château qui était vide. Ils scrutèrent les environs à la recherche d'une personne.
<br/>Selestan entendit un bruit et se précipita vers celui-ci, Xalendan le suivit et ils trouvèrent Chloé et Jasson en train de discuter.
<br/>      -   On n’est venu à l'heure mais il n'y avait personne. Il est dix heures vingt et toujours personne, dit Jasson en les voyant arriver.
<br/>
<br/>*Dans ce monde, les réveils sont des objets magiques que l‘on règle avec une brève incantation le soir avant de se coucher. Ces objets sont très rare, puisque seule quelques mages savent les créés.
<br/>      -    Quoi !! s’exclama Selestan, mais...
<br/>      -  Vous aviez tous des heures différentes, dit un homme qui arrivait calmement derrière eux. Excusez-moi, je n’ai pas pu empêcher les autres professeurs de vous jouer ce petit tour… Malgré ça,  nous pouvons commencer.
<br/>Selestan fronça les sourcils, il n’aimait pas vraiment ce genre de blague.
<br/>L’homme les emmena au centre de la cour avant de se présenter :
<br/>      -    Je suis Konrad, votre professeur d'endurance, de course et de sprint. Je m’efforcerais d’endurcir vos corps pour qu’ils puissent subir les épreuves qui vous attende. Je vais d’abord évaluer votre course sur très petite distance.
<br/>Konrad traça une ligne de départ et une ligne d'arrivée. C’était une course d’à peu près soixante-quinze mètres. Le professeur dit aux chevaliers de se préparer…
<br/>      -    Partez ! cria-t-il pour leur donner le départ.
<br/>Chloé partit comme une flèche, d'une rapidité surprenante, dépassant sans problème Jasson et Xalendan puis Selestan à mi-chemin. Elle arriva première avec les félicitations du professeur. Selestan était deuxième. Les deux autres arrivèrent derniers.
<br/>Konrad leur demanda ensuite de courir trois quarts d'heure afin qu'il évalue leur endurance,  leur disant que l'athlétisme portait principalement sur le parcours qu'ils pouvaient faire en moins de temps possible sur une très longue distance.
<br/>Au départ ils couraient tous côte à côte, puis les écarts se creusèrent, Selestan devant, Xalendan et Jasson au milieu et Chloé à la traîne, le souffle court. A la fin du temps, Selestan avait parcouru huit tours de cour du château de plus que Chloé. Ces calculs étaient exacts et la fille se renfrogna devant son résultat médiocre. Selestan l'aperçut se dirigeant vers Jasson comme si elle voulait du réconfort mais celui-ci l’ignora, en pleine discussion avec Xalendan depuis le début du cours. La journée se continua et ils enchaînèrent les cours, découvrant leurs professeurs :
<br/>Nathir en alchimie, Jasson se révéla être un très bon alchimiste… En tant qu’ancien paysan, il avait une certaine connaissance des plantes.
<br/>Shirquant en tir à l'arc, Selestan put dévoiler ses talents.
<br/>Vitey en magie "3"…Pour se premier cour de magie, Vitey leur appris la base même de la magie. Son principe fondamental :
<br/>      -    La magie, elle est enfouie au plus profond de nous. Pour exécuter un sortilège, il vous faut aller chercher votre énergie. Après, la puissance du sortilège jugera de l'énergie qui va vous être enlevée. Je veux vous mettre en garde, beaucoup de magiciens sont morts lors d’une expérience, car leurs sortilèges ont dévoré toute leur énergie. Un petit sort ne demande même pas une fraction de votre énergie, c'est pourquoi nous commencerons par des sorts de ce type. Il faut bien faire la différence entre un sortilège qui a mal tourné et un sort qui a raté. Un sort qui a mal tourné vous tue alors qu'un sortilège qui est raté est dû tout simplement au manque de concentration du magicien pour l’exécuter. Un sortilège peut aussi être raté si le magicien est tout simplement dans l’incapacité de le réaliser. Par exemple, un grand nombre de magiciens ne peuvent utiliser la téléportation. Ce n’est pas qu’ils n’ont pas assez d’énergie pour l’effectuer, c’est qu’ils sont tous simplement incapables de la réaliser. Votre énergie est relayée par la planète, ainsi c’est elle qui décide si vous pouvez faire tel ou tel chose.
<br/>Pour la suite des cours, il y eut :
<br/>Zagzull en arme lourde. Aucun des nouveaux chevaliers n’arrivaient ne serait-ce qu’à soulever l’arme que leur donné le professeur.
<br/>Marion, la grande femme qu'ils avaient aperçue à la réunion, se révéla être le professeur de lame et d'escrime. Cette fois, les armes étaient plus légères, et ils purent commencer à apprendre comme se tenir devant un ennemi.
<br/>La fin de la journée arriva vite, ils rentrèrent épuiser, durent monter toutes les marches avant d'arriver dans leurs appartements…
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}