function C() { var choice = "Continuer#Motivation";var texting = `
<br/>
<br/>** Les secrets **
<br/>
<br/>
<br/>
<br/>
<br/>Selestan, encore sous le choc d'être mis à l'écart par Xalendan, la personne avec laquelle il avait le plus d'affinité, alla à l'écurie afin de promener son cheval, pour se détendre.
<br/>Sa valeur de jockey étant bonne, il sortait Cristalis, son étalon, plusieurs fois par jour. Racontant à l'animal ses exploits et ses ratés du jour. Etant persuadé que celui-ci l'écoutait, Selestan racontait avec détail sa journée. Il aimait aussi regarder avec précision la nature, s'arrêtant dans la forêt, au bord de l’étang. Il admirait l'eau cristalline reflétant le soleil, se laissant bercer par le chant des oiseaux. Tout était doux, comme le lever du jour qu'il observait tous les matins silencieusement depuis sa fenêtre. Le cheval, comme à son habitude, se coucha à coté de Selestan. Une chose rare pour ces animaux, mais pas pour Cristalis qui trouvait apparemment normal de s'allonger pour écouter les histoires du chevalier.
<br/>      -    Aujourd'hui, commença Selestan avec le mot habituel, on a combiné la magie avec l'adaptation aux lieux...
<br/>L'étalon hennissait en secouant la tête, sa crinière blanche virevoltant sur les poils noirs de sa peau.
<br/>      -    …Et Xalendan a fait des choses bizarres, il a crié des mots inconnus pour se protéger du loup des sables... continua Selestan.
<br/>Plus tard, quand Selestan eut fini de conter sa journée, il posa sa tête sur le ventre de son cheval. Il regarda les feuilles de l'arbre  se secouer, poussées par le vent ; le ciel et ses nuages, s'amusant à imaginer une représentation possible de l'un d'eux.
<br/>      -    Tu ne trouves pas que celui-ci ressemble à une licorne, en haut, le nuage ?
<br/>      -    Où ca ? dit une voix inconnue.
<br/>      -    Qui a parlé ? dit Selestan.
<br/>Le chevalier se leva d’un seul coup, regardant tout autour de lui.
<br/>      -    Qui a parlé ? répéta-il en scrutant les environs.
<br/>      -    C'est moi, dit une voix qui venait de Cristalis.
<br/>L'animal se leva et se mit face au chevalier. Une corne apparut sur le front du cheval...
<br/>      -    Une licorne !! s’émerveilla Selestan
<br/>      -    Tu as vu juste, dit Cristalis sans ouvrir la bouche.
<br/>Selestan, incapable de produire plus qu'un "ah'' admiratif, resta bouche bée.
<br/>
<br/>
<br/>
<br/>
<br/>Le lendemain soir, Jasson alla furieusement se réfugier à la bibliothèque. Selestan était encore parti avec son cheval, Xalendan ne lui répondait qu'avec des énigmes et des questions en tout genre (des choses dont il avait horreur)... Et enfin Chloé et lui s'étaient disputés pour un de ses peignes "adoré" qu'elle avait perdu... Elle soupçonnait Jasson de lui faire une blague en le lui ayant volé. Il avait clamé son innocence mais non, madame tête de bourrique avait décrété que le coupable, obligatoirement, était Jasson. Ce chevalier espiègle avait  l'esprit tellement imaginatif qu'elle ne retrouverait "jamais son peigne", d’après elle.
<br/>Jasson attrapa un livre et commença la lecture, il savait maintenant à peu près lire. Mais le chevalier n'arrivait pas se concentrer, un bruit le fit tressaillir.
<br/>      -    Qui est là ? demanda Jasson dans tous les sens.
<br/>      -    Nous !! soufflèrent des voix...
<br/>      -   Quoi, arrêtez ! Si c'est une farce... Selestan, Xalendan... Chloé... Ca me fait vraiment pas rire...
<br/>      -    Ah ah ah ah!!!
<br/>Jasson se leva de sa chaise en sursaut.
<br/>      -    Hi hi hi hi!!!
<br/>      -    Hou hou hou hou, snif...
<br/>      -    C'est nous!!
<br/>Jasson chercha un endroit ou se cacher tel un lapin pour sauver sa peau. Il esquissa un cri qu'il n'arriva pas à finir, sa langue avait fourché de terreur.
<br/>Quand on la regarde sous un autre angle, cette scène avait de quoi faire rire. Jasson recula, se heurtant à une chaise qu'il fit valdinguer, se cognant le tendon d'Achille au passage.
<br/>Presque s'il ne faisait pas un saut périlleux arrière…
<br/>Il s'écrasa sur le sol, mais cette fois, beugla bien entièrement un "aïe !!!!!" qui fit vibré les murs de la bibliothèque.
<br/>La douleur le pinçait d'une force incroyable, le sourire sur les visages -si on peut dire des visages- des trois personnages,  responsable de tout ce cirque, s'estompa la seconde qui suivit le cri.
<br/>Des fantômes, eh bien oui... Qui aurait pu le croire ! Des fantômes, cause de tout le malheur de Jasson.
<br/>      -  Mais qui êtes vous ? demanda Jasson irrité, en se relevant. Les visages de ces choses n’avaient pas l’air bien méchante, mais Jasson resta quand même sur ces gardes.
<br/>      -  Des rigolos !! On adore les farces, hi, hi, ouais, on adore... lança un fantôme.
<br/>      -  Tais-toi, Rhig !! gronda un autre fantôme, nous ne voulons pas faire de mal, nous voulons juste nous amuser... Hou  hou... Ouais.
<br/>      -   Oui ! J'ai vu, mon talon s'en souviendra d’ailleurs ! Et ma conscience aussi ! Des fantômes, non mais je rêve ! s’exclama Jasson pour lui même.
<br/>      -    Tu ne rêves pas, mec, dit le dernier fantôme, t’as eu trop de chance de pouvoir nous voir, très peu de personnes peuvent voir les fantômes... Ha, ha...
<br/>      -   Oui… Euh… C'est quoi vos noms ? demanda le chevalier.
<br/>Quel genre de question pouvait-il poser… Jasson ne trouva rien d’autre.
<br/>      -    Mille excuses, moi, c'est Rhag, ha, ha...
<br/>      -    Moi, c'est Rhig, hi, hi...
<br/>      -    Et moi Rhoug, hou, hou...
<br/>
<br/>
<br/>
<br/>
<br/>Chloé, pendant ce temps, pleurait sur son lit...
<br/>      -   Qu'est-ce que tu as ? demanda une voix douce derrière elle.
<br/>Sans se préoccuper de qui provenait cette voix, Chloé répondit :
<br/>      -   J'ai mal accusé Jasson ! J'avais fait tombé le peigne, je l'avais pas vu, ce n’était pas lui qui l'avait pris...
<br/>Des larmes coulèrent, elle les essuya avec les draps.
<br/>      -   Mais ce n’est pas grave, tu iras t’excuser, ça marche toujours… dit encore la voix
<br/>      -    Il est parti furieux ! Si je vais m'excuser, il me tue ! Je me suis emportée pour cette petite histoire alors qu'il n'avait rien fait ...
<br/>      -    Oh....
<br/>Chloé sentit quelque chose appuyer doucement sur son épaule, cela ne devait pas être plus gros qu'un doigt, elle sentit une de ses mèches de cheveux se lever et se faire caresser.
<br/>La femme chevalier tourna la tête et inspira, d'une rapidité égale à celle d'un guépard, l'oxygène dont elle avait besoin. C’était pour récupérer du choc qu'elle avait reçu en voyant un tout petit être habillé de vêtement blanc brillant sur son épaule. L’être avait la forme d'un humain, elle était de la taille d'une main avec deux ailes dans le dos.
<br/>      -    Que... Qu'est-ce que... réussit-elle à bafouiller.
<br/>      -    Ah, je suis une fée, je me présente, Sastibive.
<br/>      -    Euh...
<br/>      -  Tu n'as pas à avoir peur... Je sais que tu t'appelles Chloé et que tu as 16 ans !
<br/>Ne sachant que dire, Chloé répondit en lui demandant :
<br/>      -    Et vous... Ou tu… as quel âge ?
<br/>      -   Oh... Moi, je suis jeune, j'ai cent soixante et un ans, enfin pour un humain, ça équivaut à peu prés à dix sept, dix huit ans...
<br/>      -    Euh... Oui... C'est... jeune dit donc... Cent soixante et un ans...
<br/>
<br/>
<br/>
<br/>
<br/>Le soir de sa formidable découverte des fantômes, Jasson descendit une nouvelle fois à la bibliothèque. Personne n'avait parlé de la soirée, comme si tout le monde cachait quelque chose...
<br/>Jasson arriva en bas et trouva les fantômes qui devaient lui apprendre les règles du "poker".
<br/>Une heure plus tard, alors qu'il continuait sa partie de poker avec ses nouveaux "amis", Rhag demanda à Jasson :
<br/>      -    Tu es un chevalier, n'est-ce pas ?
<br/>      -   Oui, un chevalier du Sphinx fraichement recruté, répondit Jasson.
<br/>      -    Nous ne t'avons pas tout dit, avoua Rhoug, c'est nous qui avons décidé que tu puisses nous voir...
<br/>      -   Pourquoi ça ? demanda le chevalier absorbé par le jeu de cartes.
<br/>      -    Hé bien... continua Rhag mal à l'aise, nous t'avons élu.
<br/>      -    Comment ça ? dit Jasson tout à coup avide de savoir.
<br/>      -    Les fantômes sont des personnes...
<br/>      -    Mortes, je sais... coupa le chevalier, blasé.
<br/>      -  Non ! Pas du tout ! Si nous étions morts, nous ne pourrions être dans le monde des vivants, expliqua Rhag
<br/>      -    Mais attends… Tu es en train de me dire que vous n'êtes pas morts ?! s’étonna Jasson.
<br/>      -    Non, au contraire, nous sommes bien vivants ! s'exclama Rhig.
<br/>      -   Nous sommes des êtres en voie de disparition, nous vivons dans un monde parallèle, si tu veux. Rares sont les humains qui voient ce monde parallèle,  il faut qu'un fantôme décide que l'humain puisse le regarder, renchérit Rhag.
<br/>      -    Tous les trois, nous représentons un fantôme, parce que nous sommes frères, d'habitude, les fantômes n'ont pas de frère...
<br/>      -   …Avant 20 ans, les fantômes frères ou le fantôme seul doivent choisir un être comme toi à... Protéger, dit Rhig.
<br/>      -    Des anges gardiens ? proposa Jasson
<br/>      -   Si tu veux, en bien plus complexe. Enfin, on est avant tout des amis, non ! s’exclama Rhoug.
<br/>
<br/>
<br/>
<br/>
<br/>Chloé commençait à apprécier sa nouvelle amie, la fée. Elles parlaient ensemble chiffons et garçons, leurs goûts étaient quasiment pareils, si on enlève leurs points de vue complètement différents. Ce soir là, elles parlèrent comme d’habitude…
<br/>      -  Tu ne penses pas que Jasson est un beau garçon, demanda la fée.
<br/>      -  Ho !! Je t'interdis d’y toucher ! s'exclama la jeune femme, il est à moi !
<br/>      -  Mais tu t'entends, comme si une personne de dix cm pouvait être aimée d’un garçon d’un mètre soixante... J'aurai bien aimé, si j'étais aussi grande que toi...
<br/>      -    Ne serais tu pas jalouse, tout à coup !
<br/>      -   Tu sais, je ne te dirai pas comment j'ai atterri ici, mais en tout cas, je suis loin de chez moi, s'attrista Sastibive.
<br/>Ne sachant quoi faire, Chloé se tût, avec une personne "normale", elle aurait sûrement mis sa main sur son épaule, mais là...
<br/>      -    Où sont les tiens ? finit-elle par demander.
<br/>      -   A cette question, je ne peux répondre car même moi, je ne sais comment y aller, répondit la fée en toute sincérité.
<br/>Elles décidèrent d'arrêter cette conversation gênante pour Sastibive et préférèrent parler de Jasson. La fée demanda à Chloé ce qu'elle en pensait, elle répondit qu'elle le trouvait beau, gentil, mais qu'elle n'avait pas eu encore le temps de s'excuser car il était encore à la bibliothèque.
<br/>      -    Il m‘aime aussi, affirma-t-elle avec fierté.
<br/>      -    Mais n'est-il pas un peu petit en taille par rapport à toi ?
<br/>Chloé comprit tout de suite que la fée avait la phobie des tailles.
<br/>      -    Nous avons la même taille ! Je m’en fiche !
<br/>      -   Oui mais ça doit faire bizarre de l'embrasser de haut, quand même…
<br/>      -    Non, je te dis que nous faisons la même taille...
<br/>
<br/>
<br/>
<br/>Une nouvelle semaine de cours intensif n'avait pas beaucoup permis à Selestan de parler avec sa licorne, Cristalis. En dehors des cours d'équitation où ils devaient se montrer le plus discret possible, ils n'eurent même pas plus de quelques instants ensembles car l'allure des horaires de cours s'était intensifiée...
<br/>On était samedi, normalement le lendemain, il aurait le temps de profiter de la bonne détente après une longue semaine de travail. Enfin... Le cours de simulation de quête, ce jour là comportait pour lui beaucoup de mystère. Selestan savait juste qu'il fallait aller à la grande tour du château.
<br/>A l'heure de ce cours, il se dirigea vers la porte extérieure qui mène à la plus haute tour du blockhaus. Flegmatique, face au frontispice du château, il regardait la grande porte fermée à clef, son kandjar pendant à sa ceinture. Debout et parfaitement droit sur un genre d'asphalte, Selestan leva la tête et contempla le magnifique plafond orné d'or et de diamant de la grande salle du château.
<br/>      -   Qui êtes-vous ? persifla un garde qui le tira de ses pensées.
<br/>Selestan tourna la tête vers lui sans rien dire...
<br/>      -    Qui êtes-vous ? bissa le garde
<br/>      -   L'identité de ma personne ne vous regarde guère, répondit Selestan sur un ton très faussement gentil et calme.
<br/>Un sourire niais se dessina sur le visage du chevalier.
<br/>Le garde s'exacerba et sortit son épée...
<br/>      -   Il ne sera pas nécessaire que vous utilisiez ceci, dit Selestan en tendant la main vers l'épée
<br/>L’épée se propulsa d'elle-même de la main de l'homme et le jeune chevalier s’esclaffa d’un rire nerveux et horrible.
<br/>      -    Co… Comment... s'exclama le soldat, expliquez-vous ou j'appelle les chevaliers !!
<br/>      -    Vos boniments ne me font ni chaud ni froid, monsieur, dit Selestan sur un ton d'amabilité encore faux.
<br/>Le garde courut chercher son épée...
<br/>      -    Très bien !! Ahhhhhh !! beugla le garde en chargeant.
<br/>Selestan prit son poignard et esquiva le coup lancé par le soldat. Il fit ensuite une pirouette avant en faisant tournoyer son couteau. L'arme de Selestan atteignit sa cible et la main du garde fut tranchée à moitié. De douleur, l'homme lâcha son épée et hurla.
<br/>      -   Chevalier Selestan de l'ordre du Sphinx ! s'exclama le jeune homme sur un ton de fierté, je n'aime pas que l'on me parle de "haut" ! Alors, vous avez payé...
<br/>Les gémissements du garde continuaient alors que le professeur de magie ‘2’ arrivait. Mme Bibina identifia l'homme qui était par terre de haut en bas, ne ratant aucuns détails. Puis elle se tourna vers Selestan et ferma les yeux avec une expression de vouloir chercher quelque chose...
<br/>Pile à ce moment là, Xalendan arriva et vu la femme fermant les yeux. D'un lever de main, il propulsa le professeur par terre... La dame se releva puis dit :
<br/>      -    Co... Comment as tu fait !! Tu payeras !!
<br/>      -   Madame, vous ne devriez pas lire les pensées de Selestan !! s’exclama le chevalier.
<br/>Les yeux de Mme Bibina s'écarquillèrent.
<br/>      -    Fais le tomber !! s’écria le professeur.
<br/>Xalendan sentit ses jambes se serrer et il tomba à terre... Selestan courut et en un coup, frappa la tête de la dame qui s'évanouit.
<br/>Rudiger arriva et cria :
<br/>      -    Ferme leurs yeux !!
<br/>Selestan sentit ses yeux se fermer malgré lui... Puis il pensa de toutes ses forces qu'il voulait que lui et Xalendan se téléportent dans le parc, mais il ne pouvait pas.
<br/>Chloé arriva et tira une flèche sans chercher à comprendre, croyant que Rudiger faisait preuve de traîtrise. Elle atteint sa cible en pleine cheville, l'homme par son cri, déchira les tympans des témoins qui durent se boucher les oreilles.
<br/>      -    Ouvre nos yeux, ouvre nos yeux !! criait Xalendan.
<br/>      -  Vous n'y arriverez pas, ricana Rudiger qui réussit à prendre la fuite, je vous ai collé les yeux !
<br/>      -    Quoi !! cria Chloé pleine de rage.
<br/>      -   Décolle nos yeux, crièrent les jeunes chevaliers pour se libérer du maléfice.
<br/>      -    Iss-scolalo sonér paf elleut !! hurla Xalendan.
<br/>Les yeux de Selestan et les siens s'ouvrirent.
<br/>      -    Comment t’as fait !! s’écria Chloé.
<br/>      -    Euh... Plus tard... balbutia Xalendan avec un gros et faux sourire.
<br/>Chloé laissa échapper un cri de fureur et de désespoir et elle se tourna.
<br/>      -  Tu ne me laisses pas le choix alors, répliqua-t-elle toujours le dos tourné.
<br/>      -     Quoi ? demanda Xalendan.
<br/>Puis elle se retourna tellement rapidement qu'il eut à peine le temps de réagir, elle l'avait attrapé.
<br/>      -    Donne-moi plus de force, dit-elle à la magie.
<br/>Elle souleva Xalendan du sol et l'écrasa contre le mur.
<br/>      -    Dis le moi, menaça-t-elle.
<br/>      -    Non... couina le jeune chevalier complètement dépourvu de moral tout à coup.
<br/>Elle le propulsa vers le mur d'en face mais Jasson fraichement arrivé sauta pour sauver son camarade d'un horrible choc.
<br/>      -    Pourquoi ? demanda Jasson apparemment irrité, ce qui était très rare chez lui.
<br/>      -    Je... commença Chloé honteuse, pardon...
<br/>      -    Tu rigoles ! s'énerva Jasson, te pardonner !
<br/>      -    Il n'avait pas à me laisser dans l'ignorance, attaqua Chloé en retrouvant son caractère habituel que Jasson connaissait bien.
<br/>      -    A qui tu parlais alors, dans ta chambre ! lança Xalendan pour se défendre.
<br/>Chloé pâlit et dit que ça ne le regardait pas puis Xalendan dit que Chloé n'avait pas à le laisser dans l'ignorance. Cette imitation énerva complètement Chloé qui sortit son épée.
<br/>Jasson trouva que le moment était venu de s'interposer et il se dirigea vers elle mais elle l'interrompit avec son épée qu'elle tendit à son cou.
<br/>      -    Tu ne le feras jamais... Même énervée, dit Jasson pas très sûr de lui.
<br/>      -    C'est que tu me connais mal !
<br/>Jasson ignora l'avertissement et continua son chemin, provoquant Chloé au plus haut point, il tourna la tête pour ne pas toucher l'épée. Il se serait fait tuer facilement si la personne, ou l’adversaire avait vraiment eu envie de le tuer.
<br/>Il la prit dans ses bras et la serra avec amour. Chloé lâcha son épée et le prit dans ses bras avant de l’enlacer tendrement.
<br/>Elle le repoussa violemment. Il se heurta au mur qui lui brisa le crane sous l'impact...
<br/>      -    Tu es décidément folle, dit Selestan qui rentrait enfin dans le conflit.
<br/>      -    Ah... Selestan, quelle naïveté ! répondit-elle sur un ton persiflant, tu crois que j'allais me laisser manipuler !
<br/>Elle se rapprocha de Selestan avant de lui caresser doucement la joue. Le garçon resta impassible à la tentative de manipulation de Chloé.
<br/>      -    Et toi, tu fais quoi avec ton cheval quand tu le promènes plus de dix fois par jour, quand tu lui chuchotes des choses à l'oreille pendant le cours d'équitation ! continua Chloé. Serait-tu atteint mentalement ?
<br/>      -    Ca ne te regarde pas, répliqua-t-il sèchement.
<br/>Elle lui mit une baffe qui claqua violemment sa joue déjà rouge.
<br/>      -    Jasson... Quant-à toi... dit-elle en se dirigeant vers le garçon qui avait peine à se relever.
<br/>Elle posa délicatement ses doigts sur les épaules de Jasson et lui mit un coup de genou dans le ventre d'une telle force que le chevalier s'aplatit une nouvelle fois au sol.
<br/>Chloé s'allongea avec tendresse sur le dos de Jasson et dit à son oreille :
<br/>      -    Qu'est-ce que tu fais tous les jours à la bibliothèque et à qui tu parles ?
<br/>Il lui lança un regard noir par dessus son épaule et se retourna avec force, la renversa à côté de lui, se mit sur elle, lui attrapa les poignets et les plaqua au sol. Jasson envoya sa tête en coup de boule vers Chloé... Une giclée de sang sortit du nez de la jeune femme.
<br/>      -    Ah !! hurla-t-elle. Pourquoi ?
<br/>      -   Parce que tu l'as mérité, répondit simplement Jasson en se relevant.
<br/>      -    Qu'ils tombent tous ! cria Mme Bibina.
<br/>Les quatre chevaliers se sentirent aspirés par le sol...
<br/>Xalendan tenta de lire les pensées du professeur et vu qu'en fait, tout ceci était leur simulation de quête... Ils devaient réussir à battre les professeurs... Car ils veulent une pierre qui est dans la forêt...
<br/>Boum !!! Xalendan se pris un éclair dans la figure. Mme Bibina avait réussi à les immobiliser...
<br/>      -    C'est la simulation de quête, cria Xalendan qui se débattait pour se libérer de l'enchantement de la dame.
<br/>      -  Bien vu, Xalendan !! hurla Mme Bibina, trouvez et rapportez la pierre avant les professeurs et vous aurez réussi la simulation de quête !
<br/>Et elle partit en courant...
<br/>      -     Libère-nous, dit Chloé à l'adresse de la magie.
<br/>Ils purent enfin se relever, tout le monde avait un regard froid, dirigé vers Chloé.
<br/>      -  Euh... Ouais... Bah désolée... bafouilla la femme chevalier.
<br/>      -    Et c'est tout, s'énerva Xalendan tout en crachant à terre.
<br/>      -   Xalendan… soupira Jasson qui vint se placer entre les deux adversaires, pour elle, dire désolée, c'est... Enorme...
<br/>      -    Bon, on arrête, on oublie tout ça et on va chercher cette foutue pierre ! s’énerva Selestan.
<br/>Personne ne bougea...
<br/>      -    MAINTENANT !! beugla Selestan en tapant du pied.
<br/>Il était le plus sage, et tout le monde savait qu'il valait mieux l'écouter. Ils se dirigèrent en trainant des pieds vers la forêt comme le leur avait indiqué Xalendan.
<br/>
<br/>
<br/>
<br/>
<br/>     
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>9.
<br/>
<br/>** La forêt du Yanilar **
<br/>
<br/>
<br/>
<br/>Chloé, la plus têtue du groupe, avait dû s'excuser, avouer qu'elle avait eu tort, elle... 
<br/>« Ils le payeront » se jura-t-elle, « surtout Jasson que j’aimais et qui m'a humiliée »
<br/>Elle avançait en compagnie des trois autres chevaliers la tête baissée, songeant au moyen de faire souffrir Jasson.
<br/>Une voix qu'elle connaissait bien lui chuchota :
<br/>      -    Ce n'est pas bien de vouloir la souffrance des autres, Chloé.
<br/>      -    Sastibive !! cria Chloé, surprise.
<br/>Les autres se tournèrent vers elle, l'air complètement ahuri. L'expression de leur visage signifiait qu'ils avaient besoin d’explications.
<br/>      -    Ne leur dis pas ! avertit Sastibive à son oreille
<br/>      -    Quoi, s'exclama Chloé à l'adresse de ses camarades, vous avez l'air con, tout à coup...
<br/>      -    Bon, on avance... dit Selestan
<br/>Xalendan s’approchant de Chloé, la fée se cacha dans le sac que la jeune femme avait vite préparé avant de partir à la chasse à la pierre.
<br/>      -    Qu'est-ce que tu as dit ? demanda Xalendan à Chloé avec beaucoup de douceur et de tendresse.
<br/>      -    Xalendan, tu me connais mal, mon pauvre, ce n'est pas avec de la tendresse que tu vas réussir à me draguer, dit Chloé.
<br/>      -    Sastibive, tu as dit ça... N'est-ce pas ? continua-t-il en faisant mine de ne pas avoir entendu Chloé.
<br/>      -    Eh... Quoi ? lança nerveusement Chloé.
<br/>Sastibive, de son coté, se cacha plus profondément dans le sac de la jeune femme.
<br/>      -    Tu as dit Sastibive, en fait, tu as dit la fée mignonne... La signification de Sastibive, c'est « la fée mignonne ».
<br/>Chloé accéléra le pas, dépassa Selestan et se retrouva à coté de Jasson. Chloé ne l'avait pas encore remarqué, trop songeuse...
<br/>« Xalendan n'a pas vu que je suis partie, il réfléchit, mais à quoi ? » pensa Chloé.
<br/>Elle se tourna et vit Jasson, croisant son regard. Elle détourna les yeux et s'apprêta à partir mais Jasson la saisit par le bras.
<br/>La jeune femme tourna la tête et envoya un regard noir plein de haine à Jasson qui resta flegmatique.
<br/>      -    Je t'aime... dit le jeune homme tendrement.
<br/>      -    Moi non, je ne t'aime plus, lança sèchement Chloé.
<br/>Elle se libéra de Jasson qui avait l'air triste et perdu.
<br/>      -   Qu'est-ce que j'ai fait ? demanda Jasson avec une dernière marque de tendresse.
<br/>      -  Eh bien, comme je l'ai déjà dit à Xalendan, la tendresse ne marche pas avec moi !
<br/>      -   Ca a toujours marché jusqu'à maintenant...
<br/>      -    Mais ça ne marchera plus !
<br/>      -    Pourquoi ? Pourquoi !! cria Jasson à court d'espoir.
<br/>Mais c'était trop tard, Chloé était déjà partie. Cette fille était tellement incompréhensible ! Ces réactions étaient vraiment bizarre !
<br/>      -   Sastibive, qu'est-ce que tu fais là, demanda-elle à son sac.
<br/>      -  Je suis entrée dans ton sac quand tu avais le dos tourné, mais revenons au sujet principal... Tu m’as...Tu es d'une méchanceté !
<br/>      -  Pourquoi ? Ah... Avec Jasson, il le méritait, railla-t-elle, plus jamais il ne me touchera, je le déteste !!
<br/>Chloé essaya de contenir ses larmes mais quelques unes sortirent malgré tout de ses beaux yeux verts.
<br/>Ils arrivèrent enfin à l'écurie où ils comptaient prendre leurs chevaux pour aller dans les bois...
<br/>Le soir, ils arrivèrent à destination, dans la profondeur de la forêt obscure du "Yanilar". Ils préparèrent le camp comme le leur avait appris le professeur sans nom.
<br/>      -    Bonne nuit, dit Selestan après avoir mangé.
<br/>      -    On n’a pas besoin de monter la garde ? demanda Jasson.
<br/>      -    Non ! N’est-ce pas Cristalis, tu t'en occupes ?
<br/>Le cheval hennit et ils se couchèrent tous sous les arbres bruissant. Ces arbres qui étaient ternes, dépourvus de vie, cachaient la petite lueur de la lune et recouvraient ainsi les corps sommeillant des chevaliers d'une ombre tranquille.
<br/>A l'aube, les chevaliers se réveillèrent sous les coups de sabot de Cristalis qui ruait d'énervement. Selestan s'approcha de son cheval et chuchota d'un air innocent :
<br/>      -    Qu’y a-t-il ?
<br/>      -   Il est peut être temps que vous vous leviez, vous avez une pierre à aller chercher, lui répondit tout bas Cristalis pour qu'aucun des camarades de Selestan ne l'entende.
<br/>      -  OK ! Il est temps de lever le camp, plus vite on aura trouvé cette foutue pierre, plus vite on sera tranquille pour notre dimanche, une liberté bien méritée ! s'écria Selestan sous les gémissements de ses camarades qui avaient apparemment du mal à sortir de leur couchage...
<br/>Quelques temps après ils marchaient d'un pas las, vers le centre de la forêt, au fur et à mesure qu'ils avançaient, les arbres se resserraient et l'obscurité du bois s'accentuait.
<br/>Bientôt ils durent se mettre en file indienne pour pouvoir continuer... Selestan à la tête de nos quatre héros, chevauchait sa licorne avec allure.
<br/>      -    STOP !! ordonna tout à coup Selestan.
<br/>Il y avait eu du bruit…
<br/>      -   Que se passe-t-il ? s’exclamèrent ses camarades, en un brouhaha.
<br/>Chlig ! Grincèrent des épées en sortant de leurs fourreaux. Les professeurs d'arme lourde et d'escrime accompagnés plus loin du professeur de tir à l'arc brandirent leurs armes.
<br/>Xalendan fût le premier à réagir.
<br/>      -  taf oniras seur'r i-astoup ! (fait tomber leurs arme) s'exclama t'il.
<br/>      -    otiru taroum capurtys's ! (Contre ce sortilège !) lança le professeur sans nom.
<br/>Le professeur d'adaptation aux lieux fit son entrée en sautant d'un arbre, dès qu'il le vit, Xalendan frémit de terreur car il savait que ce professeur pourrait dévier ses sortilèges facilement, comme là, par exemple.
<br/>Le sortilège qu’avait lancé Xalendan rejoint celui de Laziador, les sortilèges mesuraient leurs force respectives, c’était à celui qui relâcherait son sortilège en premier que reviendrait la défaite. Ce fût le jeune homme, qui savait que continuer ce duel de magiciens contre le professeur elfe était inutile. Stopper ce sort l’avait vidé d’une bonne dose de force magique. Les professeurs chargèrent, ils avaient un handicap : ils étaient à pied.
<br/>      -  Chevaliers, servez vous de notre seul avantage, les chevaux ! s'exclama Selestan.
<br/>Et tous s'exécutèrent, faisant ruer, courir, tourner leur chevaux, ce qui réussit finalement à les départager de leurs adversaires au sol. Ces manœuvres apprises en cours d'équitation servaient à utiliser la force du cheval au profit de son cavalier.
<br/>Seulement, Shirquant, le tireur à l'arc adverse, entra en scène et tira une flèche. Le projectile siffla avant de se planter profondément dans l'épaule de Chloé, celle-ci chancela, perdit l'équilibre, tomba de son cheval puis s'effondra et enfin s'évanouit.
<br/>      -    Non !! s’égosilla Jasson en voyant Chloé sombrer.
<br/>Il se mit complètement debout sur son cheval et sauta, c'était dans le feu de l'action, Jasson n'avait jamais fait ça de sa vie. Une aura s’échappa de son corps, c’était une lumière bleue éblouissante. La pirouette parfaite qu'il exécuta, mit de l'admiration dans les yeux de tous. Sauf dans ceux de Chloé qui étaient fermés, insensible à la réalité, ne sachant ce qui se passait... L'air flegmatique, impassible, sans expression traversait le beau visage de la jeune femme inconsciente.
<br/>Jasson mit un pied à terre mais pas le deuxième... Il fit tournoyer son épée, la lançant légèrement en l'air, la faisant tourner et virevolter avec souplesse et grâce, la lâchant, la rattrapant. Par ces enchaînements magnifiques, il frappa le bout de chaque épée des deux professeurs d'armes, ce qui les désarma... Il attrapa le pommeau d'ivoire de son épée à deux mains, lança sa jambe en l'air en faisant un demi-tour avec son pied encore au sol puis fit retomber son pied à terre en avançant son buste et ses bras vers l'avant. Il lâcha son épée qui se planta en plein dans le mollet de Shirquant qui beugla de douleur. Jasson courut vers le professeur de tir, arracha son épée et sauta sur le torse de celui-ci  avec un pied puis avec l'autre, enchaînant avec un salto arrière. C’est sur le torse de  Shirquant qu’il prit l’impulsion dont il avait besoin pour l’exécuter. Ce pauvre professeur tomba violemment vers l'arrière, se râpant le dos contre une écorce pourrie. Jasson retomba sur le sol en tremblant, rangea son épée dans son fourreau et dit :
<br/>      -    J'ai quelqu'un à soigner, alors si ça ne vous ennuie pas, j'aimerais que vous DEGAGIEZ !!
<br/>      -   Vous n'avez pas gagné, mais vous méritez que l'on s'écarte après votre premier "vrai" combat, fît Laziador imperturbable.  
<br/>Et c'est ainsi que les professeurs disparurent dans la profondeur du bois.
<br/>      -    Guéris cette blessure... Guéris cette blessure ! GUERIS CETTE FOUTUE BLESSURE !! s’énerva Jasson en tendant la main vers Chloé.
<br/>La magie refusait d’opérer.
<br/>      -    Laisse-moi essayer... chuchota Xalendan.
<br/>Il s'éclaircit la gorge et prononça en langage elfe :
<br/>      -    Guéris cette blessure....
<br/>Rien, la blessure continuait à s'infecter. Jasson courut dans les bois en larmes...
<br/>      -    Qu'est-ce qu'on peut faire ! s'écria Selestan impuissant.
<br/>Xalendan regardait la blessure qui se faisait attaquer par plein de bactéries microscopiques. Un peu comme la rouille attaque le fer, ces microbes infestaient la plaie de Chloé, des microbes qui venaient de... La flèche !
<br/>      -    La flèche était empoisonnée !! cria Xalendan
<br/>      - Mais pas seulement, dit Selestan qui venait de comprendre, ce poison a été ensorcelé pour que l'on ne puisse la guérir avec la magie...
<br/>
<br/>
<br/>
<br/>Jasson courait dans la profondeur de la forêt, cherchant quelque chose, mais quoi ? Il s'arrêtait de temps en temps, touchant et reniflant des plantes comme un chien reniflant sa gamelle pleine de nourriture. Il cueillit plusieurs d'entre elles.
<br/>      -    Des solanacées, des vipérorum, un chibavern, il ne manque plus que l'astoirtus, mais comment trouver... chuchota Jasson pour lui même.
<br/>Tout à coup, il eut un "flash"... Enfin une idée, bien qu'il se prit un coup de foudre en plein sur le torse à ce moment là.  Cette attaque le propulsa au sol.
<br/>      -  Bonjour, chevalier, dit l'homme à l’origine de ce sortilège foudroyant, ils recrutent de plus en plus nul ces recruteurs.
<br/>Jasson se releva avec peine. Il sortit ensuite son épée d'un air menaçant.
<br/>      -    Qui êtes-vous ?
<br/>      -    Oh... Qui je suis, c'est la question que m’ont posée tous les chevaliers avant de mourir !
<br/>Ensuite, l'homme ricana d'une voix glaciale, il était grand, habillé de vêtements noirs, ses yeux rouges sang faisaient froid dans le dos. Quant à ses cheveux, Jasson n'en avait jamais vu de semblables, ils étaient violets et noirs, avec une nuance de bleu vers le bas. En gros, une silhouette pas vraiment humaine et tout à fait démoniaque.
<br/>      -    Comment ça... Mourir ?  s'étonna Jasson.
<br/>      -    Trêve de bavardage, à l'attaque !!
<br/>L'homme chargea le premier, il mit un coup de bras sur le visage de Jasson. Le chevalier s'écrasa au sol avec violence, son dos se brisa à l'impact. Il réussit tout de même à se relever mais l'homme lui mit un violent coup de poing dans le ventre. Jasson se plia de douleur. L'homme attrapa ensuite Jasson par le dos, le souleva en l'air et le jeta au sol, puis il sauta par terre, écrasant le chevalier... Le mystérieux personnage tira la dague de Jasson de son fourreau et se prépara à mettre le coup décisif au chevalier...
<br/>Mais à ce moment là, les fantômes apparurent, Rhoug, Rhig et Rhag. Ils s'interposèrent à l'attaque de l'homme... Le choc que Jasson crut avoir à subir n'arriva pas. Il ouvrit les yeux, ses fantômes avaient disparu… Il s'évanouit l'instant d'après...
<br/>Le chevalier ouvrit les yeux, il avait la tête lourde.
<br/>      -    NON !! Que leur as tu fait, NON !! Pas eux !! Pas mes fantômes !! Où êtes-vous ? s’écria Jasson en se relevant.
<br/>La sueur coulait sur la peau du jeune homme.
<br/>Les fantômes n’étaient plus là, ni l'homme, rien que Jasson.
<br/>      -    Où est-il ? s’étonna Jasson qui réalisait que maintenant il était seul.
<br/>Le jeune homme retomba lourdement au sol, à genoux. Il leva la tête en l'air et demanda au ciel caché par les arbres pourquoi il n’était pas mort.
<br/>      -    Chloé... dit tout bas Jasson en baissant la tête, Chloé... Tu es sûrement morte à l'heure qu'il est...
<br/>Puis le chevalier pleura silencieusement sous le léger vent qui faisait ondoyer ses cheveux.
<br/>      -    Et même si tu n’es pas morte... Je ne trouverai jamais d'astoirtus...
<br/>Jasson aurais bien aimé faire pousser cette plante à l'aide de la magie... Mais même un grand mage s'évanouirait rien que pour créer le bourgeon. Cette plante était très rare. Faire pousser une plante magiquement n'était pas à sa portée, il était pourtant très tenté de lancer cet enchantement. Il se retint car s’il utilisait toutes ses forces magiques, il mourait.
<br/>Eh oui, comme le leur ont enseigné les professeurs, la magie a des limites, si on dépasse sa puissance magique, on meurt... Ainsi est la règle de la magie.
<br/>      -    Jasson, Jasson... dirent Selestan et Xalendan qui lui remirent les pieds sur terre.
<br/>      -    Oh...c'est vous, j'ai pensé que...
<br/>Puis il sanglota.
<br/>      -    Chloé a besoin de nous... Jasson, on ne sait pas quoi faire.
<br/>Il ramassa ses ingrédients par terre et dit :
<br/>      -    Il faut faire une potion, il faut utiliser l'alchimie !
<br/>      -  Je n'y avais pas pensé ! s'exclama Xalendan, qu'est-ce qu'on attend, allons la sauver !
<br/>Jasson leva la tête vers lui, ses yeux pleins de larmes.
<br/>      -    Nous ne connaissons pas le poison de cette flèche...
<br/>      -   Eh ! attends, comment tu as su qu'elle était empoisonnée ! s'écria Selestan.
<br/>      -    C'était évident, continua Jasson, alors, il nous faut une potion qui marche contre tous les poisons... Enfin presque tous, il n'y a pas vraiment de potion qui guérisse tous les poisons...
<br/>      -    Et donc...
<br/>      -    Pour faire cette potion, il nous faut... Un astoirtus.
<br/>      -    QUOI !! Mais c'est introuvable, s'énerva Xalendan.
<br/>      -    J'ai pensé le faire pousser magiquement...
<br/>      -   Tu es fou !! Faire pousser une plante dépasse de loin nos compétences, dit Selestan.
<br/>Jasson tourna la tête vers Selestan puis vers Xalendan, réfléchissant à toute vitesse.
<br/>      -    C'est à la portée de Xalendan... affirma-t-il finalement.
<br/>Xalendan essaya de se défendre en disant qu'il était nul en magie et Jasson répliqua que Xalendan connaissait des mots incompréhensibles plus puissants que ceux de notre langue.
<br/>      -    Le langage des elfes, comprit soudain Selestan.
<br/>      -    Le langage de quoi ? se défendit Xalendan.
<br/>      -   Des elfes, tu as raison Selestan ! s’exclama Jasson dont le visage s'illumina, comment tu la connais ?
<br/>      - Je ne vois pas de quoi vous parlez... fît Xalendan pour une dernière tentative.
<br/>      -    Arrête !! Ou on te pète la gueule, ironisa Jasson.
<br/>
<br/>
<br/>
<br/>« Mince », pensa Xalendan. « Je ne pourrai jamais m'en sortir ». Il décida finalement de tout leur avouer. Alors, revenant vers l'endroit où dormait Chloé, Xalendan leur raconta comment il avait trouvé le livre, la discussion avec le professeur sans nom -en prenant bien soin bien sur de ne pas révéler le secret que l'homme lui avait confié- ; il raconta son acharnement à apprendre tous les mots tous les soirs, tous les matins, tous les dimanches. Xalendan leur expliqua que ce langage permettait d'avoir besoin de moins d'énergie pour lancer un sortilège et que celui-ci était plus puissant. Ils arrivèrent enfin devant Chloé qui avait toujours l'air flegmatique, les yeux fermés.
<br/>      -   Répétez après moi, lança Xalendan, tistif yalbisoir... (Fait pousser...) Attendez ! Je ne connais pas le mot astoirtus !...
<br/>      -    C'est logique, tu ne peux pas tout connaître. Essayons de combiner notre langue avec la langue elfe... proposa Selestan.
<br/>      -    Je n'y avais jamais songé... dit Xalendan.
<br/>      -    Tistif yalbisoir astoirtus... A trois, continua Xalendan.
<br/>Les trois chevaliers firent un cercle et tendirent leurs mains en son centre. Ils puisèrent plus profondément leur énergie que d'habitude pour exécuter leur enchantement. Comme appris en cours, ils devaient rester concentrés sur leur énergie, ce qui permettrait de la perdre moins vite. Les chevaliers invoquèrent la magie puis s'écrièrent d'une même voix :
<br/>      -    Un...deux...trois… Tistif yalbisoir astoirtus !!
<br/>
<br/>
<br/>10.
<br/>
<br/>** L'astoirtus **
<br/>
<br/>
<br/>Xalendan sentait sa main trembler sous l'effet de la magie, cinq minutes s'écoulèrent sans que rien ne se passe ; mais leur énergie ne s'arrêtait pas de diminuer pour autant.
<br/>Enfin, un bourgeon apparu, redonnant de l'espoir aux chevaliers. Une goutte de sueur glissa sur la joue de Selestan.
<br/>Xalendan aussi commençait sérieusement à se fatiguer, mais une fois lancé, on ne peut arrêter un sortilège si puissant (arrêter un sortilège demande de l'énergie en pourcentage de la puissance magique de cet enchantement). La peur de ne pas avoir assez de force, de devoir mourir hantaient les pensées des jeunes hommes contraints à résister. Xalendan et les deux autres baissèrent leurs mains et tombèrent à genoux, se concentrant de toutes leurs forces pour se maintenir éveillés.
<br/>
<br/>
<br/>
<br/>Jasson résistait, il tenta un regard vers le bourgeon et vit qu'il commençait à peine à fleurir. Cinq minutes plus tard, les chevaliers étaient laminés, la plante ressemblait maintenant à une plante jeune, cela aurait suffi pour guérir Chloé mais l'enchantement refusait de s'arrêter et pompait leurs forces comme un tic pompe le sang d'un chien.
<br/>      -    On aurait dû dire à la magie que l'on puisse s'arrêter quand on veut, sans utiliser d’énergie !! s’écria Jasson à bout de souffle.
<br/>      -    Non... ça aurait pris notre énergie beaucoup plus vite, ce n’est pas gratuit de faire ce que tu dis... répliqua Xalendan, c'est écrit dans mon livre...
<br/>Jasson vit Selestan s'évanouir de fatigue... Le chevalier aurait tant voulu l'aider mais il ne pouvait pas en raison de sa fatigue.
<br/>Le temps s'écoulait de plus en plus lentement... Cinq secondes... Dix secondes... Vingt secondes… Xalendan lui aussi s'évanouit... une minute s'écoula et Jasson était maintenant tout rouge et au bord de l'agonie.
<br/>"Résiste" se répétait-il dans sa tête... L'enchantement s'arrêta enfin et Jasson s'écrasa au sol, à peine conscient, le souffle haletant.
<br/>Il se hâta malgré tout d'aller toucher le pouls de ses deux amis inconscients, et poussa un cri de joie quand il sut qu'ils n'étaient pas morts... Ce cri lui déchira les abdominaux...
<br/>Le chevalier coupa délicatement la plante comme si le destin du monde ne dépendait que d'elle. Il ajouta la plante à sa potion déjà prête et la fit boire délicatement à Chloé qui était toujours inconsciente. Il était écrit sur le manuel d'alchimie qu’il faudrait attendre avant qu’elle ne se réveille ; déjà, le principal était fait, Chloé allait survivre. A cette pensée, Jasson était content. Mais quand il repensa comme elle l’avait rejeté, il ravala son enthousiasme.
<br/>Il décida qu'une bonne nuit de sommeil s'imposait et il alla préparer les couchettes. Les quatre lits installés, Jasson était mou comme une mie de pain. Il parvint quand même en utilisant le peu de force qui lui restait à glisser ses compagnons dans leur lit respectif.
<br/>Quand Jasson rentra dans son lit, il ressentit une grande fierté, c'était lui qui s'était occupé de Chloé, c'est lui qui avait veillé sur Xalendan et sur Selestan, c'est lui qui avait réussi à survivre au mystérieux personnage... Quand il y repensa, tout le bonheur qu'il avait mérité de ressentir, s'évapora.
<br/>      -    Mes pauvres fantômes, gémit-il.
<br/>Puis la tristesse s'empara de lui, ses fantômes auxquels il était attaché, étaient morts, par sa faute... Mais comment se faisait-il que l'homme ait disparu ? Comment était-ce possible ?
<br/>Plein de questions commencèrent à le bousculer. Il médita. Dix minutes plus tard, quand toutes ses questions furent pour le moment oublier, Jasson s'endormit.
<br/>
<br/>Jasson marchait dans un château sombre et lugubre, ne craignant rien, il tourna vers la grande porte de gauche et l'ouvrit.
<br/>      -    Que me vaut cette visite ! lança une voix glaciale.
<br/>      -  Je suis venu vous affronter en duel ! rétorqua Jasson d'une voix trop assurée.
<br/>Plusieurs personnes se mirent à rire autour de lui.
<br/>      -   Vraiment, eh bien il va falloir que tu gagnes un autre duel avant de m'affronter, ricana la voix de plus en plus froide.
<br/>L'homme était flou à la vue de Jasson qui arrivait à peine à distinguer sa taille.
<br/>Seul la voix de l'homme était claire, et même plus claire que nature quand il dit...
<br/>      -    C'est ta chère Chloé que tu vas combattre, et après, si tu gagnes, tu auras l'honneur de perdre contre moi en duel à l'épée...
<br/>
<br/>      -    Jasson... Jasson... dit la voix de Selestan, ça va ?...
<br/>Jasson transpirait, tous ses vêtements étaient mouillés de sueur, "quel horrible rêve" pensa-t-il.
<br/>      -    Que t'est-il arrivé ? demanda Xalendan à côté de Selestan.
<br/>      -    J'ai dû avoir chaud, mentit Jasson.
<br/>      -    Chloé ne s'est pas réveillée...
<br/>      -    QUOI !! s’exclama Jasson pris d'une fureur subite.
<br/>      -    Il y a un moyen de lui parler, dit Xalendan
<br/>Jasson regarda son compagnon, blasé :
<br/>      -    Bah tu parles à côté d'elle et c'est bon…
<br/>      -  Non, le coupa Xalendan, je veux dire qu'elle peut nous répondre...
<br/>Jasson jugea la possibilité avec considération.
<br/>Xalendan leur expliqua comment entrer dans l'esprit de quelqu'un et comment savoir si on est victime de cette emprise. Sans attendre, Jasson se précipita vers le corps inanimé de Chloé. Xalendan le mit en garde en lui disant qu'une personne sachant se défendre face à cette "attaque" pouvait tuer l'attaquant si celui-ci n'était pas sur ses gardes...
<br/>      -    Pff ! Elle ne sait même pas que ça existe ! s’exclama le chevalier.
<br/>Jasson plongea dans l'esprit de Chloé comme le lui avait appris Xalendan. Il se heurta contre un mur comme un astéroïde s'écrase contre une planète. La défense de la jeune femme était impressionnante. Jasson s'acharna contre cette paroi mais rien, pas une fissure n'était apparue, ses attaques étaient aussi utiles qu'une gomme pour effacer de la peinture !
<br/>Finalement, Jasson pensa de toutes ses forces qu'il voulait une massue. L'arme s'était invoquée dans ses mains spirituelles.
<br/>Il prépara son attaque... Boum ! La massue frappa contre la muraille et celle-ci s'ouvrit, juste un peu. Jasson s'y glissa rapidement. Il avait bien fait car cette fissure se referma la fraction de seconde qui suivit son passage.
<br/>Il était arrivé dans... L'intimité de Chloé. Toutes ses pensées et ses secrets y étaient cachés, Jasson en frissonna de nervosité. Les pensées de Chloé était mal "rangées", des souvenirs dans tous les sens, des pensées dans tous les autres, un gros bordel noir, chaque souvenir, pensée, secret et tout ce qui touchait à l'intimité de la jeune femme avait une couleur avec une forme.
<br/>Jasson ne put  s'empêcher de se rapprocher d'une forme en cœur barré et rouge sang... Il entra à la seconde qui suivit dans ce souvenir.
<br/>
<br/>Chloé était furieuse, (Jasson voyait avec la vue de Chloé) "je le tuerai pour ce qu’il m’a fait" pensa-t-elle. Jasson chercha qui  était la personne qu'elle voulait tuer et fut surprit de voir en Chloé que c'était lui...
<br/>
<br/>Jasson se prit un coup de point dans la figure et sortit du souvenir. Chloé se tenait devant lui. Son regard noir le fit tressaillir.
<br/>      -    Que fais tu ici et comment... Tu as fait ?! demanda-t-elle aussi surprise qu’énervée.
<br/>      -    C'est Xalendan qui nous a appris et je suis venu voir si tu allais bien, en venant te parler...
<br/>      -    QUOI !! Et c'est comme ça que tu le fais, en fouillant dans mon cerveau, salaud !
<br/>      -    Non, ce n'est pas...
<br/>      -    Tu mens, tu es venu pour fouiller, pour FOUILLER !! pleura-t-elle, tu te fiches bien que j'aille bien ou pas, ce qui t’intéresse, c'est le statut de mon père et mon physique !
<br/>      -    Tu oses me dire ça !
<br/>Jasson s'énerva sous l'affirmation de Chloé. Il n'était pas dans sa nature d'avoir un "caractère d'attaquant".
<br/>Mais là, il contre-attaqua :
<br/>      -    Tu oses dire que je ne pense qu'à ton physique, tu oses penser que je ne t'ai jamais aimé, que je te veux pour ton père !!
<br/>      -    OUI !! s’exclama Chloé qui avait les traits de la rage extrême sur son visage, des larmes de colère roulaient sur ses joues et son teint avait légèrement foncé.
<br/>Elle n'avait maintenant plus qu'une idée en tête : "tuer Jasson". Le chevalier ne pût se contrôler sous la fureur et mit un coup de poing dans la tête de Chloé qui poussa un cri de douleur...
<br/>      -    NON !! Qu’est ce que j'ai fait !  s’exclama-t-il, Chloé, Chloé, excuse moi. J’ai frappé une fille mais je suis fou !
<br/>Il s'allongea devant elle sur le ventre en signe de soumission et Chloé se leva avant de le frapper violemment au visage avec son pied. Jasson eut des spasmes dans tout le corps. Il réussit toutefois à se lever et à attraper Chloé par la taille. Il la serra tendrement contre lui. Chloé était ignorante, l'air impassible.
<br/>      -    Tu m'as dit que la tendresse n'était pas ce que tu aimais mais moi, je pense que si on aime, il faut être tendre, dit Jasson en la regardant dans les yeux.
<br/>Jasson la serra encore plus fort contre lui et lui caressa les cheveux avec délicatesse. Il mit sa tête sur l'épaule de Chloé et continua :
<br/>      -    C'est pour ça que tu aimais la tendresse avec moi, avant, parce que tu m'aimais... Et tu ne m'aimes plus... Moi, j'ai toujours aimé la tendresse avec toi et je t'ai toujours aimée... C'est toi qui ne m'aimes pas, tu ne m'aimes PAS !!
<br/>Il se décolla d'elle et se retourna en marchant n'importe où. La jeune femme eut un long moment d'hésitation mais Chloé cria finalement :
<br/>      -    Jasson, JASSON... Je t'aime, je t'aime, je t'ai toujours aimé, je t'aimerai toujours, je ne pensais pas ce que j'ai dit, je t'aime, JE T'AIME !!
<br/>Elle le rattrapa en sprintant, Jasson courait moins vite qu'elle sur courte distance alors ses efforts pour la distancer furent un échec. Chloé l'attrapa en l'enlaçant et l'embrassa fougueusement... Jasson accepta ce baiser et le rendit avec beaucoup d'amour.
<br/>
<br/>
<br/>Selestan se tenait devant un Jasson inconscient...
<br/>      -    Là, il est carrément rentré dans la tête de Chloé, il a propulsé son corps et son esprit dans Chloé, le corps de Jasson que tu as devant toi est temporairement mort, il ne sert à rien...expliqua Xalendan.
<br/>Le temps dans le cerveau de quelqu'un est agrandi, doublé, c'est à dire que une heure pour nous, c’est deux heures pour eux.
<br/>      -    Ce qui fait que l'on peut "rentrer" dans "son" cerveau ? demanda Selestan
<br/>      -    Bien sûr, je le fais souvent vu que le temps est agrandi, ça me sert quand les profs nous donnent des devoirs, j'ai deux fois plus de temps pour les faire... ou pour revoir des cours...
<br/>Selestan se concentra pour rentrer dans son esprit. Il se sentit tout à coup aspiré...il se retrouva dans une magnifique nature, une forêt, un lac, des animaux sauvages...et enfin des souvenirs éparpillés, difficile à dire comment ils étaient, Selestan savait juste leur emplacement, sans les voir, un genre d'onde révélait leur présence. Selestan resta dans son cerveau pendant plus d'une heure à regarder plus d’une fois ses souvenirs préférés, à ranger ses pensées, à les classer...Enfin il se décida à sortir, "mince’’, comment on fait..."songea-t-il. Puis il se concentra et improvisa...un quart d'heure se déroula sans que Selestan ne trouve le moyen de sortir...il commença à paniquer quand quelque chose tenta de rentrer dans son cerveau, il essaya de l'arrêter mais n'y parvint pas et Selestan fut soulager de voir Xalendan marcher vers lui...
<br/>      -    C'était bien ta défense, mais insuffisante pour me barrer la route ! s'exclama le chevalier
<br/>      -    C'est bien que tu sois venu, tu ne nous as pas expliqué comment sortir...
<br/>Un regard de peur et de surprise passa sur le visage de Xalendan.
<br/>      -    C'est vrai ! Mince, Jasson doit être bloqué !
<br/>Xalendan lui expliqua comment faire et ils sortirent des pensées de Selestan. Selestan se sentit une nouvelle fois aspiré par une force inconnue et se retrouva sur la terre ferme. Jasson se tenait devant lui.
<br/>      -    Alors, comment ça c'est passé ? Comment tu as fait pour sortir   ? demanda Selestan impatient et surprit.
<br/>      - C'est Chloé, elle sait utiliser cette magie. C'est son père qui le lui a appris, et elle m'a expliqué comment faire.
<br/>      -  Pourquoi elle ne se réveille pas, que s'est-il passé ? interrogea Selestan encore une fois.
<br/>Cette question assombrit le visage du chevalier qui répondit que le sérum qu'ils lui avaient fabriqué ne marchera pas contre cet empoisonnement avant une bonne semaine. A ce moment là, le cheval de Selestan qui était en réalité une licorne s'approcha de son maître en hennissant. Le cheval s'assit par terre comme un chien s'assied devant son maître.
<br/>
<br/>
<br/>
<br/>
<br/>Le geste du cheval époustoufla Jasson, lui qui avait pourtant une imagination sans limite. Il s'avança vers la bête bouche bée, puis approcha lentement sa main au dessus du naseau de l'animal. Sa paume fût arrêtée par quelque chose d'invisible et pointu.
<br/>      -   UNE LICORNE !!! s’exclama, s'écria, beugla, s'égosilla, s'émerveilla Jasson.
<br/>      -    Comment ça ? s’étonna Selestan en essayant de paraître le plus naturel possible.
<br/>      -    Selestan, dis leur ! dit une voix qui provenait de l'animal.
<br/>Selestan finit par avouer tout sur la découverte de sa licorne. Ils leur conta leur rencontre, leurs habitudes.
<br/>Après le récit de Selestan, assez long, Xalendan réfléchit à toute vitesse, mais aucune idée pour sauver Chloé ne lui vint à l'esprit. Jasson était impressionné, son père n'avait donc pas mentit sur l'existence de ces créatures. Un jour, le père de Jasson était arrivé à la maison, excité. L'homme insinua qu'il avait vu un de ses êtres magnifiques qui s'appelaient "licornes", sa mère ne l'avait pas cru. Son père décrivit à son fils les détails du physique de la licorne, il lui dit aussi que l'animal s'allongeait et s'asseyait au contraire des chevaux. Jasson avait cherché dans toute la région pour apercevoir l'animal. En vain. Jamais il ne trouva la licorne qu’il rêvait d'apercevoir comme son père. Finalement, il se persuada que la licorne avait été une illusion de son père et que celle-ci n'avait jamais existé. Aujourd'hui, Jasson avait vu une licorne... Encore sous le choc, Jasson ne pensait plus à Chloé, ce qui lui attira les reproches de ses camarades.
<br/>      -    La corne de la licorne a de grands pouvoirs médicaux, affirma Jasson qui reprenait lentement le sens de la réalité.
<br/>La corne de la créature apparut tout à coup au dessus de son naseau, ce qui émerveilla Xalendan et Jasson. Sous le regard interrogateur de ses frères d'arme, Jasson expliqua les bienfaits de la corne de licorne. Il suffit de toucher la blessure avec la corne pour que celle ci soit guérie.
<br/>      -  ça guérit même les empoisonnements ? demanda Xalendan avec excitation et impatience.
<br/>      -    Je ne sais pas, il faut essayer, dit Jasson.
<br/>La licorne approcha donc de Chloé, sa corne tout à coup s'illumina. L'animal toucha alors Chloé avec sa corne puis recula juste après.
<br/>      -  Pourquoi ne se réveille-t-elle pas ? demanda Selestan étonné que l'effet ne soit pas immédiat.
<br/>Une grande déception frappa le cœur du chevalier Jasson. Une larme coula sur sa joue.
<br/>      - Il n'y a plus qu’à attendre qu'elle se réveille, dit simplement Cristalis.
<br/>      -   Mais... Il faut qu'elle se réveille pour que l'on puisse finir la quête !
<br/>Le soir arriva et les chevaliers admirèrent la belle lumière orange du soleil couchant. Ils s'enroulèrent dans leur couette avec l'espoir que demain, Chloé se réveille. Quand les deux autres chevaliers furent endormis, Jasson sortit de sa couchette et alla se mettre à coté de Chloé, à genoux.
<br/>      -    Pourquoi ne veux-tu pas te réveiller ?
<br/>Il se glissa dans la couette de Chloé et mit son torse contre le dos de la jeune femme. Le chevalier mit ensuite sa tête entre les cheveux de la chevalière et dit doucement à son oreille :
<br/>      -    Je t'aime, réveille toi, je t'en supplie...
<br/>A se moment là, il sentit le corps Chloé bouger et elle ouvrit les yeux.
<br/>      -    Je t'aime aussi, Jasson.
<br/>Elle se retourna pour faire face à son petit ami et l'embrassa tendrement.
<br/>      -    La tendresse est tout à coup revenue sur ton beau visage, dit Jasson
<br/>      -  Mais c'est parce que je t'aime, rétorqua Chloé qui commença à l'amadouer, et toi, tu m'aimes ?
<br/>Jasson savait qu'elle le taquinait, alors il répondit que non, qu'il trouvait la jeune femme odieuse et méchante, une hypocrite complètement moche.
<br/>      -    C'est d'ailleurs pour cela que je suis là lança Jasson avec humour.
<br/>Chloé rigola de bon cœur, elle le secoua doucement comme un sac de patates pour se venger de ses propos, elle se mit ensuite sur lui.
<br/>      -    Tu n’es pas gentil ! s'exclama Chloé qui cherchait a l'amadouer une nouvelle fois.
<br/>Jasson tourna avec Chloé dans ses bras et se retrouva sur elle, puis il l'embrassa avec amour.
<br/>11.
<br/>
<br/>** La pierre **
<br/>
<br/>
<br/>
<br/>Xalendan se réveilla de bonne heure, il alla seller les chevaux et préparer les petits déjeuners.
<br/>      -  Jasson, dit Xalendan en voyant que son frère d'arme n'était pas dans son lit.
<br/>Il tourna finalement la tête et vit avec soulagement que le chevalier était dans la couchette de Chloé. " que fait-il dans son lit " se demanda Xalendan. Peut être la chevalière avait-t-elle ouvert les yeux et s'était réveillée, cette pensée remit de l'espoir dans son cœur. Une heure après environ, Selestan se réveilla. Les deux chevaliers déjeunèrent ensemble.
<br/>      -    Si jamais elle s'est réveillée, à mon avis, ils ont fait crac crac, ironisa Xalendan
<br/>Selestan éclata de rire et dit que son compagnon avait sûrement raison.
<br/>      -  Et ce serais pour ça qu'ils sont fatigués, se moqua Selestan.
<br/>      -  Non, franchement, est-ce que tu as déjà fait...l'amour, demanda Xalendan
<br/>      -    Euh... Non, et toi
<br/>Xalendan sembla rougir, Selestan demanda si l'heureuse élue était belle.
<br/>      -    Non, je ne l'ai jamais fait, répondit finalement le chevalier.
<br/>Jasson et Chloé se réveillèrent en même temps. Quand la jeune femme ouvrit les yeux, elle fût accueillie par les grands cris de joie des deux chevaliers. Puis Selestan et Xalendan échangèrent un regard avant d'éclater de rire. Le fou rire des deux vicieux terminé, Jasson et Chloé allèrent s'assoir à terre pour le petit déjeuner.
<br/>      -    J'ai soif et je suis affamée !! s’exclama Chloé
<br/>      -  Normal, ça fait longtemps que tu n'as pas mangé, dit Jasson.
<br/>Un sourire espiègle traversa le visage de Selestan. Xalendan croisa son regard et sut à quoi son camarade pensait. Il sourit à son tour avant de se tourner vers les deux tourtereaux.
<br/>      -    Ah bon, vous n'en avez pas eu assez avec hier soir, vous avez encore faim ! dirent ensemble les deux chevaliers.
<br/>Jasson rougit, Chloé rétorqua :
<br/>      -    Ah ah, c'est drôle mais ce n'est pas vos affaires.
<br/>Cette réplique cassante coupa le souffle aux deux chevaliers espiègles. La fin du repas se fît dans la bonne humeur.
<br/>Ils partirent donc dans l'après midi à la recherche de la fameuse pierre. Tout en chevauchant, ils lançaient des blagues et se mettaient tous à rire, même Chloé qui d'habitude ne prenait pas part à leurs jeux. Elle riait de bon cœur en pensant qu'elle ne pourrait trouver meilleurs amis. Sastibive était restée dans le sac de Chloé pendant deux jours.
<br/>      -  Que savez vous des fées, demanda sérieusement Chloé à ses camarades en la sentant bougée dans son sac.
<br/>      -  Les fées ? s’étonna Jasson, comment sais tu qu'elles existent ?
<br/>      -   Je n'ai jamais dit ça ! s'exclama Chloé comme pour se défendre.
<br/>Le sac de Chloé bougea d'un coup, et comme tout le monde la regardait, tout le monde vit le sac. Tous les garçons descendirent instinctivement de leurs chevaux, Chloé les imita.
<br/>      -    Que caches-tu dans ton sac, demanda Xalendan méfiant.
<br/>      -    Oh... Rien pourquoi ?
<br/>Jasson se dirigea d'un coup vers elle et d'un geste, attrapa le sac de Chloé. Il allait l'ouvrir mais il se prit un coup de poing en pleine figure. Le chevalier lâcha des jurons et lâcha le sac qui s'écrasa au sol. Une voix aiguë cria alors.
<br/>      -   Le cri vient du sac ! s'écria Selestan, dis nous ce que tu caches dedans sinon...
<br/>      -    Sinon quoi, répliqua-t-elle avec agressivité.
<br/>Jasson attrapa la jeune femme par le bassin et la poussa contre un arbre. Elle se retourna et enchaina deux coups à Jasson dont le sang commença à couler. Xalendan se dirigea vers le sac et l'ouvrit d'un coup sec, avec un cri de rage,  Chloé  fonça vers lui en lui mettant un coup puissant dans le torse. Le jeune homme s'écroula au sol et ne put qu'apercevoir une fée sortir du sac avant de s'évanouir. Selestan se tenait devant une fée. Il lança un petit son admiratif avant de voir le poing de Chloé s'abattre sur lui, quelques coups suffirent pour qu'il s'évanouisse. Jasson se prépara à encaisser les coups de Chloé qui fonçait vers lui. Mais finalement, il décida de se défendre. Le jeune homme esquiva le coup de poing rageur de la femme chevalier.
<br/>Il porta ensuite trois coups à Chloé qui tomba à terre. Le chevalier lui sauta dessus, mais au lieu de la frapper, il l'embrassa. Malgré les coups qu'il se prenait dans tous les sens, il ajouta de la tendresse à son baiser. Jasson la serra ensuite de toutes ses forces et avec la plus grande tendresse.
<br/>      -    Chut...Calme toi, c'est fini, tu n’es plus obligée de me frapper...
<br/>Le beau visage de Chloé se retourna vers le sien. Elle pleurait à chaudes larmes... Jasson serra la tête de la jeune femme contre son torse.
<br/>      -    Pourquoi... Pourquoi as-tu fait ça ? demanda Jasson avec la crainte de réveiller une nouvelle fois la rage de sa petite copine.
<br/>      -    Je... Je... Ne sais pas... C’est toujours comme ça, une force invisible m’oblige à agir ainsi !
<br/>Elle enfouit son visage plus profondément dans le torse du jeune garçon. Chloé était en train de vider toutes les larmes de son corps dans les bras de celui qu'elle aimait.
<br/>
<br/>
<br/>
<br/>
<br/>Un peu plus loin, deux hommes les regardaient... parmi eux, le professeur d'adaptation aux lieux.
<br/>      -   Ils n'ont même pas besoin de nous pour perdre, ils s'entre-tuent ! fît-il à son voisin.
<br/>Celui ci acquiesça en hochant la tête et répondit :
<br/>      -    Cette fille a un sale caractère, personne ne peut la calmer quand elle s'énerve.
<br/>      -   Je n'en suis pas si sûr, le jeune homme à coté d'elle semble la comprendre et semble arriver à la calmer.
<br/>      -    Le code de l'ordre du Sphinx voudrait que l'on expulse la demoiselle pour sa colère et le jeune homme pour entretenir de tendres sentiments envers l’une de ses sœurs d'arme.
<br/>L'homme soupira avant de continuer :
<br/>      -    Mais nous ne pouvons nous séparer d'atouts comme eux...
<br/>
<br/>
<br/>
<br/>
<br/>Le lendemain, quand Xalendan et Selestan se réveillèrent enfin, Chloé raconta la découverte de Sastibive et la leur présenta. Tous eurent un regard admiratif devant le petit être.
<br/>      -   Et c'est pour ça que tu nous as frappés !! s’exclama Xalendan à bout de nerfs, une demi journée de perdue à cause de madame l'emmerdeuse.
<br/>Jasson s'interposa en disant qu'il ne fallait plus parler de ça. Selestan dit finalement à contrecœur qu'il acceptait les excuses de Chloé, Xalendan fit de même. Ils marchèrent dans le fond de la forêt pendant la mi-journée sans rien trouver.
<br/>      -   Mais ce n’est pas possible !! Ça fait bientôt cinq heures que nous marchons et il n'y a rien, toujours ces arbres miteux et cette herbe à l'odeur de moisi ! s’énerva Xalendan
<br/>      -    Non, ce n'est pas l'herbe, c'est la bouse dans laquelle tu as marché, s'amusa Chloé en baissant la tête vers les chaussures du chevalier.
<br/>Xalendan regarda avec dégout le marron sur la semelle de sa chaussure.
<br/>       -    Pourquoi c'est arrivé à moi... Beurk !
<br/>Selestan rigola avec Chloé mais Jasson faisait la tête, l'air sombre et songeur.
<br/>Sur son cheval, Chloé se dirigea vers lui et le secoua par l'épaule puis elle lui sourit doucement.
<br/>      -    Ca va ?
<br/>      -  Oui, ça va, je t'assure, répondit Jasson en se forçant à sourire.
<br/>Elle l'embrassa mais le chevalier la repoussa avec tendresse. Chloé allait s'énerver mais Jasson lui mit le doigt sur la bouche avant de s'éloigner à cheval. La jeune femme ne le suivit pas, mais cela n'enleva pas pour autant la fureur dans son cœur. L'après midi, après avoir mangé les pauvres croutons de pain rassis qui leur restaient, les chevaliers attaquèrent de nouveau l'avancée dans la forêt.
<br/>Tout à coup, le décor changea, ils se retrouvèrent dans une plaine, face à une pierre sur un socle.
<br/>      -   C'est trop simple, tout à coup, dit Selestan avec méfiance.
<br/>Il tourna sur lui même mais personne, à part les quatre chevaliers, ne se trouvait sur la plaine. Cela ne le rassura pas pour autant.
<br/>Il ordonna à tous les chevaliers d'avancer avec prudence. Plus que huit mètres avant d'atteindre la pierre mais tous les professeurs arrivaient par derrière, pensant les surprendre.
<br/>En fait, Xalendan avait expliqué à ses camarades comment se parler par la pensée. Durant les longues heures de balade à cheval, les chevaliers avaient en effet développés un peu ce pouvoir.
<br/> " Ils sont derrière nous, faites semblant de ne pas les avoir vu, on va les avoir à leur propre jeu ! " dit Selestan aux chevaliers.
<br/>Shirquant encocha une flèche et la tendit. " Je m'occupe des flèches " affirma Xalendan. Les deux professeurs d'arme au corps à corps sortir leurs armes.
<br/>"Je m'occupe de ces deux là" dit Selestan.
<br/>Le professeur sans nom et les trois enseignants magicien invoquèrent leurs sortilèges.
<br/>"Nous, avec Chloé, on s'occupe des sorts" lança Jasson.
<br/>      -    Maintenant ! beugla Selestan
<br/>Les quatre chevaliers se retournèrent à une vitesse impressionnante et le combat commença. Xalendan bloqua les flèches avec agilité, Selestan fonça sur Zagzull et Marion, l'épée à la main. Jasson et Chloé invoquèrent la magie, ils demandèrent magiquement à Xalendan les mots nécessaires et ils s'écrièrent en langage elfe :
<br/>      -    Bouclier !!
<br/>Le combat se déroula sans qu'un groupe manifeste un avantage réel. Soudain le professeur sans nom leva la main, tous les autres professeurs s'arrêtèrent et Jasson en profita pour mettre un coup d'épée dans la jambe de Shirquant qui cria de douleur.
<br/>      -    J'ai dit stop ! s'écria Laziador en envoyant un lourd regard à Jasson.
<br/>      -  J’n’avais pas entendu, vous n'avez rien dit ! s'exclama Jasson faussement désolé.
<br/>      -  Nous, vos professeurs, n'arrivons même pas à avoir le dessus sur des adolescents de seize ans ! Vous avez vraiment mérité votre semaine de liberté... Vos premières vacances.
<br/>Des sourires de joie se formèrent sur les visages des quatre chevaliers. Ces quelques jours leurs avaient paru tellement long ! Pourtant, ils le savaient, ils avaient beaucoup apprit.
<br/>Xalendan souligna cependant qu'il n'y avait eu qu'un mois avant leurs premières vacances et les professeurs dirent que les chevaliers avaient souvent de courtes vacances comme celles là avant les missions.
<br/>      -    Et la pierre ? demanda Selestan
<br/>      -  Prenez là, vous l'avez gagnée. Elle vous paraitra commune mais son pouvoir ne vous sera révélé qu'au moment où tout vous semblera perdu. Cette pierre très puissante n’apparait sur se socle par magie que très rarement, mais les anciens chevaliers du sphinx avait pour habitude de la prendre avec eu dès qu’ils la voyaient. Il est écrit que cette pierre leurs a plusieurs fois sauvée la vie.
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}