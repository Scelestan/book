function C() { var choice = "Continuer#Secret";var texting = `
<br/>
<br/>** Une nouvelle vie **
<br/>
<br/>
<br/>
<br/>Jasson aimait sa nouvelle vie, plusieurs semaines s’étaient écoulées depuis leur première journée de cours. Bien qu'il fasse exprès d'ignorer Chloé et ne doute pas que celle-ci l’ait remarqué, il est heureux. Pourquoi ignorer Chloé ?…
<br/>Eh bien parce que le jeune homme avait très bien compris l'avertissement lors de la réunion sur leur relation poussée et il ne désirait pas être renvoyé. Il ne voulait pas devenir fermier !
<br/>Il s'assit sur un fauteuil dans ses appartements, tout était alors silencieux. Mais la porte s'ouvrit furieusement, Jasson savait qui c'était. Il ne s’était effectivement pas tromper…
<br/>Chloé entra pleine de rage, les yeux brillants.
<br/>      -    Pourquoi m'ignores-tu ? questionna-t-elle furieusement.
<br/>Jasson avait déjà préparé la réponse à cette question.
<br/>      -    Je ne veux pas être renvoyé, je suis fils d'un fermier alors que toi...
<br/>      -   Je suis une bourge pleine d'or qui n'en a rien à faire de toi, c'est ça !!
<br/>      -      Euh... N...
<br/>      -      Moi qui croyais que... commença-t-elle furieuse.
<br/>Mais quelques larmes coulèrent et elle enfouit son visage dans ses mains.
<br/>« Oula ! » pensa Jasson.
<br/>      -       Tu ne m’aimes pas !! s’exclama Chloé.
<br/>Jasson mit doucement ses doigts sur sa joue et la caressa tendrement.
<br/>      -    Tu crois vraiment que tes caresses vont me consoler, jamais je n'ai éprouvé tant de souffrance que maintenant, je t'aime plus que tout au monde et toi tu m'as ignoré... Tu m'as trompé… Tu as joué avec moi ! s’écria-t-elle en levant ses yeux pleins de larmes*1.
<br/>      -   Non, je t'aime... souffla Jasson qui perdait tous ses moyens. Jamais il n'aurait pensé que l’esprit d’une fille puisse être comme ça.
<br/>      -    Tu m'aimes, s’affola-t-elle en un faux rire, si c'était le cas, tu serais gentil avec moi, tu me ferais des câlins, tu me ferais des bisous, tu t’intéresserais à moi !
<br/>« Elle est jalouse de Xalendan parce que nous avons une nouvelle fois discuté toute la journée » comprit Jasson. Prêt à ne pas se laisser faire, il lança :
<br/>      -    Tu n'éprouves pas de la souffrance, tu éprouves de la jalousie envers Xalendan !
<br/>      -    Comment... Non... Je...
<br/>Elle écarquilla les yeux et lui envoya un regard furieux puis se retourna pour partir. Jasson l'attrapa à temps, la serrant contre lui.
<br/>      -    Si nous continuons notre relation, nous serons renvoyés, comprend le, souffla-t-il dans l'oreille de Chloé.
<br/>      -    Nous pouvons être amis ! lança-t-elle sèchement en se dégageant de ses bras.
<br/>      -   Oui, répondit simplement Jasson, mais ce n'est pas comme ça que ça va se terminer, après... Tu sais que je ne peux pas résister à ton charme, donc... Enfin... Voilà…
<br/>      -   Tu ne peux vraiment pas me résister... répétât-elle en partant.
<br/>« Mince, je n'aurais pas dû dire ça » pensa Jasson, rouge de timidité.
<br/>La soirée se passa sous les rires des blagues lancées par Selestan. Chloé resta à l'écart, songeuse...
<br/>Jasson alla finalement se coucher en se disant que le lendemain, il devrait se lever tôt pour leur premier cours de magie "1". Malgré les semaines qui se passaient très vite, ce cour n’avait encore jamais eu lieu. Il sentit soudain un corps se mettre contre son dos et l'enlacer...
<br/>Jasson se retourna et ne fut pas surpris de trouver Chloé, qui lui lança un regard de défi. Elle était quasiment nue, juste une culotte et un petit soutien-gorge rouge*, elle se rapprocha encore plus de lui et le contact avec sa peau le fit frémir. Elle l'embrassa fougueusement, toujours cet air de défi sur son visage. Ne pouvant pas résister, il se contraint à accepter ses baisers.
<br/>      -    Je t'en supplie...arrête, couina Jasson le souffle court.
<br/>      -  Plein d'hommes sur notre continent rêveraient d'être comblés, mais non, moi je tombe sur le seul paumé ne voulant rien, s'exclama Chloé.
<br/>      -    Ce n'est pas que je n'en veux pas... répondit Jasson en l'a regardant avec envie.
<br/>Quand il prit conscience de ce qu'il avait dit, il rougit, ce qui fit sourire la femme chevalier.
<br/>      -  Je ne veux pas que cette vie s'arrête, reprit le jeune homme.
<br/>Le regard de Chloé changea, c’était un regard plein de tendresse et de considération.
<br/>      -    Bon... Je cède… Mais je voudrais juste continuer de t'embrasser en cachette, tu veux bien ?
<br/>      -    A vrai dire, tu n'as pas eu besoin de mon accord pour le faire jusqu'à maintenant, mais je suis d’accord !
<br/>Ils s’embrassèrent comme jamais, petit au milieu de cette nuit noire, que seule la lune éclairait…
<br/>
<br/>
<br/>
<br/>
<br/>Xalendan se leva très tôt, avant tout le monde, pour avoir le temps de s'exercer à la magie "3". Couper un caillou à l'aide de la magie lui était très dur, il n'avait réussi qu'à entailler le bout de la pierre pendant le dernier cours.
<br/>Décidé à faire mieux, il mangea vite et descendît les escaliers a toute allure. Une fois dans la cour, il ramassa un caillou quelconque et commença, mettant toute sa concentration comme le lui avait enseigné son professeur. Mais rien, il continua pendant prés d'une heure, mais il ne réussit finalement qu'à écorcher le bout de la roche. Xalendan avait beau pensé : "coupe ce caillou" de toutes ses forces, comme on le lui avait appris, le résultat était tellement médiocre qu'il se résigna et alla à la bibliothèque.
<br/>Lisant quelque petit livre au hasard, son niveau de lecture n'étant pas magnifique, il ne comprenait jamais entièrement ce qu'il lisait. Quand il attrapa un livre intitulé "les bardes et leur mensonge", un livre poussiéreux tomba du haut de l'étagère. Il le prit et l'essuya, un beau livre qui n'avait pas dû être ouvert depuis plus de trois siècles, orné d'or sur ses contours.
<br/>Xalendan ouvrit la première page et lut :
<br/>"Le livre ancestral de la langue des plus anciens elfes qui aient existé, les hauts elfes."
<br/>Il relut cette phrase sans comprendre le sens de "elfe". Il ne connaissait qu’une légende qui disait que la première race ayant existé sur le continent était les elfes. Intrigué, il feuilleta le livre se révélant être une traduction de sa langue en langage elfe.
<br/>Il l'emmena dans sa chambre, veillant à bien le cacher, se promettant d'apprendre plus de choses sur les elfes durant cette journée de cours. Se dirigeant vers la salle de magie"1", il trouva Selestan dans le couloir.
<br/>      -    Tu as bien la même heure que moi, cette fois ?
<br/>
<br/>*Eh oui dans ce monde les vêtements sont semblables dans l’ensemble à ceux de notre monde. Seul grande différence, dans ce monde, les habits sont créés par magie.
<br/>      -    Il est sept heures cinquante-cinq.
<br/>      -    Ouais… Il faut il y aller.
<br/>Depuis le premier jour, les deux chevaliers avait pris l’habitude de toujours faire attention à l’heure.
<br/>Ils allèrent donc à leur premier cours de magie"1" où Jasson  dévoila ses talents, car la magie "1" enseignée par Rudiger portait principalement sur la lévitation et la guérison.
<br/>L’équitation était enseignée par Jalune qui leur avait attribué un cheval à chacun, ils devraient toujours s’en occuper, bien sûr, les serviteurs s'occuperaient de leur donner à manger, de les brosser mais :
<br/>      -    Jamais un coup de brosse supplémentaire n'est de trop pour pouvoir passer un peu de temps avec son cheval, leur expliquait à longueur de temps Jalune.
<br/>L’art, la littérature et les mathématiques étaient enseignés par le professeur Satistis, un petit bonhomme cachant toujours sa tête sous une épaisse capuche.
<br/>Magnus, le petit homme de la réunion se révéla être un nain. Il venait d'un autre pays apparemment, mais jamais le professeur dont la race était différente de celle des chevaliers ne parlait de son histoire ou encore de l’histoire de son peuple. Il s'occupait d'une matière bizarre : la stratégie et le commandement. Ayant complètement oublié sa curiosité pour les elfes durant la journée, Xalendan ne put poser sa question qu'à la dernière heure de cours de la journée, la magie"2", enseignée par madame Bibina.
<br/>      -    Madame ?
<br/>Le cour avait à peine commencé, le professeur était surprit d’avoir déjà une question.
<br/>      -    Oui, répondit celle-ci.
<br/>      -    Pourriez-vous me dire ce que vous savez des "elfes", j'ai croisé ce mot dans un livre sans trop savoir ?...
<br/>L’air ahuri de ses trois camarades le fit sourire.
<br/>      -    Les elfes, eh bien... En voila, une bonne question... Ce sont des êtres qui existent sur une île magique infranchissable par ceux qui ne connaissent pas leur langue... commença Bibina.
<br/>La curiosité dans le cœur de Xalendan s'enflamma d'une telle puissance qu'il crut qu'il allait exploser.
<br/>      -    Personne ne sait où est cette île, les elfes sont des êtres mythiques, les plus puissants magiciens du monde. Leur secret résidant dans leur langue... Les elfes sont les premiers êtres à avoir vécu sur notre continent avant d'être massacrés par les nains et les humains, ils ont dû se replier sur leur île natale pour ne pas être anéantis. On dit que des elfes seraient devenus des "elfes sylvains", et qu'ils vivraient dans les bois du Lloclavr, maudit dans notre langue, ce mot elfe est un des rares connus par les humains et les nains. D'autres elfes auraient rejoint les forces du mal, se donnant le nom d'elfes noirs. Oups... Je me suis étendue... Continuons, Selestan, essaye de transformer la couleur de cette eau en la couleur que tu veux...
<br/>Le cours reprit, mais le chevalier restait concentré sur sa découverte, les elfes… son livre…
<br/>Le soir venu, Xalendan courut vers ses appartements, il voulait en découvrir plus sur cette langue. Comprenant maintenant la valeur de ce livre oublié, excité, il se précipita sur l‘ouvrage. Quand il l'ouvrit, il trouva une introduction qu'il n'avait pas remarqué au départ, il la lut. Cette introduction disait que la langue elfe était elle même magique, que ses mots étaient beaucoup plus forts que ceux des autres langues, que si l'on voulait faire de la magie avec des mots d’une autre langue, les résultats seraient minimes, alors qu’avec la langue elfe, les résultats sont largement meilleurs. Car plus la langue est ancienne, plus elle est magique, et le langage elfe est extrêmement vieux.
<br/>Prononcer les mots serait apparemment plus puissant pour exécuter un sortilège. Pour vérifier ce qu'il avait lu, Xalendan ouvrit le livre et chercha "couper" et "caillou" qui se disait "colpit" et "laratis" puis chercha le petit mot "ce" qui se disait "iol".
<br/>Il sortit un caillou de sa poche.
<br/>      -    Colpit iol laratis ! lança-t-il au caillou en se concentrant sur son énergie spirituelle.
<br/>Le résultat fut splendide, la pierre se coupa net en son milieu et les deux morceaux retombèrent dans sa main. Sous un sentiment d'extase, Xalendan rangea le livre, son livre, dans la commode en veillant à ce qu'il ne se voie pas.
<br/>Il dina rapidement suscitant les questions de ses trois camarades qui s’inquiétaient de le voir manger si vite. Il courut dans sa chambre et lut page après page le livre, marmonnant de temps à autre un mot, ou le prononçant à haute voix. Il alla finalement se coucher, les mots dansant dans sa tête...
<br/>
<br/>
<br/>
<br/>
<br/>Chloé se réveilla, le lendemain, encore intriguée par le comportement bizarre de Xalendan. Peut-être qu‘elle ne le connaissait pas bien, il ne fallait plus qu‘elle y pense. Se lever tôt était une épreuve difficile pour elle, habituée à se faire servir tout plein de petits entremets par les serviteurs de son père quand elle se levait tard le matin. C’était en fait tout les jours.
<br/>Elle arriva à son premier cours juste à l'heure. Endurance, une matière qu'elle n'aimait pas trop, de par ses mauvaises capacités,  les longues courses la fatiguaient deux fois plus que les autres... La journée se passa plutôt bien, découvrant la dernière matière non vue durant les semaines passées, les adaptations du chevalier dans les divers lieux, enseignée par un grand homme apparemment blond, dont on ne voyait pas les oreilles. Elles étaient effectivement cachées par un grand bandeau noir. Le professeur refusa de dévoiler son nom, qui,  d'après lui, réveillerait des soupçons...
<br/>Ce cours fût des plus banals, le professeur leur enseigna qu’il existait plusieurs types de climat, que cela influençait les caractéristiques d’un lieu…
<br/>Quelques jours s'écoulèrent sans qu'il y ait un seul cours de magie. Chloé continuait à enseigner la lecture à Jasson de temps en temps. Celui-ci progressait très vite.
<br/>Ils trouvaient le comportement de Xalendan de plus en plus bizarre. Le samedi venu, ils enchaineraient la magie « 1 », « 2 », « 3 » toute la journée, ce qui réjouit Chloé. Puis surtout, le lendemain, ce serait une journée libre !
<br/>      -    Les trois heures de cours d'aujourd'hui porteront sur la lévitation, dit Rudiger au début du cours.
<br/>      -    Oui !! s’exclama Jasson apparemment impatient d'en apprendre plus sur son mystérieux don.
<br/>Le professeur leur assigna une branche d'arbre qu'ils se devaient de faire voler. Jasson comprit tout de suite la difficulté, la branche était plus lourde que n'importe quel objet qu'il avait soulevé de son gré et non par action incontrôlée. La sueur se dessina déjà sur les visages des quatre élèves au bout de cinq minutes, leur branche ne se levait jamais plus de trois secondes.
<br/>Au bout de dix minutes, Xalendan s'exclama à voix basse :
<br/>      -    Bon...finit la rigolade !
<br/>Puis il marmonna des paroles inconnues et la branche se leva d’un coup. Un petit cri de jalousie et de surprise sortit de la bouche des trois autres. Rudiger se dirigea vers lui, les yeux écarquillés.
<br/>      -    Monsieur, il a marmonné quelque chose avant que la branche ne se soulève, dit Chloé pour avoir des explications.
<br/>Un sourire se dessina sur le visage du professeur.
<br/>      -    Voila ce que je voulais que vous deviniez, dire les mots à haute voix plutôt que de les pensés donne beaucoup plus de puissance à votre sort !  Bravo, Xalendan.
<br/>Déçu de ne pas avoir trouvé l'astuce lui même, Jasson recommença en prononçant les mots : "lève-toi" à voix haute. Mais le bâton ne se leva pas aussi puissamment que le bâton de Xalendan. Chloé aperçut celui-ci se détendre quand le professeur s'approcha de lui sans rien lui dire. La branche de Xalendan ne se leva pas aussi puissamment lors de ses autres tentatives de la matinée. Le cours de magie "2" se déroula bien, quoi que banal et sans intérêt. Mais le cours de magie "3" de la soirée fut marqué par l’exécution parfaite de Xalendan pour couper son caillou !
<br/>"Décidément, il doit nous cacher quelque chose sur sa magie" pensa Chloé.
<br/>Durant leur jour libre, on leur distribua un nouvel emploi du temps. Sauf magie et adaptation aux lieux combinée pendant le mercredi matin, l'emploi du temps leur parut normal.
<br/>Xalendan fût absent aux deux repas du soir, le lundi et le mardi. Le mercredi arriva… Le temps passait si vite… Les journées était toutes les mêmes, ils apprenaient, s’entraînaient… Xalendan avait rêvé de ça toute sa jeune vie.
<br/>
<br/>
<br/>
<br/>
<br/>Xalendan se leva tôt se matin là, pour pouvoir encore lire quelques pages de son précieux livre, il savait que ses camarades s'étaient aperçu de son comportement car au dîner ils lui posaient une montagne de questions. Il aimait ce livre, l'admirait et le dévorait  jours après jours. Il apprenait par cœur tous les mots et toutes les phrases, s'exerçant à la magie avec les mots elfes et se les récitant régulièrement. Il se rendit à contre cœur à la mystérieuse matière du mercredi matin : la magie combinée avec l'adaptation aux lieux. Il aurait préférer lire toute la journée...
<br/>Il arriva dans la "salle imaginaire".
<br/>      -    Bien, dit Rudiger quand tout le monde fut arrivé, cette matière est en fait une simulation de scène possible que vous pourriez rencontrer dans le monde extérieur. Vous n'aurez que la magie pour vous sortir de cette situation.
<br/>      -    Oui, on attend de vous que vous preniez partie à la situation donnée et aux lieux donnés, afin d’en faire votre allié naturel, ajouta le professeur d'adaptation. Je vous donne un exemple : vous éviterez d’utiliser le feu dans une forêt sèche ou encore l’électricité alors que vous êtes mouillé.
<br/>Les professeurs bidouillèrent un peu les commandes installées sur le bord de la pièce. Jusqu’au moment où Madame Bibina lança :
<br/>      -    Bien ! commençons...
<br/>Le sol trembla, puis Xalendan ouvrit les yeux en plein désert, entouré de ses trois compagnons d'armes.
<br/>      -    Il faut que vous attrapiez la clef qui vous fera aller au prochain lieu, dit la voix de Rudiger dans la tête de chacun.
<br/>La clef était à l'autre bout de la dune, brillante sous le soleil. Xalendan avait en effet déjà entendu parler du désert, mais ne l’avait jamais vu de ses propres yeux.
<br/>Il avait souvent entendu les bardes du village raconter comment le soleil au désert frappait la tête des voyageurs. Leurs dires se révélaient être la vérité…
<br/>      -    Aller y doucement, ordonna Selestan.
<br/>Personne ne protesta, n'ayant pas vraiment envie de savoir se qu'il y avait derrière la dune...
<br/>Ils avancèrent prudemment et hop, un loup des sables bondit sur eux. Jasson se cloua sur place, surprit, ce qui fît de lui une proie facile pour le loup des sables...
<br/>      -    Sable, envole-toi vers l'animal ! ordonna Chloé.
<br/>Le sable se prit dans les yeux du loup. Cela laissa un petit répit à Jasson pour rejoindre les autres. Exténuée, Chloé dut arrêter son sortilège et le loup fût libéré. L’animal bondit sur Xalendan qui cria la main en l'air :
<br/>      -    Oclï-us, s'itotas tim (bouclier, protège moi) !!
<br/>Un bouclier invisible d'une puissance incroyable apparut, le loup se heurta sur le sortilège et tomba à terre, mort comme électrocuté.
<br/>Le décor se changea tout à coup et ils réapparurent dans la salle imaginaire où les professeurs fronçaient les sourcils. Le professeur d’adaptation marcha vers Xalendan, son visage en disait long sur sa surprise :
<br/>      -    Je voudrai te voir à la fin du cours, il faut que l’on parle, cependant, ne fais pas... Enfin tu vois ce que je veux dire.
<br/>Et le décor se rechangea, ils étaient dans une forêt dense...
<br/>Comment le professeur aurait-il pu savoir quelle langue il avait utilisée ?... Cela ne se pouvait pas, personne ne connaît cette langue...
<br/>Le cours se finit enfin. Les chevaliers étaient épuisés. Le professeur sans nom pris soudain Xalendan par l’épaule. Il dit à Selestan d’informé les autres professeurs que Xalendan ne viendrait pas assisté à leur cour.
<br/>L’homme emmena Xalendan dans un bureau, qui devait être le sien. Il le fit s'asseoir, puis il s'assit à son tour en face du jeune chevalier.
<br/>Ils s'observèrent un moment, impassibles.
<br/>      -   D'où la connais-tu ? demanda enfin l'homme au nom inconnu.
<br/>      -    D'où je connais quoi, monsieur ? le questionna poliment Xalendan
<br/>Un sourire léger apparut sur les lèvres du professeur.
<br/>      -   Les elfes sont des êtres magnifiques, n'est-ce pas ?  questionna le professeur.
<br/>Puis l'homme ferma les yeux... Xalendan savait de son précieux livre que pour lire dans l'âme de quelqu'un, il fallait fermer les yeux.
<br/>Par chance, il venait de finir le chapitre sur : « comment reconnaître si quelqu’un lit dans ton âme ». Il suffisait juste de fermer les yeux et d’être très attentif. Il le fit et sentit une âme s'infiltrer. Il se dépêcha de forger ses défenses comme le lui avait enseigné le livre. L’âme augmenta son attaque. Pas assez puissant, Xalendan dut se contraindre à lâcher prise...
<br/>Il se leva et lança un gros coup de poing que le professeur esquiva.
<br/>      -   Tu ne veux vraiment pas que je lise en toi, c’est une chose, mais pourquoi ? demanda l’homme en ouvrant les yeux.
<br/>      -      Que me voulez vous ?
<br/>Un autre sourire se dessina sur le visage de l'homme.
<br/>      -    Comment connais-tu la langue des elfes ? demanda enfin le professeur.
<br/>      -   Je ne la connais pas, personne ne la connaît à part les elfes, non ?
<br/>Le sourire du professeur s'agrandit encore.
<br/>      -   Des questions et des questions, si je te révèle mon plus gros secret, tu me promets de me révéler le tien ?
<br/>      -     Si votre secret en vaut...
<br/>      -    Oui, il en vaut le coup, mais es-tu d’accord ? le coupa le professeur un peu blasé.
<br/>Xalendan parut un peu méfiant.
<br/>      -   Si le secret en vaut bien la peine, oui, mais vous dites le votre en premier, d’accord ?
<br/>Le sourire revint sur le visage du professeur.
<br/>      -   Je suis d’accord, dit il en mettant fin à la nuée de questions.
<br/>Le professeur porta la main à son bandeau et l'enleva... Des oreilles pointues d'une extrême finesse se dévoilèrent.
<br/>      -    Vous êtes un elfe, s'émerveilla Xalendan
<br/>      -    Je m'appelle Laziador-dé-Orion, un prénom elfe...
<br/>      -   Vous ne vouliez pas le dire parce que sinon, on aurait soupçonné…
<br/>      -   Eh bien voila, je t'ai dit mon secret, dis moi le tien, à présent.
<br/>Après l'aveu fait par le professeur, Xalendan n'hésita pas à dévoiler l'existence de son précieux livre.
<br/>      -    Ce livre a été oublié et il est très rare, tu sais. Je suppose que tu as appris à te défendre des infiltrations dans ton esprit grâce à ce livre et que tu sais les repérer aussi grâce à cette ouvrage... Bien... Je suppose que tu seras prêt à laisser ta vie pour que l'on ne te prenne pas ton trésor, mais je te demanderai de ne jamais dire à qui que ce soit la découverte de ce livre, ni mon secret... Et n'utilise pas la langue en classe et... Il faudra que tu me montre ce livre un de ces jours.
<br/>      -    D’accord, répondit simplement le jeune chevalier.
<br/>      -   D'autre part, les elfes qui ne veulent pas révéler quelque chose répondent avec des questions et tu le fais plutôt bien.
<br/>      -    Oui et... rougit Xalendan, j'aimerais que vous m'en appreniez plus sur la magie, ça m'intéresse tellement... Et sur les elfes...
<br/>Laziador sourit puis lui expliqua qu'il ne pouvait pas le faire sans que les autres s'en aperçoivent, qu'il faudrait beaucoup d'intelligence à Xalendan pour arriver à se sortir de la masse de questions qu’allaient lui poser ses camarades...
<br/>
<br/>
<br/>
<br/>
<br/>     
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
`;var ok = prog("page1-1", 1, (0.05*(texting.split("<br/>").length)));
var ajoue = ok.cadreGeometry("Cadre");
ajoue.changeCouleur("Cadre", "rgb(241,241,241)");
ajoue.plusItem("item1", 10, 100-(texting.split("<br/>").length*3), 80, -20+(texting.split("<br/>").length*3));
ajoue.changeCouleur("item1", "white"); 
ajoue.changeOrdre("item1", "30");
var triag = "";
for (var a = 0; a < choice.split("*").length; a++) {
	triag += "<br/><button style='font-size: 38px; font-family: Helvetica;' onclick='suite(this, "+ '"' + choice.split("*")[a].split("#")[1] + '"' +")'>" + choice.split("*")[a].split("#")[0] + "</button>";
}
ajoue.utiliserHTML("item1", "<div style='font-size: 24px; font-family: Helvetica;' >" + texting + "</div><div style='position:fixed; bottom:0; right:50%'>" + triag + "</div>");
ok.ajouterGeometry("page1-1", ajoue.GeoString());
 var charge = ok.Activer(); 
charge.ChargerPage("030", "page1-1", false); 
ok.autoZoom(false);
charge.autoRedimention();}