﻿function C() { 






var geoss = `{
"type":"Collection",
"name":"XML_doss",
"crs":{"type":"name","utilisation":{"name": "CritCanvas"}},
"item":[
{"type":"Feature","utilisation":{"id":"030","route":"null","couleur":"white","utiliser":"","contour":null,"Ordre":"0"},"geometrie":{"type":"Polygon","place":[[[4.634857,43.909642],[4.75296,43.909642],[4.75296,42.983428],[4.634857,42.983428],[4.634857,43.909642]]]}} , 
{"type":"Feature","utilisation":{"id":"029","route":"null","couleur":"rgb(250,210,80)","utiliser":"","contour":null,"Ordre":"1"},"geometrie":{"type":"Polygon","place":[[[4.643955,43.956858],[4.649105,43.956858],[4.649105,43.955375],[4.643955,43.955375],[4.643955,43.956858]]]}} , 
{"type":"Feature","utilisation":{"id":"028","route":"null","couleur":"rgb(250,210,80)","utiliser":"","contour":null,"Ordre":"2"},"geometrie":{"type":"Polygon","place":[[[4.634771,43.928615],[4.637775,43.912417],[4.641552,43.919527],[4.634771,43.928615]]]}} , 
{"type":"Feature","utilisation":{"id":"027","route":"null","couleur":"rgb(210,210,80)","utiliser":"","contour":null,"Ordre":"3"},"geometrie":{"type":"Polygon","place":[[[4.633827,43.941595],[4.64653,43.913221],[4.65065,43.935785],[4.633827,43.941595]]]}} , 
{"type":"Feature","utilisation":{"id":"026","route":"null","couleur":"rgb(210,210,80)","utiliser":"","contour":null,"Ordre":"4"},"geometrie":{"type":"Polygon","place":[[[4.651423,43.917425],[4.649963,43.916127],[4.651079,43.91489],[4.653311,43.916251],[4.651423,43.917425]]]}} , 
{"type":"Feature","utilisation":{"id":"025","route":"null","couleur":"rgb(20,210,170)","utiliser":"","contour":null,"Ordre":"5"},"geometrie":{"type":"Polygon","place":[[[4.637003,43.918847],[4.649363,43.918847],[4.649363,43.914148],[4.637003,43.914148],[4.637003,43.918847]]]}} , 
{"type":"Feature","utilisation":{"id":"024","route":"null","couleur":"rgb(20,210,70)","utiliser":"","contour":null,"Ordre":"6"},"geometrie":{"type":"Polygon","place":[[[4.637175,43.925215],[4.652452,43.925215],[4.652452,43.920207],[4.637175,43.920207],[4.637175,43.925215]]]}} , 
{"type":"Feature","utilisation":{"id":"023","route":"null","couleur":"rgb(210,210,70)","utiliser":"","contour":null,"Ordre":"7"},"geometrie":{"type":"Polygon","place":[[[4.729357,43.929171],[4.730473,43.915756],[4.731846,43.919589],[4.729357,43.929171]]]}} , 
{"type":"Feature","utilisation":{"id":"022","route":"null","couleur":"rgb(210,210,170)","utiliser":"","contour":null,"Ordre":"8"},"geometrie":{"type":"Polygon","place":[[[4.718285,43.926699],[4.720516,43.915014],[4.727297,43.915138],[4.721117,43.922248],[4.718285,43.926699]]]}} , 
{"type":"Feature","utilisation":{"id":"021","route":"null","couleur":"rgb(210,210,140)","utiliser":"","contour":null,"Ordre":"9"},"geometrie":{"type":"Polygon","place":[[[4.724894,43.976688],[4.724293,43.951359],[4.727898,43.970882],[4.724894,43.976688]]]}} , 
{"type":"Feature","utilisation":{"id":"020","route":"null","couleur":"rgb(250,210,140)","utiliser":"","contour":null,"Ordre":"10"},"geometrie":{"type":"Polygon","place":[[[4.725065,43.949134],[4.724894,43.946106],[4.728155,43.945117],[4.727125,43.954695],[4.725065,43.949134]]]}} , 
{"type":"Feature","utilisation":{"id":"019","route":"null","couleur":"rgb(250,210,140)","utiliser":"","contour":null,"Ordre":"11"},"geometrie":{"type":"Polygon","place":[[[4.724979,43.944376],[4.728069,43.943758],[4.726439,43.919837],[4.726439,43.919775],[4.726439,43.919775],[4.726439,43.919775],[4.726439,43.919775],[4.722662,43.92812],[4.724979,43.944376]]]}} , 
{"type":"Feature","utilisation":{"id":"018","route":"null","couleur":"rgb(250,240,240)","utiliser":"","contour":null,"Ordre":"12"},"geometrie":{"type":"Polygon","place":[[[4.636488,43.978232],[4.644127,43.978788],[4.647818,43.955252],[4.638376,43.969832],[4.636488,43.978232]]]}} , 
{"type":"Feature","utilisation":{"id":"017","route":"null","couleur":"rgb(250,240,140)","utiliser":"","contour":null,"Ordre":"13"},"geometrie":{"type":"Polygon","place":[[[4.706354,43.966063],[4.715452,43.966063],[4.715452,43.954201],[4.706354,43.954201],[4.706354,43.966063]]]}} , 
{"type":"Feature","utilisation":{"id":"016","route":"null","couleur":"rgb(90,240,140)","utiliser":"","contour":null,"Ordre":"14"},"geometrie":{"type":"Polygon","place":[[[4.654942,43.979591],[4.709101,43.979591],[4.709101,43.979529],[4.654942,43.979529],[4.654942,43.979591]]]}} , 
{"type":"Feature","utilisation":{"id":"015","route":"null","couleur":"rgb(9,240,140)","utiliser":"","contour":null,"Ordre":"15"},"geometrie":{"type":"Polygon","place":[[[4.650908,43.979035],[4.712706,43.979035],[4.712706,43.978294],[4.650908,43.978294],[4.650908,43.979035]]]}} , 
{"type":"Feature","utilisation":{"id":"014","route":"null","couleur":"rgb(9,240,170)","utiliser":"","contour":null,"Ordre":"16"},"geometrie":{"type":"Polygon","place":[[[4.647989,43.977676],[4.715023,43.977676],[4.715023,43.976503],[4.647989,43.976503],[4.647989,43.977676]]]}} , 
{"type":"Feature","utilisation":{"id":"013","route":"null","couleur":"rgb(90,240,170)","utiliser":"","contour":null,"Ordre":"17"},"geometrie":{"type":"Polygon","place":[[[4.647989,43.90914],[4.728327,43.90914],[4.728327,43.908954],[4.647989,43.908954],[4.647989,43.90914]]]}} , 
{"type":"Feature","utilisation":{"id":"012","route":"null","couleur":"rgb(90,210,170)","utiliser":"","contour":null,"Ordre":"18"},"geometrie":{"type":"Polygon","place":[[[4.643869,43.910129],[4.730129,43.910129],[4.730129,43.909635],[4.643869,43.909635],[4.643869,43.910129]]]}} , 
{"type":"Feature","utilisation":{"id":"011","route":"null","couleur":"rgb(90,210,170)","utiliser":"","contour":null,"Ordre":"19"},"geometrie":{"type":"Polygon","place":[[[4.641552,43.912664],[4.731588,43.912664],[4.731588,43.9105],[4.641552,43.9105],[4.641552,43.912664]]]}} , 
{"type":"Feature","utilisation":{"id":"crit","route":"null","couleur":"rgb(250,250,250)","utiliser":"16#*#georgia#*##509334#*#Les gardiens d'hylzandre","contour":null,"Ordre":"20"},"geometrie":{"type":"Polygon","place":[[[4.655113,43.953707],[4.716139,43.953707],[4.716139,43.912974],[4.655113,43.912974],[4.655113,43.953707]]]}} , 
{"type":"Feature","utilisation":{"id":"09","route":"null","couleur":"rgb(250,210,190)","utiliser":"","contour":null,"Ordre":"21"},"geometrie":{"type":"Polygon","place":[[[4.649963,43.956858],[4.714165,43.956858],[4.714165,43.954078],[4.649963,43.954078],[4.649963,43.956858]]]}} , 
{"type":"Feature","utilisation":{"id":"08","route":"replace_socket_Intro","couleur":"rgb(100,100,100)","utiliser":"","contour":null,"Ordre":"22"},"geometrie":{"type":"Polygon","place":[[[4.636831,43.968843],[4.636831,43.928491],[4.65477,43.928491],[4.65477,43.954757],[4.643354,43.954757],[4.643354,43.968473],[4.636831,43.968843]]]}} , 
{"type":"Feature","utilisation":{"id":"07","route":"null","couleur":"rgb(230,210,220)","utiliser":"","contour":null,"Ordre":"23"},"geometrie":{"type":"Polygon","place":[[[4.715967,43.979097],[4.721804,43.979097],[4.721804,43.936156],[4.715967,43.936156],[4.715967,43.979097]]]}} , 
{"type":"Feature","utilisation":{"id":"06","route":"null","couleur":"rgb(130,10,20)","utiliser":"","contour":null,"Ordre":"24"},"geometrie":{"type":"Polygon","place":[[[4.636917,43.97675],[4.646616,43.97675],[4.646616,43.970511],[4.636917,43.970511],[4.636917,43.97675]]]}} , 
{"type":"Feature","utilisation":{"id":"05","route":"null","couleur":"rgb(180,180,120)","utiliser":"","contour":null,"Ordre":"25"},"geometrie":{"type":"Polygon","place":[[[4.644899,43.969832],[4.705753,43.969832],[4.705753,43.957229],[4.644899,43.957229],[4.644899,43.969832]]]}} , 
{"type":"Feature","utilisation":{"id":"04","route":"null","couleur":"rgb(180,180,120)","utiliser":"","contour":null,"Ordre":"26"},"geometrie":{"type":"Polygon","place":[[[4.65683,43.965199],[4.693308,43.965199],[4.693308,43.960194],[4.65683,43.960194],[4.65683,43.965199]]]}} , 
{"type":"Feature","utilisation":{"id":"03","route":"null","couleur":"rgb(250,190,170)","utiliser":"","contour":null,"Ordre":"27"},"geometrie":{"type":"Polygon","place":[[[4.647646,43.975885],[4.722319,43.975885],[4.722319,43.966372],[4.647646,43.966372],[4.647646,43.975885]]]}} , 
{"type":"Feature","utilisation":{"id":"02","route":"null","couleur":"rgb(250,190,170)","utiliser":"","contour":null,"Ordre":"28"},"geometrie":{"type":"Polygon","place":[[[4.657259,43.973723],[4.710217,43.973723],[4.710217,43.96767],[4.657259,43.96767],[4.657259,43.973723]]]}}
]
}`;

var ok = prog("page1", 1, 1);
var cool = JSON.parse(geoss);
geoss = JSON.stringify(cool);
ok.ajouterGeometry("page1", geoss);

var charge = ok.Activer();

ok.autoZoom(true);
charge.ChargerPage("init", "page1", true); 
charge.autoRedimention(); 
document.getElementById("08").click();

}

                                      
